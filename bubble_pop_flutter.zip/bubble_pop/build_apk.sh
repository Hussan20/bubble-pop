#!/usr/bin/env bash
# Builds the release APK. Needs Flutter (https://docs.flutter.dev/get-started/install).
set -e
cd "$(dirname "$0")"

if [ ! -d android ]; then
  flutter create --platforms=android --org com.bubblepop --project-name bubble_pop .
fi
flutter pub get
dart run tool/setup_android.dart
flutter build apk --release

echo
echo "Done! APK: build/app/outputs/flutter-apk/app-release.apk"
