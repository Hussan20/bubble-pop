// Bubble Pop — a cheerful bubble-popping arcade game (Flutter edition).
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/content.dart';
import 'core/save.dart';
import 'services/audio.dart';
import 'services/storage.dart';
import 'ui/app.dart';
import 'ui/kit.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  // full screen: the play area gets the whole height of the phone
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  final store = await PrefsStore.open();
  Save.load(store, 'ar');
  app = AppCtl();
  app.boot();
  runApp(const BubblePopApp());
  unawaited(GameAudio.init());
}

class BubblePopApp extends StatelessWidget {
  const BubblePopApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Bubble Pop',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: Pal.frame, brightness: Pal.dark ? Brightness.dark : Brightness.light),
          scaffoldBackgroundColor: Pal.page,
          fontFamily: gLang == 'ar' ? 'Baloo' : 'Sniglet',
        ),
        builder: (context, child) {
          final mq = MediaQuery.of(context);
          return Directionality(
            textDirection: gLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
            child: MediaQuery(
              data: mq.copyWith(textScaler: mq.textScaler.clamp(maxScaleFactor: 1.1)),
              child: child ?? const SizedBox.shrink(),
            ),
          );
        },
        // ignore: prefer_const_constructors
        home: GameShell(),
      ),
    );
  }
}
