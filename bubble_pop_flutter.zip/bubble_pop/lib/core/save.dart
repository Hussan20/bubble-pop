// SAVE — versioned, validated, checksummed, with a rolling backup.
import 'dart:async';
import 'dart:convert';

import 'content.dart';
import 'util.dart';

const String saveKey = 'bubblepop.save.v3';
const String backupKey = 'bubblepop.save.v3.bak';
const String corruptKey = 'bubblepop.save.corrupt';
const int saveVersion = 3;

/// Key-value persistence implemented by the app (SharedPreferences).
abstract class KeyValueStore {
  bool get ok;
  String? read(String key);
  bool write(String key, String value);
}

// content tables under names that the model's fields don't shadow
final List<String> _diffKeys = difficulty.keys.toList();
const List<UpgradeDef> _upgradeDefs = upgrades;

// ---------------------------------------------------------------- tolerant readers
final RegExp idRe = RegExp(r'^[a-zA-Z0-9_:\-]{1,48}$');
Map<String, dynamic> _obj(Object? v) => v is Map<String, dynamic> ? v : <String, dynamic>{};
List<dynamic> _list(Object? v) => v is List ? v : const [];
const int _maxInt = 9000000000000000; // < 2^53, safe through JSON
int _int(Object? v, int d, [int min = 0, int max = _maxInt]) {
  if (v is num && v.isFinite) return clampI(v.round(), min, max);
  return d;
}

double _dbl(Object? v, double d, [double min = 0, double max = 1e12]) {
  if (v is num && v.isFinite) return clampD(v.toDouble(), min, max);
  return d;
}

bool _bool(Object? v, bool d) => v is bool ? v : d;
String _str(Object? v, String d, [RegExp? re]) => v is String && v.length < 200 && (re == null || re.hasMatch(v)) ? v : d;
String _oneOf(Object? v, List<String> list, String d) => v is String && list.contains(v) ? v : d;
Map<String, int> _intMap(Object? v) {
  final out = <String, int>{};
  final m = _obj(v);
  for (final e in m.entries) {
    if (idRe.hasMatch(e.key) && e.value is num && (e.value as num).isFinite) {
      out[e.key] = (e.value as num).round().clamp(0, _maxInt).toInt();
    }
  }
  return out;
}

// ---------------------------------------------------------------- model
class Settings {
  String lang;
  bool sfxOn;
  bool musicOn;
  double sfx;
  double music;
  String motion; // auto · reduced · full
  String difficulty;
  bool vibrate;
  Settings({
    this.lang = 'ar',
    this.sfxOn = true,
    this.musicOn = true,
    this.sfx = 0.8,
    this.music = 0.45,
    this.motion = 'auto',
    this.difficulty = 'normal',
    this.vibrate = true,
  });
  Map<String, dynamic> toJson() => {
        'lang': lang, 'sfxOn': sfxOn, 'musicOn': musicOn, 'sfx': sfx, 'music': music, 'motion': motion,
        'difficulty': difficulty, 'vibrate': vibrate,
      };
  static Settings fromJson(Object? raw, String defLang) {
    final m = _obj(raw);
    return Settings(
      lang: _oneOf(m['lang'], const ['en', 'ar'], defLang),
      sfxOn: _bool(m['sfxOn'], true),
      musicOn: _bool(m['musicOn'], true),
      sfx: _dbl(m['sfx'], 0.8, 0, 1),
      music: _dbl(m['music'], 0.45, 0, 1),
      motion: _oneOf(m['motion'], const ['auto', 'reduced', 'full'], 'auto'),
      difficulty: _oneOf(m['difficulty'], _diffKeys, 'normal'),
      vibrate: _bool(m['vibrate'], true),
    );
  }
}

class Profile {
  int xp;
  int level;
  int coins;
  Profile({this.xp = 0, this.level = 1, this.coins = 0});
}

class StageRec {
  int stars;
  int best;
  StageRec(this.stars, this.best);
}

class QuestState {
  String id;
  int n;
  int p;
  bool claimed;
  QuestState(this.id, this.n, {this.p = 0, this.claimed = false});
  bool get done => p >= n;
}

class QuestBook {
  String key;
  List<QuestState> list;
  bool rerolled;
  QuestBook({this.key = '', List<QuestState>? list, this.rerolled = false}) : list = list ?? [];
}

class LoginState {
  String last;
  int day;
  int streak;
  int best;
  int total;
  LoginState({this.last = '', this.day = 0, this.streak = 0, this.best = 0, this.total = 0});
}

class DailyHist {
  String d;
  int s;
  bool w;
  DailyHist(this.d, this.s, this.w);
}

class DailyState {
  String key;
  int best;
  bool done;
  List<DailyHist> history;
  DailyState({this.key = '', this.best = 0, this.done = false, List<DailyHist>? history}) : history = history ?? [];
}

class EventState {
  int n;
  List<int> claimed;
  EventState({this.n = 0, List<int>? claimed}) : claimed = claimed ?? [];
}

class Stats {
  int pops = 0;
  Map<String, int> popsBy = {};
  int games = 0;
  Map<String, int> gamesBy = {};
  int playMs = 0;
  int bestStreak = 0;
  int bestChain = 0;
  int powersUsed = 0;
  int misses = 0;
  int escapes = 0;
  int fevers = 0;
  int coinsEarned = 0;
  int questsDone = 0;
  int dailyDone = 0;
  int achDone = 0;

  Map<String, dynamic> toJson() => {
        'pops': pops, 'popsBy': popsBy, 'games': games, 'gamesBy': gamesBy, 'playMs': playMs, 'bestStreak': bestStreak,
        'bestChain': bestChain, 'powersUsed': powersUsed, 'misses': misses, 'escapes': escapes, 'fevers': fevers,
        'coinsEarned': coinsEarned, 'questsDone': questsDone, 'dailyDone': dailyDone, 'achDone': achDone,
      };
  static Stats fromJson(Object? raw) {
    final m = _obj(raw);
    return Stats()
      ..pops = _int(m['pops'], 0)
      ..popsBy = _intMap(m['popsBy'])
      ..games = _int(m['games'], 0)
      ..gamesBy = _intMap(m['gamesBy'])
      ..playMs = _int(m['playMs'], 0)
      ..bestStreak = _int(m['bestStreak'], 0)
      ..bestChain = _int(m['bestChain'], 0)
      ..powersUsed = _int(m['powersUsed'], 0)
      ..misses = _int(m['misses'], 0)
      ..escapes = _int(m['escapes'], 0)
      ..fevers = _int(m['fevers'], 0)
      ..coinsEarned = _int(m['coinsEarned'], 0)
      ..questsDone = _int(m['questsDone'], 0)
      ..dailyDone = _int(m['dailyDone'], 0)
      ..achDone = _int(m['achDone'], 0);
  }
}

class SaveData {
  int created = DateTime.now().millisecondsSinceEpoch;
  String contentSeen = '';
  Settings settings = Settings();
  Profile profile = Profile();
  List<String> owned = ['skin:soap', 'fx:splash', 'theme:bath'];
  Map<String, String> equipped = {'skin': 'soap', 'fx': 'splash', 'theme': 'bath'};
  Map<String, int> upgrades = {};
  Map<String, Map<String, int>> best = {'classic': {}, 'time': {}, 'survival': {}};
  int zenPops = 0;
  int survivalTime = 0;
  Map<int, StageRec> stages = {};
  Stats stats = Stats();
  Map<String, int> ach = {};
  Set<String> discovered = {};
  Set<String> tips = {};
  QuestBook qDaily = QuestBook();
  QuestBook qWeekly = QuestBook();
  LoginState login = LoginState();
  DailyState daily = DailyState();
  Map<String, EventState> events = {};
  String lastMode = 'classic';
  int lastStage = 1;

  String get skin => equipped['skin'] ?? 'soap';
  String get fx => equipped['fx'] ?? 'splash';
  String get theme => equipped['theme'] ?? 'bath';

  static List<Map<String, dynamic>> _quests(QuestBook b) =>
      b.list.map((q) => <String, dynamic>{'id': q.id, 'n': q.n, 'p': q.p, 'claimed': q.claimed}).toList();

  Map<String, dynamic> toJson() => {
        'v': saveVersion,
        'created': created,
        'contentSeen': contentSeen,
        'settings': settings.toJson(),
        'profile': {'xp': profile.xp, 'level': profile.level, 'coins': profile.coins},
        'owned': owned,
        'equipped': equipped,
        'upgrades': upgrades,
        'best': {
          for (final e in best.entries) e.key: e.value,
          'zen': {'pops': zenPops},
          'survivalTime': survivalTime,
        },
        'stages': {for (final e in stages.entries) '${e.key}': {'stars': e.value.stars, 'best': e.value.best}},
        'stats': stats.toJson(),
        'ach': ach,
        'discovered': {for (final k in discovered) k: true},
        'tips': {for (final k in tips) k: true},
        'quests': {
          'daily': {'key': qDaily.key, 'list': _quests(qDaily), 'rerolled': qDaily.rerolled},
          'weekly': {'key': qWeekly.key, 'list': _quests(qWeekly)},
        },
        'login': {'last': login.last, 'day': login.day, 'streak': login.streak, 'best': login.best, 'total': login.total},
        'daily': {
          'key': daily.key, 'best': daily.best, 'done': daily.done,
          'history': daily.history.map((h) => {'d': h.d, 's': h.s, 'w': h.w}).toList(),
        },
        'events': {for (final e in events.entries) e.key: {'n': e.value.n, 'claimed': e.value.claimed}},
        'lastMode': lastMode,
        'lastStage': lastStage,
      };

  /// Validates everything; unknown or damaged fields fall back to defaults.
  static SaveData fromJson(Object? rawAny, String defLang) {
    final s = SaveData();
    s.settings = Settings(lang: defLang);
    if (rawAny is! Map<String, dynamic>) return s;
    final raw = rawAny;
    s.created = _int(raw['created'], s.created);
    s.contentSeen = _str(raw['contentSeen'], '');
    s.settings = Settings.fromJson(raw['settings'], defLang);
    final rp = _obj(raw['profile']);
    s.profile = Profile(xp: _int(rp['xp'], 0), level: _int(rp['level'], 1, 1, 999), coins: _int(rp['coins'], 0, 0, 1000000000));
    final owned = <String>{...s.owned};
    for (final x in _list(raw['owned'])) {
      if (x is String && idRe.hasMatch(x)) owned.add(x);
    }
    s.owned = owned.toList();
    final re = _obj(raw['equipped']);
    for (final k in const ['skin', 'fx', 'theme']) {
      final v = _str(re[k], s.equipped[k]!, idRe);
      if (s.owned.contains('$k:$v')) s.equipped[k] = v;
    }
    final ru = _obj(raw['upgrades']);
    for (final u in _upgradeDefs) {
      final v = _int(ru[u.id], 0, 0, u.prices.length);
      if (v > 0) s.upgrades[u.id] = v;
    }
    final rb = _obj(raw['best']);
    for (final m in const ['classic', 'time', 'survival']) {
      s.best[m] = _intMap(rb[m]);
    }
    s.zenPops = _int(_obj(rb['zen'])['pops'], 0);
    s.survivalTime = _int(rb['survivalTime'], 0);
    final rs = _obj(raw['stages']);
    for (final e in rs.entries) {
      final id = int.tryParse(e.key);
      final v = _obj(e.value);
      if (id != null && id > 0 && id < 1000) s.stages[id] = StageRec(_int(v['stars'], 0, 0, 3), _int(v['best'], 0));
    }
    s.stats = Stats.fromJson(raw['stats']);
    s.ach = _intMap(raw['ach']);
    for (final k in _obj(raw['discovered']).keys) {
      if (bubbles.containsKey(k)) s.discovered.add(k);
    }
    for (final k in _obj(raw['tips']).keys) {
      if (idRe.hasMatch(k)) s.tips.add(k);
    }
    List<QuestState> ql(Object? l) {
      final out = <QuestState>[];
      for (final q in _list(l)) {
        final m = _obj(q);
        final id = _str(m['id'], '', idRe);
        if (id.isEmpty) continue;
        out.add(QuestState(id, _int(m['n'], 1, 1), p: _int(m['p'], 0), claimed: _bool(m['claimed'], false)));
        if (out.length >= 6) break;
      }
      return out;
    }

    final rq = _obj(raw['quests']);
    final rqd = _obj(rq['daily']), rqw = _obj(rq['weekly']);
    s.qDaily = QuestBook(key: _str(rqd['key'], ''), list: ql(rqd['list']), rerolled: _bool(rqd['rerolled'], false));
    s.qWeekly = QuestBook(key: _str(rqw['key'], ''), list: ql(rqw['list']));
    final rl = _obj(raw['login']);
    s.login = LoginState(
      last: _str(rl['last'], ''),
      day: _int(rl['day'], 0, 0, 6),
      streak: _int(rl['streak'], 0),
      best: _int(rl['best'], 0),
      total: _int(rl['total'], 0),
    );
    final rd = _obj(raw['daily']);
    final hist = <DailyHist>[];
    for (final h in _list(rd['history'])) {
      final m = _obj(h);
      final d = _str(m['d'], '');
      if (d.isNotEmpty) hist.add(DailyHist(d, _int(m['s'], 0), _bool(m['w'], false)));
    }
    s.daily = DailyState(
      key: _str(rd['key'], ''),
      best: _int(rd['best'], 0),
      done: _bool(rd['done'], false),
      history: hist.length > 14 ? hist.sublist(hist.length - 14) : hist,
    );
    for (final e in _obj(raw['events']).entries) {
      if (!idRe.hasMatch(e.key)) continue;
      final m = _obj(e.value);
      final claimed = <int>[];
      for (final x in _list(m['claimed'])) {
        if (x is int && x >= 0 && x < 10) claimed.add(x);
      }
      s.events[e.key] = EventState(n: _int(m['n'], 0), claimed: claimed);
    }
    s.lastMode = _oneOf(raw['lastMode'], modeOrder, 'classic');
    s.lastStage = _int(raw['lastStage'], 1, 1, 999);
    return s;
  }
}

// ---------------------------------------------------------------- manager
class Save {
  static late KeyValueStore store;
  static SaveData data = SaveData();
  static String notice = ''; // '', recovered, reset, nostorage
  static String defLang = 'ar';
  static Timer? _timer;

  static String wrap(SaveData d) {
    final json = jsonEncode(d.toJson());
    return jsonEncode({'v': saveVersion, 'h': hashStr(json), 'd': json});
  }

  static Object? unwrap(String? text) {
    if (text == null || text.isEmpty) return null;
    try {
      final w = jsonDecode(text);
      if (w is! Map<String, dynamic>) return null;
      final d = w['d'];
      if (d is! String || w['h'] != hashStr(d)) return null;
      return jsonDecode(d);
    } catch (_) {
      return null;
    }
  }

  static void load(KeyValueStore kv, String lang) {
    store = kv;
    defLang = lang;
    if (!kv.ok) {
      notice = 'nostorage';
      data = SaveData.fromJson(null, lang);
      return;
    }
    final primary = kv.read(saveKey);
    var obj = unwrap(primary);
    if (obj == null && primary != null && primary.isNotEmpty) {
      obj = unwrap(kv.read(backupKey));
      kv.write(corruptKey, primary.length > 200000 ? primary.substring(0, 200000) : primary);
      notice = obj != null ? 'recovered' : 'reset';
    }
    data = SaveData.fromJson(obj, lang);
  }

  static void dirty() {
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 400), flush);
  }

  static bool flush() {
    _timer?.cancel();
    _timer = null;
    if (!store.ok) return false;
    final prev = store.read(saveKey);
    if (prev != null && unwrap(prev) != null) store.write(backupKey, prev);
    return store.write(saveKey, wrap(data));
  }

  static String exportCode() {
    try {
      return base64Encode(utf8.encode(wrap(data)));
    } catch (_) {
      return '';
    }
  }

  static SaveData? importCode(String code) {
    try {
      final text = utf8.decode(base64Decode(code.trim().replaceAll(RegExp(r'\s+'), '')));
      final obj = unwrap(text);
      if (obj == null) return null;
      return SaveData.fromJson(obj, defLang);
    } catch (_) {
      return null;
    }
  }

  static void reset() {
    final lang = data.settings.lang;
    data = SaveData.fromJson(null, lang);
    data.contentSeen = contentVersion;
    flush();
  }
}
