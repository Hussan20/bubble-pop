// PROGRESSION — XP/levels, coins, items, upgrades, achievements, missions,
// daily gift, seasonal events, daily challenge and run results.
import 'dart:math' as math;

import 'content.dart';
import 'save.dart';
import 'strings.dart';
import 'util.dart';

class ToastData {
  final String icon; // icon id (see ui/icons)
  final String bubble; // bubble type preview instead of an icon
  final String title;
  final String text;
  final bool tip;
  final int ms;
  final String sound;
  const ToastData({this.icon = 'star', this.bubble = '', required this.title, this.text = '', this.tip = false, this.ms = 2600, this.sound = ''});
}

class LevelUp {
  final int level;
  final int coins;
  final List<String> modes;
  final List<String> items;
  LevelUp(this.level, this.coins, this.modes, this.items);
}

class RunSummary {
  String mode = 'classic';
  int stage = 0;
  String diff = 'normal';
  int score = 0;
  int pops = 0;
  Map<String, int> popsBy = {};
  int misses = 0;
  int escapes = 0;
  int bestStreak = 0;
  int bestChain = 0;
  int powersUsed = 0;
  int fevers = 0;
  int coins = 0;
  int timeMs = 0;
  bool won = false;
  String reason = '';
  int lostHearts = 0;
  int tokens = 0;
  int hour = 0;
  int stars = 0;
  String dailyKey = '';
  int target = 0;
}

class ResultLine {
  final String key;
  final int value;
  ResultLine(this.key, this.value);
}

class RunResult {
  int coins = 0;
  int xp = 0;
  List<ResultLine> lines = [];
  bool newBest = false;
  bool newBestTime = false;
  int best = 0;
  bool dailyWin = false;
  int stageReward = 0;
  int newStars = 0;
  int levelBefore = 1;
  int xpBefore = 0;
  List<LevelUp> levelUps = [];
  List<AchDef> ach = [];
}

class AchDef {
  final String id;
  final String tier; // easy · medium · hard · rare
  final int n;
  final int Function(SaveData s)? get;
  final bool Function(RunSummary r)? run;
  final String rewardItem;
  final bool secret;
  final Tx name;
  final Tx desc;
  AchDef(this.id, this.tier, this.name, this.desc, {this.n = 0, this.get, this.run, this.rewardItem = '', this.secret = false});
}

int bestOf(SaveData s, String mode) {
  final b = s.best[mode];
  if (b == null || b.isEmpty) return 0;
  return b.values.fold(0, math.max);
}

int clearedStages(SaveData s) => s.stages.values.where((x) => x.stars > 0).length;
int totalStars(SaveData s) => s.stages.values.fold(0, (a, x) => a + x.stars);

final List<AchDef> achievements = [
  AchDef('pop1', 'easy', Tx('First pop', 'أول فرقعة'), Tx('Pop your first bubble.', 'فرقع أول فقاعة.'), n: 1, get: (s) => s.stats.pops),
  AchDef('pop100', 'easy', Tx('Getting the hang of it', 'بدأت تتقنها'), Tx('Pop 100 bubbles.', 'فرقع 100 فقاعة.'), n: 100, get: (s) => s.stats.pops),
  AchDef('games5', 'easy', Tx('Regular', 'لاعب منتظم'), Tx('Play 5 games.', 'العب 5 جولات.'), n: 5, get: (s) => s.stats.games),
  AchDef('gold10', 'easy', Tx('Shiny!', 'لامع!'), Tx('Pop 10 gold bubbles.', 'فرقع 10 فقاعات ذهبية.'), n: 10,
      get: (s) => s.stats.popsBy['gold'] ?? 0),
  AchDef('bomb1', 'easy', Tx('Kaboom', 'بوووم'), Tx('Pop a bomb bubble.', 'فرقع فقاعة متفجرة.'), n: 1, get: (s) => s.stats.popsBy['bomb'] ?? 0),
  AchDef('power1', 'easy', Tx('Powered up', 'قوة إضافية'), Tx('Use a power.', 'استخدم قدرة.'), n: 1, get: (s) => s.stats.powersUsed),
  AchDef('zen1', 'easy', Tx('Deep breath', 'نفَس عميق'), Tx('Play a Zen session.', 'العب جلسة استرخاء.'), n: 1,
      get: (s) => s.stats.gamesBy['zen'] ?? 0),
  AchDef('daily1', 'easy', Tx('Daily dipper', 'زائر يومي'), Tx('Beat a daily challenge target.', 'حقق هدف تحدٍّ يومي.'), n: 1,
      get: (s) => s.stats.dailyDone),
  AchDef('pop1k', 'medium', Tx('Bubble buster', 'محطّم الفقاعات'), Tx('Pop 1,000 bubbles.', 'فرقع 1000 فقاعة.'), n: 1000,
      get: (s) => s.stats.pops),
  AchDef('streak25', 'medium', Tx('On a roll', 'في أوج التألق'), Tx('Pop 25 in a row.', 'فرقع 25 فقاعة متتالية.'), n: 25,
      get: (s) => s.stats.bestStreak),
  AchDef('classic1k', 'medium', Tx('Classic pro', 'محترف الكلاسيكي'), Tx('Score 1,000 in Classic.', 'اجمع 1000 نقطة في الكلاسيكي.'), n: 1000,
      get: (s) => bestOf(s, 'classic')),
  AchDef('chain8', 'medium', Tx('Chain reaction', 'تفاعل متسلسل'), Tx('Pop 8 bubbles with one bomb chain.', 'فرقع 8 فقاعات بسلسلة تفجير واحدة.'),
      n: 8, get: (s) => s.stats.bestChain),
  AchDef('gold100', 'medium', Tx('Gold digger', 'منقّب الذهب'), Tx('Pop 100 gold bubbles.', 'فرقع 100 فقاعة ذهبية.'), n: 100,
      get: (s) => s.stats.popsBy['gold'] ?? 0),
  AchDef('stage8', 'medium', Tx('Challenger', 'المتحدي'), Tx('Clear 8 challenge stages.', 'اجتز 8 مراحل تحدٍّ.'), n: 8, get: clearedStages),
  AchDef('level5', 'medium', Tx('Rising star', 'نجم صاعد'), Tx('Reach level 5.', 'صل إلى المستوى 5.'), n: 5, get: (s) => s.profile.level),
  AchDef('time500', 'medium', Tx('Speedy', 'سريع'), Tx('Score 500 in Time Rush.', 'اجمع 500 نقطة في سباق الوقت.'), n: 500,
      get: (s) => bestOf(s, 'time')),
  AchDef('quests10', 'medium', Tx('Helpful', 'منجز المهام'), Tx('Complete 10 missions.', 'أكمل 10 مهام.'), n: 10, get: (s) => s.stats.questsDone),
  AchDef('guide', 'medium', Tx('Bubble scholar', 'عالِم الفقاعات'), Tx('Discover every bubble type.', 'اكتشف كل أنواع الفقاعات.'), n: 11,
      get: (s) => s.discovered.where((k) => bubbles[k] != null && !bubbles[k]!.hidden).length),
  AchDef('pop10k', 'hard', Tx('Ten thousand', 'عشرة آلاف'), Tx('Pop 10,000 bubbles.', 'فرقع 10000 فقاعة.'), n: 10000,
      get: (s) => s.stats.pops),
  AchDef('streak60', 'hard', Tx('Unstoppable', 'لا يمكن إيقافك'), Tx('Pop 60 in a row.', 'فرقع 60 فقاعة متتالية.'), n: 60,
      get: (s) => s.stats.bestStreak),
  AchDef('classic3k', 'hard', Tx('Classic legend', 'أسطورة الكلاسيكي'), Tx('Score 3,000 in Classic.', 'اجمع 3000 نقطة في الكلاسيكي.'),
      n: 3000, get: (s) => bestOf(s, 'classic')),
  AchDef('survive120', 'hard', Tx('Survivor', 'الناجي'), Tx('Last 120 seconds in Survival.', 'اصمد 120 ثانية في البقاء.'), n: 120,
      get: (s) => s.survivalTime ~/ 1000),
  AchDef('stage24', 'hard', Tx('Champion', 'البطل'), Tx('Clear all 24 challenge stages.', 'اجتز جميع مراحل التحدي الـ24.'), n: 24,
      get: clearedStages),
  AchDef('level20', 'hard', Tx('Veteran', 'المحارب القديم'), Tx('Reach level 20.', 'صل إلى المستوى 20.'), n: 20, get: (s) => s.profile.level),
  AchDef('time1200', 'hard', Tx('Lightning hands', 'يدان كالبرق'), Tx('Score 1,200 in Time Rush.', 'اجمع 1200 نقطة في سباق الوقت.'), n: 1200,
      get: (s) => bestOf(s, 'time')),
  AchDef('rainbow1', 'rare', Tx('Somewhere over…', 'خلف قوس قزح'), Tx('Pop a rare rainbow bubble.', 'فرقع فقاعة قوس قزح النادرة.'), n: 1,
      get: (s) => s.stats.popsBy['rainbow'] ?? 0, rewardItem: 'fx:prism'),
  AchDef('chain20', 'rare', Tx('Demolition expert', 'خبير الهدم'), Tx('One bomb chain pops 20 bubbles.', 'سلسلة تفجير واحدة تفرقع 20 فقاعة.'),
      n: 20, get: (s) => s.stats.bestChain),
  AchDef('fever3', 'rare', Tx('Fever pitch', 'ذروة الحماس'), Tx('Reach Fever 3 times in one run.', 'ادخل وضع الحماس 3 مرات في جولة واحدة.'),
      run: (r) => r.fevers >= 3),
  AchDef('clean100', 'rare', Tx('Surgeon', 'الجرّاح'),
      Tx('Pop 100 in a Classic run without a single miss.', 'فرقع 100 فقاعة في جولة كلاسيكية دون أي نقرة خاطئة.'),
      run: (r) => r.mode == 'classic' && r.pops >= 100 && r.misses == 0),
  AchDef('streak7', 'rare', Tx('See you tomorrow', 'أراك غدًا'), Tx('Claim the daily gift 7 days in a row.', 'استلم الهدية اليومية 7 أيام متتالية.'),
      n: 7, get: (s) => s.login.best, rewardItem: 'theme:night'),
  AchDef('stars72', 'rare', Tx('Perfectionist', 'الكمال'), Tx('Earn all 72 challenge stars.', 'اجمع كل نجوم التحدي الـ72.'), n: 72,
      get: totalStars),
  AchDef('nightowl', 'rare', Tx('Night owl', 'بومة الليل'), Tx('A secret. Try playing very late…', 'سرّ. جرّب اللعب في وقت متأخر جدًا…'),
      secret: true, run: (r) => r.hour >= 0 && r.hour < 4 && r.pops >= 30),
];

class DailySetup {
  final String key;
  final int seed;
  final List<DailyMod> mods;
  final int target;
  DailySetup(this.key, this.seed, this.mods, this.target);
}

class Prog {
  static SaveData get s => Save.data;
  static List<LevelUp> levelUps = [];
  static List<AchDef> freshAch = [];
  static void Function(ToastData t)? onToast;
  static void Function()? onChange;

  static void _toast(ToastData t) => onToast?.call(t);

  // ---------- xp / coins
  static int need() => xpForLevel(s.profile.level);
  static int addXP(num amount) {
    final n = math.max(0, amount.round());
    final p = s.profile;
    p.xp += n;
    var guard = 0;
    while (p.xp >= xpForLevel(p.level) && guard++ < 100) {
      p.xp -= xpForLevel(p.level);
      p.level += 1;
      final coins = levelRewardCoins(p.level);
      p.coins += coins;
      final unlockModes = modeOrder.where((m) => modes[m]!.unlockLevel == p.level).toList();
      final unlockItems = items.where((i) => i.source == 'shop' && i.minLevel == p.level).map((i) => i.id).toList();
      levelUps.add(LevelUp(p.level, coins, unlockModes, unlockItems));
    }
    Save.dirty();
    return n;
  }

  static int addCoins(num amount, {bool earned = true}) {
    final n = math.max(0, amount.round());
    s.profile.coins += n;
    if (earned) s.stats.coinsEarned += n;
    Save.dirty();
    onChange?.call();
    return n;
  }

  static bool spend(int n) {
    if (s.profile.coins < n) return false;
    s.profile.coins -= n;
    Save.dirty();
    onChange?.call();
    return true;
  }

  // ---------- items
  static bool owns(String id) => s.owned.contains(id);
  static bool grant(String id) {
    if (itemById(id) == null || owns(id)) return false;
    s.owned.add(id);
    Save.dirty();
    return true;
  }

  /// st: owned · buy · locked
  static ({String st, int price, bool can, String why}) status(ItemDef it) {
    if (it.source == 'free' || owns(it.id)) return (st: 'owned', price: 0, can: false, why: '');
    switch (it.source) {
      case 'shop':
        if (s.profile.level < it.minLevel) return (st: 'locked', price: it.price, can: false, why: t('lock.level', {'n': it.minLevel}));
        return (st: 'buy', price: it.price, can: s.profile.coins >= it.price, why: '');
      case 'ach':
        final a = achievements.where((x) => x.id == it.ach);
        return (st: 'locked', price: 0, can: false, why: t('lock.ach', {'name': a.isEmpty ? '?' : a.first.name.s}));
      case 'stars':
        return (st: 'locked', price: 0, can: false, why: t('lock.stars', {'n': it.stars}));
      case 'event':
        final sea = seasons.where((x) => x.id == it.event);
        return (st: 'locked', price: 0, can: false, why: t('lock.event', {'name': sea.isEmpty ? t('event.generic') : sea.first.name.s}));
    }
    return (st: 'locked', price: 0, can: false, why: '');
  }

  static bool buy(String id) {
    final it = itemById(id);
    if (it == null) return false;
    final st = status(it);
    if (st.st != 'buy' || !st.can) return false;
    if (!spend(it.price)) return false;
    grant(id);
    equip(id);
    checkAch();
    return true;
  }

  static bool equip(String id) {
    final it = itemById(id);
    if (it == null || !owns(id)) return false;
    s.equipped[it.kind] = it.key;
    Save.dirty();
    onChange?.call();
    return true;
  }

  static List<ItemDef> checkUnlocks() {
    final out = <ItemDef>[];
    for (final it in items) {
      if (it.source == 'stars' && !owns(it.id) && totalStars(s) >= it.stars) {
        grant(it.id);
        out.add(it);
      }
    }
    for (final it in out) {
      _toast(ToastData(icon: 'gift', title: t('toast.unlocked'), text: it.name.s));
    }
    return out;
  }

  // ---------- upgrades
  static int upg(String id) => s.upgrades[id] ?? 0;
  static bool buyUpgrade(String id) {
    final u = upgrades.where((x) => x.id == id);
    if (u.isEmpty) return false;
    final lv = upg(id);
    if (lv >= u.first.prices.length) return false;
    if (!spend(u.first.prices[lv])) return false;
    s.upgrades[id] = lv + 1;
    Save.dirty();
    return true;
  }

  static bool modeUnlocked(String m) => s.profile.level >= (modes[m]?.unlockLevel ?? 1);

  // ---------- achievements
  static ({int cur, int n})? achProgress(AchDef a) {
    final g = a.get;
    if (g == null) return null;
    var v = 0;
    try {
      v = g(s);
    } catch (_) {
      v = 0;
    }
    return (cur: math.min(v, a.n), n: a.n);
  }

  static List<AchDef> checkAch([RunSummary? r, bool quiet = false]) {
    final got = <AchDef>[];
    for (final a in achievements) {
      if (s.ach.containsKey(a.id)) continue;
      var ok = false;
      try {
        final g = a.get, rf = a.run;
        if (g != null) {
          ok = g(s) >= a.n;
        } else if (rf != null && r != null) {
          ok = rf(r);
        }
      } catch (_) {
        ok = false;
      }
      if (!ok) continue;
      s.ach[a.id] = DateTime.now().millisecondsSinceEpoch;
      s.stats.achDone += 1;
      final rw = tierReward[a.tier] ?? tierReward['easy']!;
      addCoins(rw[0]);
      addXP(rw[1]);
      if (a.rewardItem.isNotEmpty) grant(a.rewardItem);
      got.add(a);
      freshAch.add(a);
      if (!quiet) _toast(ToastData(icon: 'trophy', title: t('toast.ach'), text: a.name.s, sound: 'ach'));
    }
    if (got.isNotEmpty) Save.dirty();
    return got;
  }

  // ---------- missions
  static List<QuestState> makeQuests(List<QuestDef> pool, String key, int count, [List<String> exclude = const []]) {
    final r = Rng(hashStr(key));
    final avail = pool.where((q) => (q.needMode.isEmpty || modeUnlocked(q.needMode)) && !exclude.contains(q.id)).toList();
    return shuffleSeeded(avail, r.next).take(count).map((q) {
      var n = lerpD(q.lo.toDouble(), q.hi.toDouble(), r.next());
      final step = n >= 500 ? 50 : n >= 100 ? 10 : n >= 30 ? 5 : 1;
      n = (n / step).round() * step.toDouble();
      return QuestState(q.id, math.max(1, n.round()));
    }).toList();
  }

  static void ensureQuests() {
    final dk = dayKey(), wk = weekKey();
    var changed = false;
    if (s.qDaily.key != dk || s.qDaily.list.isEmpty) {
      s.qDaily = QuestBook(key: dk, list: makeQuests(questsDaily, 'd$dk', 3));
      changed = true;
    }
    if (s.qWeekly.key != wk || s.qWeekly.list.isEmpty) {
      s.qWeekly = QuestBook(key: wk, list: makeQuests(questsWeekly, 'w$wk', 3));
      changed = true;
    }
    s.qDaily.list.removeWhere((x) => questDef(x.id) == null);
    s.qWeekly.list.removeWhere((x) => questDef(x.id) == null);
    if (changed) Save.dirty();
  }

  static void questEvent(String ev, int value, [String match = '']) {
    ensureQuests();
    for (final list in [s.qDaily.list, s.qWeekly.list]) {
      for (final it in list) {
        if (it.claimed || it.p >= it.n) continue;
        final d = questDef(it.id);
        if (d == null || d.ev != ev) continue;
        if (d.match.isNotEmpty && d.match != match) continue;
        final before = it.p;
        if (d.isMax) {
          it.p = math.max(it.p, value);
        } else {
          it.p += value;
        }
        if (before < it.n && it.p >= it.n) {
          _toast(ToastData(icon: 'target', title: t('toast.quest'), text: t('toast.questClaim'), sound: 'ach'));
        }
      }
    }
    Save.dirty();
  }

  static QuestDef? claimQuest(bool daily, int i) {
    final list = daily ? s.qDaily.list : s.qWeekly.list;
    if (i < 0 || i >= list.length) return null;
    final it = list[i];
    if (it.claimed || it.p < it.n) return null;
    final d = questDef(it.id);
    if (d == null) return null;
    it.claimed = true;
    s.stats.questsDone += 1;
    addCoins(d.coins);
    addXP(d.xp);
    checkAch();
    Save.dirty();
    return d;
  }

  static bool rerollDaily(int i) {
    final q = s.qDaily;
    if (q.rerolled || i < 0 || i >= q.list.length || q.list[i].claimed) return false;
    final ex = q.list.map((x) => x.id).toList();
    final repl = makeQuests(questsDaily, 'r${q.key}$i', 1, ex);
    if (repl.isEmpty) return false;
    q.list[i] = repl.first;
    q.rerolled = true;
    Save.dirty();
    return true;
  }

  static int claimableCount() {
    ensureQuests();
    var n = 0;
    for (final it in [...s.qDaily.list, ...s.qWeekly.list]) {
      if (!it.claimed && it.p >= it.n) n++;
    }
    if (loginAvailable()) n++;
    for (final sea in activeSeasons()) {
      n += seasonClaimable(sea).length;
    }
    return n;
  }

  // ---------- daily gift
  static bool loginAvailable() => s.login.last != dayKey();
  static Gift? claimLogin() {
    final l = s.login;
    final dk = dayKey();
    if (l.last == dk) return null;
    final gap = l.last.isNotEmpty ? daysBetween(l.last, dk) : 99;
    l.streak = gap == 1 ? l.streak + 1 : 1;
    l.best = math.max(l.best, l.streak);
    final gift = loginGifts[l.day % loginGifts.length];
    l.day = (l.day + 1) % loginGifts.length;
    l.last = dk;
    l.total += 1;
    if (gift.coins > 0) addCoins(gift.coins);
    if (gift.xp > 0) addXP(gift.xp);
    checkAch();
    Save.dirty();
    return gift;
  }

  // ---------- seasonal events
  static String? seasonKeyFor(SeasonDef sea, [DateTime? d]) {
    d ??= today();
    final y = d.year;
    final md = '${pad2(d.month)}-${pad2(d.day)}';
    if (sea.dates.isNotEmpty) {
      final r = sea.dates[y];
      return r != null && md.compareTo(r[0]) >= 0 && md.compareTo(r[1]) <= 0 ? '${sea.id}$y' : null;
    }
    if (sea.start.isEmpty || sea.end.isEmpty) return null;
    if (sea.start.compareTo(sea.end) <= 0) {
      return md.compareTo(sea.start) >= 0 && md.compareTo(sea.end) <= 0 ? '${sea.id}$y' : null;
    }
    if (md.compareTo(sea.start) >= 0) return '${sea.id}$y';
    if (md.compareTo(sea.end) <= 0) return '${sea.id}${y - 1}';
    return null;
  }

  static List<SeasonDef> activeSeasons() => seasons.where((x) => seasonKeyFor(x) != null).toList();

  static EventState? seasonState(SeasonDef sea) {
    final k = seasonKeyFor(sea);
    if (k == null) return null;
    return s.events.putIfAbsent(k, () => EventState());
  }

  static int seasonEnds(SeasonDef sea) {
    final d = today();
    for (var i = 0; i < 120; i++) {
      final x = DateTime(d.year, d.month, d.day + i);
      if (seasonKeyFor(sea, x) == null) return i;
    }
    return 120;
  }

  static ({SeasonDef sea, int days})? nextSeason() {
    final d = today();
    for (var i = 1; i < 370; i++) {
      final x = DateTime(d.year, d.month, d.day + i);
      for (final sea in seasons) {
        if (seasonKeyFor(sea, x) != null && seasonKeyFor(sea, d) == null) return (sea: sea, days: i);
      }
    }
    return null;
  }

  static void addEventToken(SeasonDef sea, int n) {
    final st = seasonState(sea);
    if (st == null) return;
    final before = st.n;
    st.n += n;
    for (final tr in sea.tiers) {
      if (before < tr.n && st.n >= tr.n) {
        _toast(ToastData(icon: 'gift', title: sea.name.s, text: t('toast.tierReady'), sound: 'event'));
      }
    }
    Save.dirty();
  }

  static List<int> seasonClaimable(SeasonDef sea) {
    final st = seasonState(sea);
    if (st == null) return const [];
    final out = <int>[];
    for (var i = 0; i < sea.tiers.length; i++) {
      if (st.n >= sea.tiers[i].n && !st.claimed.contains(i)) out.add(i);
    }
    return out;
  }

  static bool claimTier(SeasonDef sea, int i) {
    final st = seasonState(sea);
    if (st == null || i < 0 || i >= sea.tiers.length) return false;
    final tr = sea.tiers[i];
    if (st.claimed.contains(i) || st.n < tr.n) return false;
    st.claimed.add(i);
    if (tr.coins > 0) addCoins(tr.coins);
    if (tr.item.isNotEmpty && !grant(tr.item)) addCoins(300);
    Save.dirty();
    return true;
  }

  // ---------- daily challenge
  static DailySetup dailySetup([String? key]) {
    final dk = key ?? dayKey();
    final r = Rng(hashStr('daily$dk'));
    final mods = shuffleSeeded(dailyMods, r.next).take(2).toList();
    final target = 400 + (r.next() * 5).floor() * 40;
    return DailySetup(dk, hashStr('seed$dk'), mods, target);
  }

  // ---------- live stats from the game
  static void onPop(String type) {
    final st = s.stats;
    st.pops += 1;
    st.popsBy[type] = (st.popsBy[type] ?? 0) + 1;
    questEvent('pop', 1, type);
    checkAch();
  }

  static void onStreak(int n) {
    if (n > s.stats.bestStreak) s.stats.bestStreak = n;
    if (n > 0) questEvent('streak', n);
  }

  static void onChain(int n) {
    if (n > s.stats.bestChain) s.stats.bestChain = n;
    questEvent('chain', n);
    checkAch();
  }

  static void onPower() {
    s.stats.powersUsed += 1;
    questEvent('power', 1);
    checkAch();
  }

  static void onMiss() => s.stats.misses += 1;
  static void onEscape() => s.stats.escapes += 1;

  // ---------- run results
  static RunResult applyRun(RunSummary r) {
    final st = s.stats;
    final mode = modes[r.mode]!;
    final out = RunResult();
    st.games += 1;
    st.gamesBy[r.mode] = (st.gamesBy[r.mode] ?? 0) + 1;
    st.playMs += r.timeMs;
    st.fevers += r.fevers;

    final dk = r.diff;
    if (r.mode == 'classic' || r.mode == 'time' || r.mode == 'survival') {
      final table = s.best.putIfAbsent(r.mode, () => {});
      final prev = table[dk] ?? 0;
      out.best = math.max(prev, r.score);
      if (r.score > prev) {
        table[dk] = r.score;
        out.newBest = prev > 0 || r.score > 0;
      }
      if (r.mode == 'survival' && r.timeMs > s.survivalTime) {
        s.survivalTime = r.timeMs;
        out.newBestTime = true;
      }
    } else if (r.mode == 'zen') {
      final prev = s.zenPops;
      if (r.pops > prev) {
        s.zenPops = r.pops;
        out.newBest = true;
      }
      out.best = math.max(prev, r.pops);
    } else if (r.mode == 'daily') {
      if (s.daily.key != r.dailyKey) s.daily = DailyState(key: r.dailyKey, history: s.daily.history);
      final prev = s.daily.best;
      if (r.score > prev) {
        s.daily.best = r.score;
        out.newBest = true;
      }
      out.best = math.max(prev, r.score);
      final h = s.daily.history.where((x) => x.d == r.dailyKey);
      if (h.isNotEmpty) {
        h.first.s = math.max(h.first.s, r.score);
        h.first.w = h.first.w || r.score >= r.target;
      } else {
        s.daily.history.add(DailyHist(r.dailyKey, r.score, r.score >= r.target));
      }
      if (s.daily.history.length > 14) s.daily.history = s.daily.history.sublist(s.daily.history.length - 14);
      if (r.score >= r.target && !s.daily.done) {
        s.daily.done = true;
        st.dailyDone += 1;
        out.dailyWin = true;
        questEvent('daily', 1);
      }
    }

    if (r.mode == 'challenge' && r.won) {
      final prev = s.stages[r.stage] ?? StageRec(0, 0);
      final newStars = math.max(0, r.stars - prev.stars);
      if (prev.stars == 0) out.stageReward += 60 + r.stage * 8;
      out.stageReward += newStars * 25;
      s.stages[r.stage] = StageRec(math.max(prev.stars, r.stars), math.max(prev.best, r.score));
      out.newStars = newStars;
      if (r.stage >= s.lastStage) s.lastStage = math.min(stages.length, r.stage + 1);
      questEvent('stage', 1);
      if (newStars > 0) questEvent('stars', newStars);
    }

    final diffMul = (mode.difficulty ? (difficulty[dk]?.reward ?? 1) : 1) * mode.rewardMul;
    final coinMul = mode.noUpgrades ? 1 : 1 + 0.1 * upg('coinBoost');
    var coins = (r.score * Bal.coinsPerScore + r.coins) * diffMul * coinMul;
    var xp = (r.score * Bal.xpPerScore + r.pops * Bal.xpPerPop) * diffMul;
    if (r.mode == 'zen') {
      coins = math.min(coins, Bal.zenCapCoins.toDouble());
      xp = math.min(xp, Bal.zenCapXp.toDouble());
    }
    if (r.mode == 'challenge' && r.won) xp += 40 + r.stage * 4;
    var coinsI = coins.round();
    var xpI = xp.round();
    out.lines.add(ResultLine('res.runCoins', coinsI));
    if (out.stageReward > 0) out.lines.add(ResultLine('res.stageBonus', out.stageReward));
    if (out.dailyWin) {
      out.lines.add(ResultLine('res.dailyBonus', 150));
      coinsI += 150;
      xpI += 120;
    }
    coinsI += out.stageReward;
    out.coins = addCoins(coinsI);
    out.levelBefore = s.profile.level;
    out.xpBefore = s.profile.xp;
    out.xp = addXP(xpI);

    questEvent('game', 1);
    if (r.mode != 'zen') questEvent('score', r.score, r.mode);
    checkAch(r, true);
    checkUnlocks();
    out.levelUps = List.of(levelUps);
    levelUps = [];
    out.ach = List.of(freshAch);
    freshAch = [];
    Save.flush();
    return out;
  }
}
