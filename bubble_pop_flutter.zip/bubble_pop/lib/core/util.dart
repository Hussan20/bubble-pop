// Pure-Dart helpers shared by the game logic (no Flutter imports here).
import 'dart:math' as math;

const double tau = math.pi * 2;

double clampD(double v, double a, double b) => v < a ? a : (v > b ? b : v);
int clampI(int v, int a, int b) => v < a ? a : (v > b ? b : v);
double lerpD(double a, double b, double t) => a + (b - a) * t;
double easeOut(double p) => 1 - math.pow(1 - p, 3).toDouble();
double easeOutBack(double p) =>
    1 + 2.70158 * math.pow(p - 1, 3).toDouble() + 1.70158 * math.pow(p - 1, 2).toDouble();
double hypot(double x, double y) => math.sqrt(x * x + y * y);

/// 1234567 -> "1,234,567"
String fmt(num n) {
  final v = n.round();
  final s = v.abs().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return (v < 0 ? '-' : '') + b.toString();
}

String pad2(int n) => n.toString().padLeft(2, '0');

int _imul(int a, int b) => ((a & 0xFFFFFFFF) * (b & 0xFFFFFFFF)) & 0xFFFFFFFF;

/// FNV-1a 32-bit
int hashStr(String s) {
  var h = 2166136261;
  for (final c in s.codeUnits) {
    h = (h ^ c) & 0xFFFFFFFF;
    h = _imul(h, 16777619);
  }
  return h & 0xFFFFFFFF;
}

/// Seeded generator (mulberry32) used by the daily challenge and missions.
class Rng {
  int _a;
  Rng(int seed) : _a = seed & 0xFFFFFFFF;
  double next() {
    _a = (_a + 0x6D2B79F5) & 0xFFFFFFFF;
    var t = _imul(_a ^ (_a >> 15), 1 | _a);
    t = ((t + _imul(t ^ (t >> 7), 61 | t)) & 0xFFFFFFFF) ^ t;
    return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296.0;
  }
}

final math.Random _cosmetic = math.Random();

/// Gameplay randomness: swapped for a seeded generator in the daily challenge.
double Function() srng = _cosmetic.nextDouble;
void useSeed(int? seed) {
  if (seed == null) {
    srng = _cosmetic.nextDouble;
  } else {
    final r = Rng(seed);
    srng = r.next;
  }
}

double rnd(double a, double b) => a + srng() * (b - a);

/// Cosmetic randomness (particles) never touches the seeded stream.
double frand(double a, double b) => a + _cosmetic.nextDouble() * (b - a);
int irand(int n) => _cosmetic.nextInt(n);

T? pickWeighted<T>(List<MapEntry<T, double>> entries, [double Function()? r]) {
  var total = 0.0;
  for (final e in entries) {
    total += math.max(0, e.value);
  }
  if (entries.isEmpty) return null;
  if (total <= 0) return entries.first.key;
  var x = (r ?? srng)() * total;
  for (final e in entries) {
    x -= math.max(0, e.value);
    if (x <= 0) return e.key;
  }
  return entries.last.key;
}

List<T> shuffleSeeded<T>(List<T> arr, double Function() r) {
  final a = List<T>.of(arr);
  for (var i = a.length - 1; i > 0; i--) {
    final j = (r() * (i + 1)).floor();
    final t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}

// ---------- dates (local device time) ----------
DateTime today() => DateTime.now();

String dayKey([DateTime? d]) {
  d ??= today();
  return '${d.year}-${pad2(d.month)}-${pad2(d.day)}';
}

/// ISO week key, e.g. 2026-W43
String weekKey([DateTime? d]) {
  d ??= today();
  var t = DateTime.utc(d.year, d.month, d.day);
  final day = t.weekday; // Mon=1..Sun=7
  t = t.add(Duration(days: 4 - day));
  final y = t.year;
  final start = DateTime.utc(y, 1, 1);
  final w = ((t.difference(start).inDays + 1) / 7).ceil();
  return '$y-W${pad2(w)}';
}

DateTime keyToDate(String k) {
  final p = k.split('-');
  if (p.length != 3) return DateTime.utc(2000);
  return DateTime.utc(int.tryParse(p[0]) ?? 2000, int.tryParse(p[1]) ?? 1, int.tryParse(p[2]) ?? 1);
}

int daysBetween(String k1, String k2) => keyToDate(k2).difference(keyToDate(k1)).inHours ~/ 24;

int msUntilMidnight() {
  final n = DateTime.now();
  final m = DateTime(n.year, n.month, n.day + 1);
  return m.difference(n).inMilliseconds;
}

int msUntilWeekEnd() {
  final n = DateTime.now();
  final m = DateTime(n.year, n.month, n.day + (8 - n.weekday));
  return m.difference(n).inMilliseconds;
}

String fmtTime(num ms) {
  final s = math.max(0, (ms / 1000).ceil());
  return '${s ~/ 60}:${pad2(s % 60)}';
}
