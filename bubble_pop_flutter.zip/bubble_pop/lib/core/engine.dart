// GAME ENGINE — run state, spawning, physics, scoring, powers, modes and
// the particle/text effects. Pure Dart: the UI reads this state and draws it.
// The world is 360 units wide; its height follows the play area's shape.
import 'dart:math' as math;

import 'content.dart';
import 'progress.dart';
import 'save.dart';
import 'strings.dart';
import 'util.dart';

const double worldW = 360;

/// Set from the motion setting / system "remove animations".
bool reduceMotion = false;

/// HSL (h in degrees, s/l in 0..1) to ARGB int.
int hsla(double h, double s, double l, [double a = 1]) {
  h = ((h % 360) + 360) % 360;
  final c = (1 - (2 * l - 1).abs()) * s;
  final x = c * (1 - ((h / 60) % 2 - 1).abs());
  final m = l - c / 2;
  double r = 0, g = 0, b = 0;
  if (h < 60) {
    r = c;
    g = x;
  } else if (h < 120) {
    r = x;
    g = c;
  } else if (h < 180) {
    g = c;
    b = x;
  } else if (h < 240) {
    g = x;
    b = c;
  } else if (h < 300) {
    r = x;
    b = c;
  } else {
    r = c;
    b = x;
  }
  int ch(double v) => clampI(((v + m) * 255).round(), 0, 255);
  return (clampI((a * 255).round(), 0, 255) << 24) | (ch(r) << 16) | (ch(g) << 8) | ch(b);
}

// ---------------------------------------------------------------- entities
class Chain {
  int count = 0;
  int pending = 0;
  final bool blast;
  bool done = false;
  Chain({this.blast = false});
}

class Bubble {
  final String type;
  double baseX;
  double x;
  double y;
  double r;
  double vy;
  final double wa;
  final double wf;
  final double phase;
  final double hue;
  final double born;
  double age = 0;
  int hp;
  final int maxHp;
  double hitAt = -9999;
  final bool deco;
  bool dead = false;
  double sched = 0;
  Chain? chain;
  String chainSrc = 'bomb';
  double endAt = 0;
  double vx;
  final String power;
  final SeasonDef? season;
  final bool harmless;
  bool highlight = false;
  Bubble({
    required this.type,
    required this.baseX,
    required this.y,
    required this.r,
    required this.vy,
    required this.wa,
    required this.wf,
    required this.phase,
    required this.hue,
    required this.born,
    required this.hp,
    this.deco = false,
    this.vx = 0,
    this.power = '',
    this.season,
    this.harmless = false,
  })  : x = baseX,
        maxHp = hp;
}

enum PKind { dot, rect, star, heart, line, shard, flake }

class Particle {
  double x, y, vx, vy, s, life, g, rot, vr;
  int color;
  double age = 0;
  PKind kind;
  bool twinkle;
  Particle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.s,
    required this.color,
    required this.life,
    this.g = 0,
    this.kind = PKind.dot,
    this.rot = 0,
    this.vr = 0,
    this.twinkle = false,
  });
}

class Ring {
  final double x, y, r, grow, life, w;
  final int color;
  double age = 0;
  Ring(this.x, this.y, this.r, this.grow, this.color, this.life, this.w);
}

class FloatText {
  final double x, y, size, life, rise;
  final String text;
  final int color;
  final bool coin;
  double age = 0;
  FloatText(this.x, this.y, this.text, this.color, this.size, this.life, this.rise, {this.coin = false});
}

class Banner {
  final String text;
  final String kind; // praise · fever · power · event
  final double life;
  double age = 0;
  Banner(this.text, this.kind, this.life);
}

const List<int> _confetti = [0xFFFF5C8A, 0xFFFFC928, 0xFF3BD38A, 0xFF1FB0D6, 0xFF8E6CF2];
const List<int> _fireworks = [0xFFFF5C8A, 0xFFFFC928, 0xFF3BD38A, 0xFF5FD8F5];

// ---------------------------------------------------------------- effects
class Fx {
  final Engine e;
  Fx(this.e);
  final List<Particle> particles = [];
  final List<Ring> rings = [];
  final List<FloatText> texts = [];
  Banner? cur;
  double frostAt = -9999, shockAt = -9999, flashAt = -9999, flashX = 0, flashY = 0;
  int flashCol = 0xFFFFBE5A;
  static const int maxParticles = 450;

  ThemeDef get c => e.theme;

  void clear() {
    particles.clear();
    rings.clear();
    texts.clear();
    cur = null;
  }

  void add(Particle p) {
    if (particles.length < maxParticles) particles.add(p);
  }

  void ring(double x, double y, double r, double grow, int color, double life, [double w = 2.5]) {
    if (rings.length < 80) rings.add(Ring(x, y, r, grow, color, life, w));
  }

  void text(double x, double y, String s, int color, double size, double life, {double rise = -26, bool big = false}) {
    if (texts.length > 40) texts.removeAt(0);
    texts.add(FloatText(big ? x : clampD(x, 36, worldW - 36), clampD(y, 16, e.H - 16), s, color, size, life, rise));
  }

  void coinText(double x, double y, int n) {
    texts.add(FloatText(clampD(x, 36, worldW - 36), clampD(y, 16, e.H - 16), '+$n', c.goldEdge, 14, 800, -18, coin: true));
  }

  void banner(String s, String kind) => cur = Banner(s, kind, kind == 'fever' ? 1700 : 1400);

  void pop(Bubble b, bool strong) {
    final style = strong ? Save.data.fx : 'splash';
    final n = reduceMotion ? 5 : (strong ? 12 : 6);
    List<int>? special;
    switch (b.type) {
      case 'gold':
        special = [c.goldEdge, c.lemon, c.shine];
        break;
      case 'bomb':
        special = const [0xFFFF8A3D, 0xFFFFD23F, 0xFF3B3F5C];
        break;
      case 'ice':
        special = const [0xFFBDEBFF, 0xFFFFFFFF, 0xFF6FC3E8];
        break;
      case 'tough':
        special = [0xFF8C9BB0, 0xFFCBD5E1, c.bubbleEdge];
        break;
      case 'rainbow':
        special = _confetti;
        break;
    }
    final cols = special ?? [c.bubbleEdge, c.pink, c.cyan, c.lemon];
    final x = b.x, y = b.y, r = b.r;
    for (var k = 0; k < n; k++) {
      final a = (k / n) * tau + frand(-0.25, 0.25);
      final sp = frand(0.05, 0.15) * (strong ? 1 : 0.7);
      final p = Particle(
        x: x + math.cos(a) * r * 0.85,
        y: y + math.sin(a) * r * 0.85,
        vx: math.cos(a) * sp,
        vy: math.sin(a) * sp,
        s: frand(1.6, 3.4),
        color: cols[k % cols.length],
        life: frand(320, 560),
        g: 0.00022,
        rot: frand(0, tau),
        vr: frand(-0.01, 0.01),
      );
      switch (style) {
        case 'confetti':
          p
            ..kind = PKind.rect
            ..s = frand(2.5, 4.5)
            ..g = 0.00035
            ..life = frand(600, 900)
            ..color = _confetti[k % 5];
          break;
        case 'stars':
          p
            ..kind = PKind.star
            ..s = frand(3, 5)
            ..g = 0.00012
            ..color = k.isOdd ? 0xFFFFC928 : c.shine
            ..life = frand(500, 750);
          break;
        case 'hearts':
          p
            ..kind = PKind.heart
            ..s = frand(3, 5)
            ..g = -0.00012
            ..vy = p.vy - 0.04
            ..color = k.isOdd ? 0xFFFF5C8A : 0xFFFF9CC0
            ..life = frand(600, 850);
          break;
        case 'fireworks':
          p
            ..kind = PKind.line
            ..vx = p.vx * 1.8
            ..vy = p.vy * 1.8
            ..s = frand(1.5, 2.4)
            ..g = 0.00015
            ..color = _fireworks[k % 4]
            ..life = frand(450, 650);
          break;
        case 'prism':
          p
            ..kind = PKind.shard
            ..s = frand(3, 5.5)
            ..color = hsla((k / n) * 360, 0.9, 0.62)
            ..life = frand(500, 800);
          break;
        case 'snow':
          p
            ..kind = PKind.flake
            ..s = frand(3, 5)
            ..g = 0.00006
            ..color = k.isOdd ? 0xFFFFFFFF : 0xFFBDEBFF
            ..life = frand(700, 1000)
            ..vx = p.vx * 0.6
            ..vy = p.vy * 0.6;
          break;
      }
      add(p);
    }
    if (style == 'fireworks' && strong && !reduceMotion) {
      for (var k = 0; k < 6; k++) {
        add(Particle(
            x: x, y: y, vx: frand(-0.04, 0.04), vy: frand(-0.04, 0.04), s: 1.6, color: c.shine, life: frand(700, 1000), g: 0.0001, twinkle: true));
      }
    }
    ring(x, y, r, r * 0.6, b.type == 'gold' ? c.goldEdge : c.bubbleEdge, 240, 2.5);
  }

  void chips(Bubble b) {
    for (var k = 0; k < 5; k++) {
      final a = frand(0, tau);
      add(Particle(
          x: b.x + math.cos(a) * b.r,
          y: b.y + math.sin(a) * b.r,
          vx: math.cos(a) * 0.08,
          vy: math.sin(a) * 0.08 - 0.03,
          s: frand(2, 3.4),
          color: 0xFF8C9BB0,
          life: 420,
          g: 0.0004,
          kind: PKind.shard,
          rot: frand(0, tau),
          vr: frand(-0.02, 0.02)));
    }
    ring(b.x, b.y, b.r, 6, 0xFF8C9BB0, 200, 2);
  }

  void spiky(Bubble b) {
    for (var k = 0; k < 12; k++) {
      final a = (k / 12) * tau;
      add(Particle(
          x: b.x,
          y: b.y,
          vx: math.cos(a) * 0.14,
          vy: math.sin(a) * 0.14,
          s: frand(3, 4.5),
          color: k.isOdd ? 0xFF8E4FD8 : 0xFFC9A2FF,
          life: 500,
          g: 0.0002,
          kind: PKind.shard,
          rot: a,
          vr: 0.01));
    }
    ring(b.x, b.y, b.r, b.r, 0xFF8E4FD8, 320, 4);
    flashAt = e.clock;
    flashX = b.x;
    flashY = b.y;
    flashCol = 0xFF8E4FD8;
  }

  void explosion(Bubble b, double radius) {
    final n = reduceMotion ? 8 : 22;
    const cols = [0xFFFF8A3D, 0xFFFFD23F, 0xFFFF5C5C, 0xFFFFF3B0];
    for (var k = 0; k < n; k++) {
      final a = frand(0, tau), sp = frand(0.08, 0.26);
      add(Particle(
          x: b.x, y: b.y, vx: math.cos(a) * sp, vy: math.sin(a) * sp, s: frand(2, 4.5), color: cols[k % 4], life: frand(400, 700), g: 0.0002));
    }
    ring(b.x, b.y, b.r, radius, 0xFFFF8A3D, 420, 5);
    ring(b.x, b.y, b.r * 0.5, radius * 0.7, 0xFFFFD23F, 320, 3);
    flashAt = e.clock;
    flashX = b.x;
    flashY = b.y;
    flashCol = 0xFFFFBE5A;
  }

  void rainbowBurst(Bubble b) {
    for (var k = 0; k < 6; k++) {
      ring(b.x, b.y, b.r + k * 3, 40 + k * 12.0, hsla(k * 60.0, 0.9, 0.6), 500 + k * 60.0, 3);
    }
  }

  void update(double dt) {
    final damp = math.pow(0.93, dt / 16.7).toDouble();
    particles.removeWhere((q) {
      q.age += dt;
      if (q.age >= q.life) return true;
      q.vx *= damp;
      q.vy = q.vy * damp + q.g * dt;
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      if (q.vr != 0) q.rot += q.vr * dt;
      return false;
    });
    rings.removeWhere((x) => (x.age += dt) >= x.life);
    texts.removeWhere((x) => (x.age += dt) >= x.life);
    final b = cur;
    if (b != null) {
      b.age += dt;
      if (b.age >= b.life) cur = null;
    }
  }
}

// ---------------------------------------------------------------- run config & state
class RunCfg {
  String mode = 'classic';
  int lives = 0;
  int maxLives = 0;
  int time = 0;
  bool hazards = false;
  bool events = false;
  bool powers = false;
  bool missPenalty = false;
  bool noFail = false;
  bool heartBubbles = true;
  Curve spawn = const Curve(800, 800, 1);
  Curve speed = const Curve(0.1, 0.1, 1);
  SizeCurve size = const SizeCurve(21, 32, 17, 27, 60);
  Map<String, W> weights = {};
  double ptsMul = 1, speedMul = 1, spawnMul = 1, sizeMul = 1;
  List<double> powerEvery = List.of(Bal.powerEvery);
  double powerTimeMul = 1;
  int headStart = 0;
  List<Goal> goals = const [];
  List<String> rules = const [];
  bool seasonBubbles = true;
}

class RunState {
  int score = 0, lives = 0, maxLives = 0, streak = 0, mult = 1, bestStreak = 0, bestChain = 0;
  int pops = 0, misses = 0, escapes = 0, coins = 0, fevers = 0, powersUsed = 0, lostHearts = 0, tokens = 0;
  Map<String, int> popsBy = {};
  double timeLeft = 0, timeTotal = 0, grace = 0;
  Map<String, int> powers = {'slow': 0, 'blast': 0, 'magnet': 0, 'shield': 0};
  Map<String, double> active = {'slow': 0, 'magnet': 0, 'shield': 0};
  Map<String, double> activeDur = {};
  double frozenUntil = 0, feverUntil = 0, reliefUntil = 0, runEventUntil = 0;
  String? runEvent;
  double nextSpawn = 0, nextPower = 0, nextEvent = 0, drizzleNext = 0;
  String failed = '';
  bool won = false;
  SeasonDef? season;
}

/// What the engine needs from the app (sound, vibration, HUD refreshes…).
abstract class GameHooks {
  void sfx(String id, {int arg = 0});
  void haptic(int ms);
  void hud({bool bump = false, bool gainHeart = false});
  void hurt(bool shake);
  void powerGained(String id);
  void music(String mood);
  void toast(ToastData t);
  void showResults(RunSummary r, RunResult res);
}

enum GState { idle, playing, paused, ending }

class Engine {
  final GameHooks hooks;
  Engine(this.hooks) {
    fx = Fx(this);
  }

  late final Fx fx;
  ThemeDef theme = themes['bath']!;
  double H = 560;
  double speedScale = 1;
  GState state = GState.idle;
  String mode = 'classic';
  RunCfg? cfg;
  StageDef? stage;
  DailySetup? daily;
  String diff = 'normal';
  double clock = 0, run = 0, wclock = 0;
  final List<Bubble> bubs = [];
  double pointerX = 0, pointerY = 0, pointerUntil = 0;
  bool pointerActive = false;
  double shake = 0;
  RunState? r;
  double decoNext = 0;
  bool feverMusic = false;
  double resultsAt = 0;
  RunSummary? _pendR;
  RunResult? _pendRes;

  bool get inRun => state == GState.playing || state == GState.paused;

  /// The play area is [w] x [h] logical pixels.
  void setSize(double w, double h) {
    if (w <= 0 || h <= 0) return;
    H = math.max(300.0, worldW * h / w);
    // taller screens get proportionally faster bubbles so the travel time
    // (and the game's balance) matches the original square-ish tub
    speedScale = clampD(H / 440, 0.85, 1.9);
  }

  // ---------- config
  RunCfg buildConfig(String m, StageDef? st, DailySetup? dl, String df) {
    final base = modes[m]!;
    final c = RunCfg()
      ..mode = m
      ..lives = base.lives
      ..maxLives = base.maxLives > 0 ? base.maxLives : base.lives
      ..time = base.time
      ..hazards = base.hazards
      ..events = base.events
      ..powers = base.powers
      ..missPenalty = base.missPenalty
      ..noFail = base.noFail
      ..heartBubbles = base.heartBubbles
      ..spawn = base.spawn ?? const Curve(800, 800, 1)
      ..speed = base.speed ?? const Curve(0.1, 0.1, 1)
      ..size = base.size ?? const SizeCurve(21, 32, 17, 27, 60)
      ..weights = Map.of(base.weights)
      ..seasonBubbles = m != 'challenge';
    if (m == 'challenge' && st != null) {
      var ramp = st.time.toDouble();
      if (ramp <= 0) {
        ramp = 60;
        for (final g in st.goals) {
          if (g.k == 'survive') ramp = g.n.toDouble();
        }
      }
      c
        ..lives = st.lives
        ..maxLives = st.lives
        ..time = st.time
        ..spawn = Curve(st.spawn * 1.18, st.spawn * 0.82, ramp)
        ..speed = Curve(st.speed * 0.85, st.speed * 1.18, ramp)
        ..size = SizeCurve(21, 32, 17, 27, ramp)
        ..weights = {for (final e in st.weights.entries) e.key: W.n(e.value)}
        ..hazards = (st.weights['spiky'] ?? 0) > 0
        ..heartBubbles = false
        ..goals = st.goals
        ..rules = st.rules;
      if (st.powerEvery > 0) c.powerEvery = [st.powerEvery, st.powerEvery + 3];
    }
    if (m == 'daily' && dl != null) {
      for (final md in dl.mods) {
        md.weights.forEach((k, f) {
          final w = c.weights[k];
          c.weights[k] = w != null ? w.times(f) : W.n(4 * f);
        });
        c.sizeMul *= md.size;
        c.ptsMul *= md.pts;
        c.speedMul *= md.speed;
        c.spawnMul *= md.spawn;
        if (md.noPowers) c.powers = false;
      }
    }
    if (base.difficulty) {
      final d = difficulty[df] ?? difficulty['normal']!;
      c.speedMul *= d.speed;
      c.spawnMul *= d.spawn;
    }
    if (!base.noUpgrades) {
      final gl = Prog.upg('goldLuck');
      final gw = c.weights['gold'];
      if (gl > 0 && gw != null) c.weights['gold'] = gw.times(1 + 0.15 * gl);
      final lk = Prog.upg('lucky');
      c.powerEvery = c.powerEvery.map((v) => v / (1 + 0.12 * lk)).toList();
      c.powerTimeMul = 1 + 0.15 * Prog.upg('powerTime');
      c.headStart = Prog.upg('headStart');
    }
    return c;
  }

  // ---------- run control
  void start(String m, {int stageId = 1}) {
    final s = Save.data;
    mode = m;
    diff = modes[m]!.difficulty ? s.settings.difficulty : 'normal';
    stage = m == 'challenge' ? stages[clampI(stageId, 1, stages.length) - 1] : null;
    daily = m == 'daily' ? Prog.dailySetup() : null;
    final c = cfg = buildConfig(m, stage, daily, diff);
    useSeed(daily?.seed);
    final rs = r = RunState();
    rs.lives = c.lives;
    rs.maxLives = c.maxLives;
    rs.timeLeft = rs.timeTotal = c.time * 1000.0;
    final act = Prog.activeSeasons();
    rs.season = c.seasonBubbles && act.isNotEmpty ? act.first : null;
    // clear the decorative bubbles with a little ripple
    final live = bubs.where((b) => !b.dead).toList()..sort((a, b) => a.y.compareTo(b.y));
    for (var i = 0; i < live.length; i++) {
      live[i].endAt = clock + 1 + i * 35;
    }
    run = 0;
    wclock = 0;
    rs.nextSpawn = 450;
    rs.nextPower = rnd(c.powerEvery[0], c.powerEvery[1]) * 1000;
    rs.nextEvent = rnd(Bal.eventFirst[0], Bal.eventFirst[1]) * 1000;
    if (c.powers && c.headStart > 0) {
      final ids = powers.keys.toList();
      for (var i = 0; i < c.headStart; i++) {
        final id = ids[irand(ids.length)];
        rs.powers[id] = (rs.powers[id] ?? 0) + 1;
      }
    }
    s.lastMode = m;
    final st = stage;
    if (st != null) s.lastStage = math.max(1, st.id);
    Save.dirty();
    state = GState.playing;
    feverMusic = false;
    fx.clear();
    hooks.music(modes[m]!.music == 'zen' ? 'zen' : 'play');
  }

  void pause() {
    if (state == GState.playing) state = GState.paused;
  }

  void resume() {
    if (state != GState.paused) return;
    state = GState.playing;
    r?.grace = 900; // a short 3-2-1 so resuming never costs a heart
  }

  void quit() {
    if (inRun) end('quit', false);
  }

  void toIdle() {
    state = GState.idle;
    r = null;
    cfg = null;
    useSeed(null);
  }

  // ---------- spawning
  String pickType(double ts) {
    final c = cfg!, rs = r!;
    final ent = <MapEntry<String, double>>[];
    c.weights.forEach((k, spec) {
      var w = spec.at(ts);
      if (w <= 0 || !bubbles.containsKey(k)) return;
      if (k == 'spiky' && !c.hazards) return;
      if (k == 'heart' && (!c.heartBubbles || rs.maxLives <= 0 || rs.lives >= rs.maxLives)) return;
      if (k == 'clock' && c.time <= 0) return;
      if (k == 'gold' && rs.runEvent == 'goldRush') w *= 6;
      ent.add(MapEntry(k, w));
    });
    if (rs.season != null && c.seasonBubbles) ent.add(const MapEntry('event', 3.2));
    return pickWeighted(ent) ?? 'normal';
  }

  Bubble spawn(String type,
      {double? x, double? y, double? rad, double? vy, double vx = 0, bool deco = false, String power = '', bool harmless = false}) {
    final c = cfg;
    final def = bubbles[type]!;
    final ts = run / 1000;
    final sz = c != null ? c.size.at(ts) : const [16.0, 30.0];
    var rr = rnd(sz[0], sz[1]) * def.rMul * (c?.sizeMul ?? 1);
    var v = (c != null ? c.speed.at(ts) * c.speedMul : 0.04) * rnd(0.85, 1.2) * def.speedMul;
    if (rad != null) rr = rad;
    if (vy != null) v = vy;
    v *= speedScale;
    if (r?.runEvent == 'calm') v *= 0.75;
    final wa = rnd(4, 13), wf = rnd(0.0015, 0.003);
    final margin = rr + wa + 4;
    var bx = x ?? rnd(margin, worldW - margin);
    if (x == null) {
      for (var tries = 0; tries < 8; tries++) {
        final clash = bubs.any((b) => !b.dead && b.y > H - 100 && (b.baseX - bx).abs() < b.r + rr + 8);
        if (!clash) break;
        bx = rnd(margin, worldW - margin);
      }
    }
    final b = Bubble(
      type: type,
      baseX: bx,
      y: y ?? H + rr + 2,
      r: rr,
      vy: v,
      wa: wa,
      wf: wf,
      phase: frand(0, tau),
      hue: frand(0, tau),
      born: clock,
      hp: def.hp,
      deco: deco,
      vx: vx,
      power: power,
      season: type == 'event' ? r?.season : null,
      harmless: harmless,
    );
    bubs.add(b);
    if (!deco) discover(b);
    return b;
  }

  void discover(Bubble b) {
    final s = Save.data;
    final def = bubbles[b.type]!;
    if (s.discovered.contains(b.type) || def.hidden) return;
    s.discovered.add(b.type);
    Save.dirty();
    if (!s.tips.contains(b.type) && b.type != 'normal') {
      s.tips.add(b.type);
      b.highlight = true;
      hooks.toast(ToastData(bubble: b.type, title: t('tip.new', {'name': def.name.s}), text: def.desc.s, tip: true, ms: 4200));
    }
  }

  void spawnPowerBubble() {
    final ids = powers.keys.toList();
    final b = spawn('power', power: ids[clampI((srng() * ids.length).floor(), 0, ids.length - 1)]);
    if (!Save.data.tips.contains('power')) {
      Save.data.tips.add('power');
      b.highlight = true;
    }
  }

  void startRunEvent() {
    final rs = r!, c = cfg!;
    final id = pickWeighted(runEvents.map((e) => MapEntry(e.id, e.w)).toList()) ?? 'wave';
    final def = runEvents.firstWhere((e) => e.id == id);
    rs.runEvent = id;
    rs.runEventUntil = run + def.duration;
    fx.banner(def.name.s, 'event');
    hooks.sfx('event');
    if (id == 'wave') {
      const n = 7;
      const gap = (worldW - 60) / (n - 1);
      for (var i = 0; i < n; i++) {
        spawn(i == 3 ? 'gold' : 'normal',
            x: 30 + i * gap, y: H + 24 + (i - 3).abs() * 16, rad: 20, vy: c.speed.at(run / 1000) * c.speedMul * 0.9);
      }
      rs.runEvent = null;
    } else if (id == 'rainbow') {
      spawn('rainbow');
      rs.runEvent = null;
    }
  }

  // ---------- update
  void update(double dt) {
    clock += dt;
    if (shake > 0) shake = math.max(0.0, shake - dt * 0.03);
    if (state == GState.ending && clock >= resultsAt) {
      final pr = _pendR, pres = _pendRes;
      state = GState.idle;
      useSeed(null);
      _pendR = null;
      _pendRes = null;
      if (pr != null && pres != null) hooks.showResults(pr, pres);
    }
    final playing = state == GState.playing;
    final rs = r;
    var wdt = 0.0;

    if (playing && rs != null) {
      if (rs.grace > 0) {
        rs.grace -= dt; // the run clock stays frozen during the resume countdown
        fx.update(dt);
        return;
      }
      run += dt;
      final frozen = run < rs.frozenUntil;
      final slow = run < (rs.active['slow'] ?? 0);
      wdt = dt * (frozen ? 0.1 : 1) * (slow ? 0.42 : 1);
      wclock += wdt;
      if (rs.runEvent != null && rs.runEventUntil > 0 && run >= rs.runEventUntil) rs.runEvent = null;
      if (cfg!.time > 0) {
        rs.timeLeft -= dt;
        if (rs.timeLeft <= 0) {
          rs.timeLeft = 0;
          timeUp();
        }
      }
      if (state == GState.playing) spawnTick();
      if (state == GState.playing && mode == 'challenge') checkGoals();
    } else if (state == GState.idle) {
      wdt = dt;
      wclock += dt;
      if (wclock >= decoNext) {
        spawn(frand(0, 1) < 0.06 ? 'gold' : 'normal', deco: true, rad: frand(14, 30), vy: frand(0.028, 0.05));
        decoNext = wclock + frand(700, 1300);
      }
    } else if (state == GState.ending) {
      wdt = dt * 0.6;
    }

    final magnetOn = playing && rs != null && run < (rs.active['magnet'] ?? 0) && (pointerActive || clock < pointerUntil);
    // index loop: pops can spawn new bubbles (splitters) while we iterate
    for (var i = 0; i < bubs.length; i++) {
      final b = bubs[i];
      if (b.dead) continue;
      if (b.endAt > 0 && clock >= b.endAt) {
        b.dead = true;
        fx.pop(b, false);
        continue;
      }
      if (playing && b.sched > 0 && run >= b.sched) {
        popBubble(b, b.chainSrc, b.chain);
        continue;
      }
      b.age += wdt;
      b.y -= b.vy * wdt;
      if (b.vx != 0) {
        b.baseX += b.vx * wdt;
        b.vx *= math.pow(0.996, wdt).toDouble();
        if (b.baseX < b.r || b.baseX > worldW - b.r) b.vx *= -1;
      }
      b.x = b.baseX + math.sin(b.age * b.wf + b.phase) * b.wa;
      if (magnetOn && !b.deco && b.sched == 0) magnetPull(b, dt);
      if (b.dead) continue;
      if (b.y < -b.r - 2) {
        b.dead = true;
        final ch = b.chain;
        if (ch != null && b.sched > 0) {
          ch.pending -= 1;
          if (ch.pending <= 0) finishChain(ch);
        }
        if (playing && !b.deco) escape(b);
      }
    }
    if (playing && rs != null && feverMusic && run >= rs.feverUntil) {
      feverMusic = false;
      hooks.music('play');
    }
    bubs.removeWhere((b) => b.dead);
    fx.update(dt);
  }

  void spawnTick() {
    final c = cfg!, rs = r!;
    final ts = run / 1000;
    if (wclock >= rs.nextSpawn) {
      spawn(pickType(ts));
      var iv = c.spawn.at(ts) * c.spawnMul * rnd(0.75, 1.25);
      if (run < rs.reliefUntil) iv *= 1.45;
      if (rs.runEvent == 'calm') iv *= 1.8;
      rs.nextSpawn = wclock + iv;
    }
    if (rs.runEvent == 'drizzle' && wclock >= rs.drizzleNext) {
      spawn('mini', rad: rnd(9, 12), vy: rnd(0.09, 0.13), harmless: true);
      rs.drizzleNext = wclock + 140;
    }
    if (c.powers && run >= rs.nextPower) {
      spawnPowerBubble();
      rs.nextPower = run + rnd(c.powerEvery[0], c.powerEvery[1]) * 1000;
    }
    if (c.events && run >= rs.nextEvent) {
      startRunEvent();
      rs.nextEvent = run + rnd(Bal.eventEvery[0], Bal.eventEvery[1]) * 1000;
    }
  }

  void magnetPull(Bubble b, double dt) {
    final dx = pointerX - b.x, dy = pointerY - b.y;
    var d = hypot(dx, dy);
    if (d == 0) d = 1;
    const range = 125.0;
    if (d > range) return;
    if (bubbles[b.type]!.hazard) {
      final push = 0.12 * dt * (1 - d / range);
      b.baseX = clampD(b.baseX - dx / d * push, b.r, worldW - b.r);
      b.y -= dy / d * push;
      return;
    }
    if (d < b.r + 14) {
      popBubble(b, 'magnet');
      return;
    }
    final pull = math.min(d, (0.12 + 0.35 * (1 - d / range)) * dt);
    b.baseX += dx / d * pull;
    b.y += dy / d * pull;
  }

  // ---------- input
  void tap(double x, double y) {
    final rs = r;
    if (state != GState.playing || rs == null || rs.grace > 0) return;
    Bubble? hit;
    var hitD = double.infinity;
    for (final b in bubs) {
      if (b.dead || b.deco || b.sched > 0 || b.endAt > 0) continue;
      final d = hypot(x - b.x, y - b.y);
      // prefer the bubble whose edge is closest to the finger
      if (d <= b.r + Bal.hitPadTouch && d - b.r < hitD) {
        hit = b;
        hitD = d - b.r;
      }
    }
    if (hit != null) {
      tapBubble(hit);
    } else {
      miss(x, y);
    }
  }

  void miss(double x, double y) {
    final rs = r!;
    fx.ring(x, y, 4, 14, theme.bubbleEdge, 280, 2);
    if (run < (rs.active['magnet'] ?? 0) || !cfg!.missPenalty) return;
    hooks.sfx('miss');
    rs.misses += 1;
    Prog.onMiss();
    if (cfg!.rules.contains('noMiss')) {
      fail('noMiss');
      return;
    }
    if (rs.streak >= 5) fx.text(x, y - 12, t('fx.comboLost'), theme.pink, 14, 800);
    resetStreak();
  }

  void tapBubble(Bubble b) {
    final def = bubbles[b.type]!;
    if (def.hazard) {
      hazardPop(b);
      return;
    }
    if (b.hp > 1) {
      b.hp -= 1;
      b.hitAt = clock;
      addStreak();
      final pts = (def.pts * mulNow()).round();
      r!.score += pts;
      fx.text(b.x, b.y - b.r * 0.3, '+$pts', theme.canvasInk, 16, 600);
      fx.chips(b);
      hooks.sfx('hit');
      hooks.haptic(12);
      hooks.hud(bump: true);
      return;
    }
    popBubble(b, 'tap');
  }

  void hazardPop(Bubble b) {
    final rs = r!;
    b.dead = true;
    fx.spiky(b);
    hooks.sfx('spiky');
    hooks.haptic(60);
    resetStreak();
    if (cfg!.rules.contains('noHazard')) {
      fail('noHazard');
      return;
    }
    if (rs.maxLives > 0) {
      loseLife(b, true);
    } else if (cfg!.time > 0) {
      rs.timeLeft = math.max(0.0, rs.timeLeft - Bal.hazardTime * 1000);
      fx.text(b.x, b.y, '−${Bal.hazardTime}${t('unit.s')}', theme.pink, 20, 900);
      hooks.hurt(false);
    }
  }

  double mulNow() {
    final rs = r!;
    return rs.mult * (run < rs.feverUntil ? Bal.feverMul : 1) * cfg!.ptsMul;
  }

  bool get fever => r != null && run < r!.feverUntil;

  void addStreak() {
    final rs = r!;
    rs.streak += 1;
    if (rs.streak > rs.bestStreak) rs.bestStreak = rs.streak;
    final before = rs.mult;
    rs.mult = math.min(Bal.multMax, 1 + rs.streak ~/ Bal.multEvery);
    Prog.onStreak(rs.streak);
    if (rs.mult > before) {
      fx.text(worldW / 2, H * 0.32, t('fx.combo', {'n': rs.mult}), theme.pink, 22, 1000, rise: -20, big: true);
      hooks.sfx('combo', arg: rs.mult);
    }
    if (rs.streak % Bal.feverEvery == 0) startFever();
    const milestones = {10: 'fx.nice', 20: 'fx.great', 30: 'fx.amazing', 50: 'fx.incredible', 75: 'fx.legend', 100: 'fx.master'};
    final m = milestones[rs.streak];
    if (m != null) fx.banner(t(m), 'praise');
  }

  void resetStreak() {
    final rs = r!;
    rs.streak = 0;
    rs.mult = 1;
    hooks.hud();
  }

  void startFever() {
    final rs = r!;
    rs.feverUntil = run + Bal.feverMs;
    rs.fevers += 1;
    fx.banner(t('fx.fever'), 'fever');
    hooks.sfx('fever');
    feverMusic = true;
    hooks.music('fever');
    hooks.haptic(30);
  }

  void popBubble(Bubble b, String source, [Chain? chain]) {
    if (b.dead) return;
    final rs = r!, c = cfg!;
    final def = bubbles[b.type]!;
    b.dead = true;
    if (def.hazard) {
      fx.spiky(b);
      return;
    }
    addStreak();
    final base = b.maxHp > 1 ? (def.finalPts > 0 ? def.finalPts : def.pts) : def.pts;
    final pts = math.max(1, (base * mulNow()).round());
    rs.score += pts;
    rs.pops += 1;
    rs.popsBy[b.type] = (rs.popsBy[b.type] ?? 0) + 1;
    if (def.coins > 0) rs.coins += def.coins;
    Prog.onPop(b.type);
    if (chain != null && !chain.blast) chain.count += 1;

    final strong = source == 'tap' || source == 'magnet';
    fx.pop(b, true);
    final col = b.type == 'gold' ? theme.goldEdge : (b.type == 'rainbow' ? theme.pink : theme.canvasInk);
    fx.text(b.x, b.y, '+$pts', col, (b.type == 'gold' || b.type == 'rainbow') ? 24 : 19, 750);
    if (def.coins > 0) fx.coinText(b.x, b.y + 16, def.coins);
    if (strong || source == 'blast') {
      if (b.type == 'gold') {
        hooks.sfx('gold');
      } else {
        hooks.sfx('pop', arg: rs.streak);
      }
    }
    if (strong) hooks.haptic(8);

    switch (def.effect) {
      case 'explode':
        explode(b, chain);
        break;
      case 'freeze':
        rs.frozenUntil = run + def.duration;
        fx.frostAt = clock;
        hooks.sfx('ice');
        break;
      case 'split':
        for (var i = 0; i < def.pieces; i++) {
          final a = -math.pi / 2 + (i - 1) * 0.9 + frand(-0.2, 0.2);
          spawn('mini',
              x: b.x,
              y: b.y,
              rad: math.max(9.0, b.r * bubbles['mini']!.rMul * 1.15),
              vy: math.max(0.08, b.vy / speedScale * 1.6),
              vx: math.cos(a) * 0.09);
        }
        hooks.sfx('split');
        break;
      case 'heal':
        if (rs.maxLives > 0 && rs.lives < rs.maxLives) {
          rs.lives += 1;
          fx.text(b.x, b.y - 26, '+1 ♥', theme.pink, 20, 900);
          hooks.hud(gainHeart: true);
        } else {
          rs.score += 10;
          fx.text(b.x, b.y - 26, '+10', theme.pink, 18, 800);
        }
        hooks.sfx('heal');
        break;
      case 'time':
        if (c.time > 0) {
          rs.timeLeft += def.seconds * 1000;
          fx.text(b.x, b.y - 26, '+${def.seconds}${t('unit.s')}', theme.good, 20, 900);
        }
        hooks.sfx('clock');
        break;
      case 'rainbow':
        hooks.sfx('rainbow');
        fx.rainbowBurst(b);
        if (c.powers) givePower(powers.keys.elementAt(irand(powers.length)), b);
        break;
      case 'power':
        if (c.powers) givePower(b.power, b);
        break;
      case 'event':
        rs.tokens += 1;
        final sea = b.season;
        if (sea != null) Prog.addEventToken(sea, 1);
        hooks.sfx('event');
        break;
    }
    // settle the chain only after this pop's own effect (a chained bomb adds more)
    if (chain != null) {
      chain.pending -= 1;
      if (chain.pending <= 0) finishChain(chain);
    }
    if (mode == 'challenge') checkGoals();
    hooks.hud(bump: true);
  }

  void givePower(String id, Bubble b) {
    final rs = r!;
    if (!powers.containsKey(id)) return;
    final have = rs.powers[id] ?? 0;
    if (have < powerMax) {
      rs.powers[id] = have + 1;
      fx.text(b.x, b.y - 30, powers[id]!.name.s, theme.cyan, 16, 1000);
      hooks.powerGained(id);
    } else {
      rs.score += 5;
      fx.text(b.x, b.y - 30, '+5', theme.cyan, 16, 800);
    }
    hooks.sfx('powerGet');
  }

  void explode(Bubble b, Chain? chain) {
    final def = bubbles[b.type]!;
    final ch = chain ?? Chain();
    final radius = def.radius;
    var scheduled = 0;
    for (final o in bubs) {
      if (o.dead || identical(o, b) || o.deco || o.sched > 0 || o.endAt > 0 || bubbles[o.type]!.hazard) continue;
      final d = hypot(o.x - b.x, o.y - b.y);
      if (d <= radius + o.r) {
        o.sched = run + 60 + d * 1.6;
        o.chain = ch;
        o.chainSrc = 'bomb';
        ch.pending += 1;
        scheduled++;
      }
    }
    fx.explosion(b, radius);
    hooks.sfx('bomb');
    hooks.haptic(45);
    if (!reduceMotion) shake = math.min(10.0, shake + 7);
    if (scheduled == 0 && ch.pending <= 0) finishChain(ch);
  }

  void finishChain(Chain ch) {
    if (ch.done || ch.blast) return;
    ch.done = true;
    final rs = r;
    if (rs == null) return;
    if (ch.count > rs.bestChain) rs.bestChain = ch.count;
    if (ch.count >= 3) fx.banner(t('fx.chain', {'n': ch.count}), 'praise');
    if (ch.count > 0) Prog.onChain(ch.count);
    if (mode == 'challenge') checkGoals();
  }

  void escape(Bubble b) {
    final rs = r!, c = cfg!;
    final def = bubbles[b.type]!;
    if (def.hazard || def.bonus || b.harmless) return;
    rs.escapes += 1;
    Prog.onEscape();
    if (run < (rs.active['shield'] ?? 0)) {
      fx.ring(b.x, 6, b.r, 24, theme.cyan, 400, 3);
      fx.text(b.x, 26, t('fx.blocked'), theme.cyan, 15, 800, rise: 14);
      hooks.sfx('block');
      return;
    }
    if (c.noFail) return;
    if (rs.streak >= 5) fx.text(b.x, 46, t('fx.comboLost'), theme.pink, 14, 800, rise: 14);
    resetStreak();
    if (rs.maxLives > 0) {
      loseLife(b, false);
    } else if (c.time > 0) {
      rs.timeLeft = math.max(0.0, rs.timeLeft - Bal.escapeTime * 1000);
      fx.text(b.x, 24, '−${Bal.escapeTime}${t('unit.s')}', theme.pink, 17, 800, rise: 14);
      hooks.sfx('miss');
    }
  }

  void loseLife(Bubble b, bool hazard) {
    final rs = r!;
    rs.lives = math.max(0, rs.lives - 1);
    rs.lostHearts += 1;
    rs.reliefUntil = run + Bal.reliefMs;
    if (!hazard) fx.text(b.x, 22, '−1 ♥', theme.pink, 18, 900, rise: 16);
    hooks.sfx('lose');
    hooks.haptic(90);
    hooks.hurt(true);
    hooks.hud();
    if (rs.lives == 0) end('lives', false);
  }

  // ---------- powers
  bool usePower(String id) {
    final rs = r, c = cfg;
    if (state != GState.playing || rs == null || c == null || !c.powers || rs.grace > 0) return false;
    if (!powers.containsKey(id) || (rs.powers[id] ?? 0) <= 0) return false;
    rs.powers[id] = rs.powers[id]! - 1;
    rs.powersUsed += 1;
    Prog.onPower();
    final dur = powers[id]!.duration * c.powerTimeMul;
    if (id == 'blast') {
      final ch = Chain(blast: true);
      final list = bubs.where((b) => !b.dead && !b.deco && b.sched == 0 && b.endAt == 0 && !bubbles[b.type]!.hazard).toList();
      double dist(Bubble b) => hypot(b.x - worldW / 2, b.y - H / 2);
      list.sort((a, b) => dist(a).compareTo(dist(b)));
      for (var i = 0; i < list.length; i++) {
        list[i]
          ..sched = run + 80 + i * 45
          ..chain = ch
          ..chainSrc = 'blast';
        ch.pending++;
      }
      fx.shockAt = clock;
      if (!reduceMotion) shake = math.min(10.0, shake + 6);
    } else {
      rs.active[id] = run + dur;
      rs.activeDur[id] = dur;
    }
    fx.banner(powers[id]!.name.s, 'power');
    hooks.sfx('power_$id');
    hooks.haptic(25);
    hooks.hud();
    return true;
  }

  // ---------- challenge goals
  int goalValue(Goal g) {
    final rs = r;
    if (rs == null) return 0;
    switch (g.k) {
      case 'pop':
        return rs.pops;
      case 'popType':
        return rs.popsBy[g.t] ?? 0;
      case 'score':
        return rs.score;
      case 'streak':
        return rs.bestStreak;
      case 'chain':
        return rs.bestChain;
      case 'power':
        return rs.powersUsed;
      case 'survive':
        return run ~/ 1000;
    }
    return 0;
  }

  bool goalsMet() => cfg!.goals.every((g) => goalValue(g) >= g.n);

  void checkGoals() {
    if (state != GState.playing || mode != 'challenge') return;
    if (goalsMet()) end('win', true);
  }

  int starsFor() {
    final rs = r!, st = stage!;
    var stars = 1;
    final tl = st.twoTimeLeft, sc = st.twoScore;
    if (tl != null && rs.timeTotal > 0 && rs.timeLeft / rs.timeTotal >= tl) stars = 2;
    if (sc != null && rs.score >= sc) stars = 2;
    if (stars == 2 && rs.lostHearts == 0) stars = 3;
    return stars;
  }

  void timeUp() {
    if (mode == 'challenge' && goalsMet()) {
      end('win', true);
    } else {
      end('time', false);
    }
  }

  void fail(String reason) => end(reason, false);

  // ---------- end of run
  void end(String reason, bool won) {
    if (!inRun) return;
    final rs = r!;
    state = GState.ending;
    rs.failed = won ? '' : reason;
    rs.won = won;
    final live = bubs.where((b) => !b.dead && b.endAt == 0).toList()..sort((a, b) => a.y.compareTo(b.y));
    for (var i = 0; i < live.length; i++) {
      live[i]
        ..endAt = clock + 200 + i * 50
        ..sched = 0;
    }
    hooks.sfx(won ? 'win' : 'over');
    hooks.haptic(won ? 40 : 70);
    feverMusic = false;
    hooks.music('menu');
    final sum = RunSummary()
      ..mode = mode
      ..stage = stage?.id ?? 0
      ..diff = diff
      ..score = rs.score
      ..pops = rs.pops
      ..popsBy = Map.of(rs.popsBy)
      ..misses = rs.misses
      ..escapes = rs.escapes
      ..bestStreak = rs.bestStreak
      ..bestChain = rs.bestChain
      ..powersUsed = rs.powersUsed
      ..fevers = rs.fevers
      ..coins = rs.coins
      ..timeMs = run.round()
      ..won = won
      ..reason = reason
      ..lostHearts = rs.lostHearts
      ..tokens = rs.tokens
      ..hour = DateTime.now().hour
      ..stars = (mode == 'challenge' && won) ? starsFor() : 0
      ..dailyKey = daily?.key ?? ''
      ..target = daily?.target ?? 0;
    _pendRes = Prog.applyRun(sum);
    _pendR = sum;
    resultsAt = clock + (won ? 900 : 750);
  }
}
