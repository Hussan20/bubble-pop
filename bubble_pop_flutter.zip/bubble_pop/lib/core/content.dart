// CONTENT — every gameplay value, rule and unlockable lives here.
// Systems read from these tables; most additions need no other change.
import 'dart:math' as math;

import 'util.dart';

const String contentVersion = '3.0.0';

/// Current UI language ('en' or 'ar').
String gLang = 'ar';

class Tx {
  final String en;
  final String ar;
  const Tx(this.en, this.ar);
  String get s => gLang == 'ar' ? ar : en;
}

// ---------------------------------------------------------------- bubbles
class BubbleDef {
  final int pts;
  final int coins;
  final double rMul;
  final double speedMul;
  final int hp;
  final int finalPts;
  final bool hazard;
  final bool bonus;
  final bool hidden;
  final String effect;
  final double radius;
  final int duration;
  final int pieces;
  final int seconds;
  final Tx name;
  final Tx desc;
  const BubbleDef({
    required this.pts,
    this.coins = 0,
    this.rMul = 1,
    this.speedMul = 1,
    this.hp = 1,
    this.finalPts = 0,
    this.hazard = false,
    this.bonus = false,
    this.hidden = false,
    this.effect = '',
    this.radius = 0,
    this.duration = 0,
    this.pieces = 0,
    this.seconds = 0,
    required this.name,
    required this.desc,
  });
}

const Map<String, BubbleDef> bubbles = {
  'normal': BubbleDef(pts: 1, name: Tx('Bubble', 'فقاعة'),
      desc: Tx("Tap to pop. Don't let it reach the top.", 'انقرها لتفرقعها، ولا تدعها تصل إلى الأعلى.')),
  'gold': BubbleDef(pts: 5, coins: 2, rMul: 0.8, speedMul: 1.35, name: Tx('Gold', 'ذهبية'),
      desc: Tx('Small and quick. 5 points and 2 coins.', 'صغيرة وسريعة. 5 نقاط وعملتان.')),
  'bomb': BubbleDef(pts: 2, rMul: 1.05, speedMul: 0.9, effect: 'explode', radius: 96, name: Tx('Bomb', 'متفجرة'),
      desc: Tx('Pops every bubble around it. Bombs set off other bombs!', 'تفرقع كل ما حولها، وتُشعل المتفجرات القريبة!')),
  'ice': BubbleDef(pts: 2, rMul: 0.95, effect: 'freeze', duration: 2600, name: Tx('Ice', 'متجمدة'),
      desc: Tx('Freezes every bubble for a moment.', 'تجمّد كل الفقاعات لحظات قصيرة.')),
  'tough': BubbleDef(pts: 1, rMul: 1.2, speedMul: 0.8, hp: 3, finalPts: 4, name: Tx('Armored', 'مدرّعة'),
      desc: Tx('Takes 3 taps. Each layer gives points.', 'تحتاج 3 نقرات، وكل طبقة تمنحك نقاطًا.')),
  'splitter': BubbleDef(pts: 2, rMul: 1.15, speedMul: 0.95, effect: 'split', pieces: 3, name: Tx('Splitter', 'مقسّمة'),
      desc: Tx('Bursts into 3 tiny, fast bubbles.', 'تنقسم إلى 3 فقاعات صغيرة وسريعة.')),
  'mini': BubbleDef(pts: 1, rMul: 0.48, speedMul: 1.45, bonus: true, hidden: true, name: Tx('Mini', 'صغيرة'),
      desc: Tx('Left over from a splitter. Quick!', 'تخرج من المقسّمة، وهي سريعة!')),
  'spiky': BubbleDef(pts: 0, speedMul: 0.85, hazard: true, name: Tx('Spiky', 'شائكة'),
      desc: Tx("Don't pop it! Let it float away safely.", 'لا تفرقعها! دعها تطفو بعيدًا بأمان.')),
  'heart': BubbleDef(pts: 1, rMul: 0.9, speedMul: 1.2, effect: 'heal', bonus: true, name: Tx('Heart', 'قلب'),
      desc: Tx('Gives back a heart.', 'تعيد إليك قلبًا.')),
  'clock': BubbleDef(pts: 1, rMul: 0.9, speedMul: 1.15, effect: 'time', seconds: 3, bonus: true, name: Tx('Clock', 'ساعة'),
      desc: Tx('+3 seconds in timed modes.', 'تضيف 3 ثوانٍ في الأنماط المؤقتة.')),
  'rainbow': BubbleDef(pts: 15, coins: 5, rMul: 0.85, speedMul: 1.5, effect: 'rainbow', bonus: true, name: Tx('Rainbow', 'قوس قزح'),
      desc: Tx('Rare! Big points, coins and a free power.', 'نادرة! نقاط كثيرة وعملات وقدرة مجانية.')),
  'power': BubbleDef(pts: 1, speedMul: 0.9, effect: 'power', bonus: true, name: Tx('Power', 'قدرة'),
      desc: Tx('Pop it to collect the power inside.', 'فرقعها لتحصل على القدرة التي بداخلها.')),
  'event': BubbleDef(pts: 3, coins: 1, speedMul: 1.05, effect: 'event', bonus: true, hidden: true, name: Tx('Event', 'فقاعة الحدث'),
      desc: Tx('Seasonal bubble. Collect them for event rewards.', 'فقاعة موسمية، اجمعها لتحصل على جوائز الحدث.')),
};

// ---------------------------------------------------------------- powers
class PowerDef {
  final String key;
  final int duration;
  final Tx name;
  final Tx desc;
  const PowerDef(this.key, this.duration, this.name, this.desc);
}

const Map<String, PowerDef> powers = {
  'slow': PowerDef('1', 6000, Tx('Slow time', 'إبطاء الوقت'), Tx('Everything moves slowly for 6 seconds.', 'يبطئ كل شيء لمدة 6 ثوانٍ.')),
  'blast': PowerDef('2', 0, Tx('Blast', 'تفجير'), Tx('Pops every bubble on screen (not spiky ones).', 'يفرقع كل الفقاعات على الشاشة (عدا الشائكة).')),
  'magnet': PowerDef('3', 6000, Tx('Magnet', 'مغناطيس'), Tx('Bubbles near your finger fly in and pop.', 'تنجذب الفقاعات القريبة من إصبعك وتنفجر.')),
  'shield': PowerDef('4', 9000, Tx('Shield', 'درع'), Tx("Escaping bubbles don't cost hearts for 9 seconds.", 'لا تخسر قلوبًا من الفقاعات الهاربة لمدة 9 ثوانٍ.')),
};
const int powerMax = 3;

// ---------------------------------------------------------------- difficulty
class DiffDef {
  final double speed;
  final double spawn;
  final double reward;
  final Tx name;
  const DiffDef(this.speed, this.spawn, this.reward, this.name);
}

const Map<String, DiffDef> difficulty = {
  'easy': DiffDef(0.82, 1.22, 0.75, Tx('Easy', 'سهل')),
  'normal': DiffDef(1, 1, 1, Tx('Normal', 'عادي')),
  'hard': DiffDef(1.2, 0.84, 1.35, Tx('Hard', 'صعب')),
};

// ---------------------------------------------------------------- curves & weights
class Curve {
  final double a;
  final double b;
  final double ramp;
  final double after;
  final double? min;
  final double? max;
  const Curve(this.a, this.b, this.ramp, {this.after = 0, this.min, this.max});
  double at(double ts) {
    final r = ramp <= 0 ? 1.0 : ramp;
    var v = ts < r ? lerpD(a, b, ts / r) : b + after * (ts - r);
    final mn = min, mx = max;
    if (mn != null && v < mn) v = mn;
    if (mx != null && v > mx) v = mx;
    return v;
  }
}

class SizeCurve {
  final double a0, a1, b0, b1, ramp;
  const SizeCurve(this.a0, this.a1, this.b0, this.b1, this.ramp);
  List<double> at(double ts) {
    final p = clampD(ts / (ramp <= 0 ? 1 : ramp), 0, 1);
    return [lerpD(a0, b0, p), lerpD(a1, b1, p)];
  }
}

/// A spawn weight: plain, or faded in from `from` seconds over `ramp` seconds.
class W {
  final double w;
  final double from;
  final double ramp;
  final bool plain;
  const W(this.w, {this.from = 0, this.ramp = 15}) : plain = false;
  const W.n(this.w)
      : from = 0,
        ramp = 0,
        plain = true;
  double at(double ts) {
    if (plain) return w;
    if (ts < from) return 0;
    return w * clampD((ts - from) / (ramp <= 0 ? 15 : ramp), 0.25, 1);
  }

  W times(double k) => plain ? W.n(w * k) : W(w * k, from: from, ramp: ramp);
}

// ---------------------------------------------------------------- modes
class ModeDef {
  final String icon;
  final int unlockLevel;
  final int lives;
  final int maxLives;
  final int time;
  final bool hazards;
  final bool events;
  final bool powers;
  final bool missPenalty;
  final bool difficulty;
  final bool noFail;
  final bool seeded;
  final bool noUpgrades;
  final bool heartBubbles;
  final double rewardMul;
  final String music;
  final Curve? spawn;
  final Curve? speed;
  final SizeCurve? size;
  final Map<String, W> weights;
  final Tx name;
  final Tx desc;
  const ModeDef({
    required this.icon,
    required this.unlockLevel,
    this.lives = 0,
    this.maxLives = 0,
    this.time = 0,
    this.hazards = false,
    this.events = false,
    this.powers = false,
    this.missPenalty = false,
    this.difficulty = false,
    this.noFail = false,
    this.seeded = false,
    this.noUpgrades = false,
    this.heartBubbles = true,
    this.rewardMul = 1,
    this.music = 'play',
    this.spawn,
    this.speed,
    this.size,
    this.weights = const {},
    required this.name,
    required this.desc,
  });
}

const Map<String, ModeDef> modes = {
  'classic': ModeDef(
    icon: 'play', unlockLevel: 1, lives: 3, maxLives: 5, hazards: true, events: true, powers: true, missPenalty: true, difficulty: true,
    spawn: Curve(1000, 330, 160, after: -0.35, min: 250),
    speed: Curve(0.06, 0.19, 150, after: 0.00025, max: 0.27),
    size: SizeCurve(23, 34, 15, 23, 150),
    weights: {
      'normal': W.n(100), 'gold': W.n(7), 'bomb': W(5, from: 18), 'ice': W(3.5, from: 35), 'tough': W(6, from: 45),
      'splitter': W(5, from: 70), 'spiky': W(9, from: 50, ramp: 60), 'heart': W(1.1, from: 60), 'rainbow': W(0.7, from: 30),
    },
    name: Tx('Classic', 'الكلاسيكي'),
    desc: Tx('3 hearts, endless bubbles. How far can you go?', '3 قلوب وفقاعات لا تنتهي. إلى أين ستصل؟'),
  ),
  'time': ModeDef(
    icon: 'clock', unlockLevel: 2, time: 60, hazards: true, events: true, powers: true, missPenalty: true, difficulty: true,
    spawn: Curve(640, 300, 60), speed: Curve(0.08, 0.17, 60), size: SizeCurve(21, 31, 16, 25, 60),
    weights: {
      'normal': W.n(100), 'gold': W.n(12), 'bomb': W(7, from: 8), 'ice': W(3, from: 15), 'tough': W(6, from: 10), 'splitter': W(6, from: 20),
      'spiky': W(10, from: 12), 'clock': W(4, from: 5), 'rainbow': W(1, from: 15),
    },
    name: Tx('Time Rush', 'سباق الوقت'),
    desc: Tx('60 seconds, no hearts. Clocks add time, spikes take it.', '60 ثانية بلا قلوب. الساعات تضيف وقتًا والشائكة تنقصه.'),
  ),
  'challenge': ModeDef(
    icon: 'flag', unlockLevel: 3, lives: 3, maxLives: 3, hazards: true, powers: true, missPenalty: true,
    name: Tx('Challenges', 'التحديات'),
    desc: Tx('24 stages with goals and 3 stars each.', '24 مرحلة لكل منها أهداف و3 نجوم.'),
  ),
  'survival': ModeDef(
    icon: 'skull', unlockLevel: 4, lives: 1, maxLives: 1, hazards: true, events: true, powers: true, missPenalty: true, difficulty: true,
    rewardMul: 1.15, heartBubbles: false,
    spawn: Curve(900, 230, 110, after: -0.4, min: 190),
    speed: Curve(0.07, 0.24, 110, after: 0.0004, max: 0.34),
    size: SizeCurve(22, 32, 14, 21, 110),
    weights: {
      'normal': W.n(100), 'gold': W.n(8), 'bomb': W(6, from: 10), 'ice': W(4, from: 20), 'tough': W(8, from: 25),
      'splitter': W(6, from: 35), 'spiky': W(12, from: 15, ramp: 50), 'rainbow': W(0.8, from: 20),
    },
    name: Tx('Survival', 'البقاء'),
    desc: Tx('One heart. It gets hard, fast. Survive!', 'قلب واحد فقط والصعوبة ترتفع بسرعة. اصمد!'),
  ),
  'zen': ModeDef(
    icon: 'leaf', unlockLevel: 1, rewardMul: 0.4, music: 'zen', noFail: true,
    spawn: Curve(950, 950, 1), speed: Curve(0.045, 0.045, 1), size: SizeCurve(22, 36, 22, 36, 1),
    weights: {'normal': W.n(100), 'gold': W.n(6), 'splitter': W.n(4), 'rainbow': W.n(0.6)},
    name: Tx('Zen', 'الاسترخاء'),
    desc: Tx('No hearts, no clock, no pressure. Just pop.', 'بلا قلوب ولا وقت ولا ضغط. فرقع واستمتع.'),
  ),
  'daily': ModeDef(
    icon: 'calendar', unlockLevel: 1, lives: 3, maxLives: 3, time: 75, hazards: true, events: true, powers: true, missPenalty: true,
    seeded: true, noUpgrades: true,
    spawn: Curve(820, 330, 75), speed: Curve(0.07, 0.18, 75), size: SizeCurve(22, 32, 16, 24, 75),
    weights: {
      'normal': W.n(100), 'gold': W.n(8), 'bomb': W(5, from: 10), 'ice': W(3, from: 20), 'tough': W(6, from: 15),
      'splitter': W(5, from: 25), 'spiky': W(9, from: 20), 'clock': W.n(0), 'rainbow': W(0.8, from: 15),
    },
    name: Tx('Daily Challenge', 'التحدي اليومي'),
    desc: Tx('New rules every day. Same seed for every player on the same date.', 'قواعد جديدة كل يوم، ونفس البذرة لكل اللاعبين في التاريخ نفسه.'),
  ),
};
const List<String> modeOrder = ['classic', 'time', 'challenge', 'survival', 'zen', 'daily'];

// ---------------------------------------------------------------- daily modifiers
class DailyMod {
  final String id;
  final Map<String, double> weights;
  final double size;
  final double pts;
  final double speed;
  final double spawn;
  final bool noPowers;
  final Tx name;
  const DailyMod(this.id, this.name,
      {this.weights = const {}, this.size = 1, this.pts = 1, this.speed = 1, this.spawn = 1, this.noPowers = false});
}

const List<DailyMod> dailyMods = [
  DailyMod('goldRush', Tx('Gold fever', 'حمّى الذهب'), weights: {'gold': 3}),
  DailyMod('bombParty', Tx('Bomb party', 'حفلة المتفجرات'), weights: {'bomb': 3}),
  DailyMod('tiny', Tx('Tiny bubbles ×1.5 pts', 'فقاعات صغيرة ×1.5 نقاط'), size: 0.8, pts: 1.5),
  DailyMod('fast', Tx('Fast lane', 'المسار السريع'), speed: 1.18),
  DailyMod('frozen', Tx('Deep freeze', 'تجمّد عميق'), weights: {'ice': 3}),
  DailyMod('armored', Tx('Armor day', 'يوم الدروع'), weights: {'tough': 3}),
  DailyMod('splits', Tx('Split storm', 'عاصفة الانقسام'), weights: {'splitter': 3}),
  DailyMod('spikes', Tx('Spike field ×1.3 pts', 'حقل الأشواك ×1.3 نقاط'), weights: {'spiky': 1.8}, pts: 1.3),
  DailyMod('noPowers', Tx('No powers ×1.25 pts', 'بلا قدرات ×1.25 نقاط'), noPowers: true, pts: 1.25),
  DailyMod('rainbow', Tx('Rainbow luck', 'حظ قوس قزح'), weights: {'rainbow': 4}),
  DailyMod('dense', Tx('Crowded tub', 'حوض مزدحم'), spawn: 0.82),
];

// ---------------------------------------------------------------- challenge stages
class Goal {
  final String k; // pop · popType · score · streak · chain · power · survive
  final int n;
  final String t;
  const Goal(this.k, this.n, [this.t = '']);
}

class StageDef {
  final int id;
  final int time;
  final int lives;
  final List<Goal> goals;
  final List<String> rules;
  final Map<String, double> weights;
  final double spawn;
  final double speed;
  final double? twoTimeLeft;
  final int? twoScore;
  final double powerEvery;
  const StageDef(this.id, this.time, this.lives, this.goals, this.weights, this.spawn, this.speed,
      {this.rules = const [], this.twoTimeLeft, this.twoScore, this.powerEvery = 0});
}

const List<StageDef> stages = [
  StageDef(1, 40, 3, [Goal('pop', 15)], {'normal': 100}, 900, 0.07, twoTimeLeft: 0.35),
  StageDef(2, 45, 3, [Goal('popType', 3, 'gold')], {'normal': 100, 'gold': 22}, 850, 0.08, twoTimeLeft: 0.3),
  StageDef(3, 45, 3, [Goal('streak', 10)], {'normal': 100, 'gold': 6}, 800, 0.08, twoTimeLeft: 0.35),
  StageDef(4, 50, 3, [Goal('popType', 5, 'tough')], {'normal': 100, 'tough': 30}, 850, 0.08, twoTimeLeft: 0.3),
  StageDef(5, 50, 3, [Goal('popType', 3, 'bomb')], {'normal': 100, 'bomb': 16}, 650, 0.08, twoTimeLeft: 0.35),
  StageDef(6, 60, 3, [Goal('chain', 6)], {'normal': 100, 'bomb': 14}, 280, 0.05, twoTimeLeft: 0.3),
  StageDef(7, 40, 3, [Goal('score', 150)], {'normal': 100, 'gold': 10, 'bomb': 5}, 600, 0.1, twoTimeLeft: 0.25),
  StageDef(8, 0, 3, [Goal('survive', 45)], {'normal': 100, 'spiky': 15}, 700, 0.1, rules: ['noHazard'], twoScore: 150),
  StageDef(9, 60, 3, [Goal('popType', 4, 'ice'), Goal('pop', 40)], {'normal': 100, 'ice': 12}, 600, 0.11, twoTimeLeft: 0.25),
  StageDef(10, 55, 3, [Goal('popType', 15, 'mini')], {'normal': 100, 'splitter': 22}, 760, 0.1, twoTimeLeft: 0.3),
  StageDef(11, 50, 3, [Goal('pop', 30)], {'normal': 100, 'gold': 6}, 650, 0.11, rules: ['noMiss'], twoTimeLeft: 0.3),
  StageDef(12, 60, 3, [Goal('popType', 1, 'rainbow'), Goal('score', 250)], {'normal': 100, 'rainbow': 3, 'gold': 8, 'spiky': 6}, 560, 0.12,
      twoTimeLeft: 0.25),
  StageDef(13, 70, 3, [Goal('power', 3)], {'normal': 100, 'tough': 8, 'spiky': 6}, 520, 0.13, powerEvery: 7, twoTimeLeft: 0.3),
  StageDef(14, 60, 3, [Goal('pop', 60)], {'normal': 100, 'gold': 6, 'splitter': 6}, 380, 0.13, twoTimeLeft: 0.2),
  StageDef(15, 0, 1, [Goal('survive', 50)], {'normal': 100, 'gold': 6, 'bomb': 5, 'tough': 6}, 560, 0.13, twoScore: 250),
  StageDef(16, 50, 3, [Goal('popType', 12, 'gold')], {'normal': 100, 'gold': 18, 'spiky': 8}, 500, 0.14, twoTimeLeft: 0.25),
  StageDef(17, 70, 3, [Goal('streak', 30)], {'normal': 100, 'gold': 6, 'ice': 4}, 500, 0.13, twoTimeLeft: 0.3),
  StageDef(18, 60, 3, [Goal('score', 350)], {'normal': 100, 'spiky': 18, 'gold': 8, 'bomb': 5}, 420, 0.13, rules: ['noHazard'], twoTimeLeft: 0.2),
  StageDef(19, 70, 3, [Goal('chain', 10)], {'normal': 100, 'bomb': 14, 'splitter': 6}, 240, 0.07, twoTimeLeft: 0.3),
  StageDef(20, 70, 3, [Goal('popType', 12, 'tough')], {'normal': 100, 'tough': 28, 'spiky': 6}, 560, 0.13, twoTimeLeft: 0.25),
  StageDef(21, 75, 3, [Goal('score', 700)],
      {'normal': 100, 'gold': 9, 'bomb': 6, 'ice': 3, 'tough': 6, 'splitter': 5, 'spiky': 8, 'rainbow': 1}, 400, 0.15, twoTimeLeft: 0.15),
  StageDef(22, 0, 2, [Goal('survive', 75)], {'normal': 100, 'gold': 6, 'bomb': 5, 'tough': 8, 'splitter': 6, 'spiky': 12}, 440, 0.155,
      twoScore: 600),
  StageDef(23, 75, 3, [Goal('pop', 40)], {'normal': 100, 'spiky': 14, 'gold': 6, 'tough': 6}, 500, 0.15,
      rules: ['noMiss', 'noHazard'], twoTimeLeft: 0.25),
  StageDef(24, 90, 3, [Goal('score', 1000), Goal('streak', 25)],
      {'normal': 100, 'gold': 9, 'bomb': 6, 'ice': 4, 'tough': 8, 'splitter': 6, 'spiky': 10, 'rainbow': 1}, 360, 0.17, twoTimeLeft: 0.15),
];

// ---------------------------------------------------------------- in-run surprise events
class RunEventDef {
  final String id;
  final double w;
  final int duration;
  final Tx name;
  const RunEventDef(this.id, this.w, this.duration, this.name);
}

const List<RunEventDef> runEvents = [
  RunEventDef('goldRush', 3, 6000, Tx('Gold rush!', 'اندفاع الذهب!')),
  RunEventDef('wave', 3, 0, Tx('Bubble wave!', 'موجة فقاعات!')),
  RunEventDef('calm', 2, 6000, Tx('Calm waters', 'مياه هادئة')),
  RunEventDef('rainbow', 1.2, 0, Tx('A rainbow appears!', 'ظهر قوس قزح!')),
  RunEventDef('drizzle', 2, 5000, Tx('Tiny drizzle!', 'رذاذ صغير!')),
];

// ---------------------------------------------------------------- seasonal events
class Tier {
  final int n;
  final int coins;
  final String item;
  const Tier(this.n, {this.coins = 0, this.item = ''});
}

class SeasonDef {
  final String id;
  final String start; // "MM-DD", yearly
  final String end;
  final Map<int, List<String>> dates; // lunar holidays: year -> [start, end]
  final String bubble; // pumpkin · snow · lantern · beach
  final String ambient;
  final Tx name;
  final Tx desc;
  final List<Tier> tiers;
  const SeasonDef(this.id, this.bubble, this.ambient, this.name, this.desc, this.tiers,
      {this.start = '', this.end = '', this.dates = const {}});
}

const List<SeasonDef> seasons = [
  SeasonDef('halloween', 'pumpkin', 'bats', Tx('Spooky Bubbles', 'فقاعات الهالوين'),
      Tx('Pumpkin bubbles are floating in every mode!', 'فقاعات اليقطين تطفو في كل الأنماط!'),
      [Tier(25, coins: 150), Tier(80, item: 'skin:pumpkin'), Tier(180, item: 'theme:spooky')], start: '10-20', end: '11-03'),
  SeasonDef('winter', 'snow', 'snow', Tx('Winter Wonder', 'عجائب الشتاء'),
      Tx('Snowball bubbles drift in with the cold.', 'فقاعات كرات الثلج تأتي مع البرد.'),
      [Tier(25, coins: 150), Tier(80, item: 'skin:snowball'), Tier(180, item: 'fx:snow')], start: '12-01', end: '02-28'),
  SeasonDef('eidFitr', 'lantern', 'lanterns', Tx('Eid al-Fitr', 'عيد الفطر'),
      Tx('Lantern bubbles to celebrate Eid. Eid Mubarak!', 'فقاعات الفوانيس احتفالًا بالعيد. عيد مبارك!'),
      [Tier(20, coins: 200), Tier(60, item: 'skin:lantern'), Tier(140, coins: 500)],
      dates: {
        2026: ['03-19', '03-25'], 2027: ['03-08', '03-14'], 2028: ['02-25', '03-02'], 2029: ['02-13', '02-19'], 2030: ['02-03', '02-09'],
      }),
  SeasonDef('eidAdha', 'lantern', 'lanterns', Tx('Eid al-Adha', 'عيد الأضحى'),
      Tx('Lantern bubbles light up the tub. Eid Mubarak!', 'فقاعات الفوانيس تضيء الحوض. عيد مبارك!'),
      [Tier(20, coins: 200), Tier(60, item: 'skin:lantern'), Tier(140, coins: 500)],
      dates: {
        2026: ['05-26', '06-01'], 2027: ['05-15', '05-21'], 2028: ['05-04', '05-10'], 2029: ['04-23', '04-29'], 2030: ['04-12', '04-18'],
      }),
  SeasonDef('summer', 'beach', 'sun', Tx('Summer Splash', 'رذاذ الصيف'),
      Tx('Beach-ball bubbles bounce in for the summer.', 'فقاعات كرة الشاطئ تقفز في الصيف.'),
      [Tier(25, coins: 150), Tier(80, item: 'skin:beach'), Tier(180, coins: 600)], start: '06-15', end: '08-31'),
];

// ---------------------------------------------------------------- shop & unlockables
class ItemDef {
  final String id;
  final String kind; // skin · fx · theme
  final String key;
  final String source; // free · shop · ach · stars · event
  final int price;
  final int minLevel;
  final String ach;
  final String event;
  final int stars;
  final Tx name;
  const ItemDef(this.id, this.kind, this.key, this.source, this.name,
      {this.price = 0, this.minLevel = 1, this.ach = '', this.event = '', this.stars = 0});
}

const List<ItemDef> items = [
  ItemDef('skin:soap', 'skin', 'soap', 'free', Tx('Soap', 'صابون')),
  ItemDef('skin:candy', 'skin', 'candy', 'shop', Tx('Candy', 'حلوى'), price: 300, minLevel: 2),
  ItemDef('skin:glass', 'skin', 'glass', 'shop', Tx('Marble', 'رخام'), price: 600, minLevel: 4),
  ItemDef('skin:jelly', 'skin', 'jelly', 'shop', Tx('Jelly', 'جيلي'), price: 900, minLevel: 6),
  ItemDef('skin:neon', 'skin', 'neon', 'shop', Tx('Neon', 'نيون'), price: 1400, minLevel: 9),
  ItemDef('skin:planet', 'skin', 'planet', 'shop', Tx('Planets', 'كواكب'), price: 2000, minLevel: 13),
  ItemDef('skin:golden', 'skin', 'golden', 'stars', Tx('Royal gold', 'ذهب ملكي'), stars: 60),
  ItemDef('skin:pumpkin', 'skin', 'pumpkin', 'event', Tx('Pumpkins', 'يقطين'), event: 'halloween'),
  ItemDef('skin:snowball', 'skin', 'snowball', 'event', Tx('Snowballs', 'كرات الثلج'), event: 'winter'),
  ItemDef('skin:lantern', 'skin', 'lantern', 'event', Tx('Lanterns', 'فوانيس'), event: 'eidFitr'),
  ItemDef('skin:beach', 'skin', 'beach', 'event', Tx('Beach balls', 'كرات الشاطئ'), event: 'summer'),
  ItemDef('fx:splash', 'fx', 'splash', 'free', Tx('Splash', 'رذاذ')),
  ItemDef('fx:confetti', 'fx', 'confetti', 'shop', Tx('Confetti', 'قصاصات'), price: 250, minLevel: 2),
  ItemDef('fx:stars', 'fx', 'stars', 'shop', Tx('Stars', 'نجوم'), price: 500, minLevel: 3),
  ItemDef('fx:hearts', 'fx', 'hearts', 'shop', Tx('Hearts', 'قلوب'), price: 700, minLevel: 5),
  ItemDef('fx:fireworks', 'fx', 'fireworks', 'shop', Tx('Fireworks', 'ألعاب نارية'), price: 1200, minLevel: 8),
  ItemDef('fx:prism', 'fx', 'prism', 'ach', Tx('Prism', 'منشور ضوئي'), ach: 'rainbow1'),
  ItemDef('fx:snow', 'fx', 'snow', 'event', Tx('Snowflakes', 'رقائق الثلج'), event: 'winter'),
  ItemDef('theme:bath', 'theme', 'bath', 'free', Tx('Bath time', 'وقت الاستحمام')),
  ItemDef('theme:ocean', 'theme', 'ocean', 'shop', Tx('Ocean', 'المحيط'), price: 500, minLevel: 3),
  ItemDef('theme:sunset', 'theme', 'sunset', 'shop', Tx('Sunset', 'الغروب'), price: 900, minLevel: 6),
  ItemDef('theme:candy', 'theme', 'candy', 'shop', Tx('Candy land', 'أرض الحلوى'), price: 1100, minLevel: 8),
  ItemDef('theme:night', 'theme', 'night', 'ach', Tx('Starry night', 'ليلة النجوم'), ach: 'streak7'),
  ItemDef('theme:spooky', 'theme', 'spooky', 'event', Tx('Spooky', 'مخيف'), event: 'halloween'),
];

ItemDef? itemById(String id) {
  for (final i in items) {
    if (i.id == id) return i;
  }
  return null;
}

class UpgradeDef {
  final String id;
  final List<int> prices;
  final String icon;
  final Tx name;
  final Tx desc;
  const UpgradeDef(this.id, this.prices, this.icon, this.name, this.desc);
}

/// Permanent upgrades (coin sinks). Disabled in the daily challenge for fairness.
const List<UpgradeDef> upgrades = [
  UpgradeDef('powerTime', [300, 700, 1500], 'clock', Tx('Longer powers', 'قدرات أطول'),
      Tx('+15% power duration per level.', '+15% لمدة القدرات في كل مستوى.')),
  UpgradeDef('lucky', [350, 800, 1600], 'sparkle', Tx('Lucky drops', 'حظ القدرات'),
      Tx('Power bubbles appear 12% more often per level.', 'تظهر فقاعات القدرات أكثر بنسبة 12% في كل مستوى.')),
  UpgradeDef('coinBoost', [400, 900, 1800], 'coin', Tx('Coin boost', 'مضاعف العملات'),
      Tx('+10% coins from runs per level.', '+10% من عملات الجولات في كل مستوى.')),
  UpgradeDef('headStart', [600, 1500], 'bolt', Tx('Head start', 'بداية قوية'),
      Tx('Start runs with 1 random power per level.', 'ابدأ الجولة بقدرة عشوائية لكل مستوى.')),
  UpgradeDef('goldLuck', [300, 700, 1400], 'star', Tx('Gold luck', 'حظ الذهب'),
      Tx('+15% gold bubbles per level.', '+15% من الفقاعات الذهبية في كل مستوى.')),
];

// ---------------------------------------------------------------- themes (ARGB ints)
class ThemeDef {
  final bool dark;
  final String pattern;
  final String ambient;
  final int frame, frameEdge, frameShadow, ink, inkSoft, heart;
  final int page, grout, water, water2, veil, card, cardStrong, cardEdge;
  final int bubbleFill, bubbleEdge, shine, gold, goldEdge, pink, cyan, lemon, good;
  final int canvasInk, canvasInkSoft, halo;
  const ThemeDef({
    this.dark = false,
    this.pattern = 'tiles',
    this.ambient = 'bath',
    this.frame = 0xFFFFC928,
    this.frameEdge = 0xFF14304D,
    this.frameShadow = 0xFF14304D,
    this.ink = 0xFF14304D,
    this.inkSoft = 0xFF2F4E6C,
    this.heart = 0xFFFF5C8A,
    this.page = 0xFFE2F2F1,
    this.grout = 0xFFCCE5E3,
    this.water = 0xFFCBEDF5,
    this.water2 = 0xFFB5E2EE,
    this.veil = 0xDBCBEDF5,
    this.card = 0x9EFFFFFF,
    this.cardStrong = 0xD9FFFFFF,
    this.cardEdge = 0x2E14304D,
    this.bubbleFill = 0x80FFFFFF,
    this.bubbleEdge = 0xFF2E7FA8,
    this.shine = 0xFFFFFFFF,
    this.gold = 0xCCFFC928,
    this.goldEdge = 0xFFA86F00,
    this.pink = 0xFFE8437A,
    this.cyan = 0xFF1FB0D6,
    this.lemon = 0xFFF0BE00,
    this.good = 0xFF1E9E62,
    this.canvasInk = 0xFF14304D,
    this.canvasInkSoft = 0xFF3C5D7C,
    this.halo = 0xFFFFFFFF,
  });
}

const Map<String, ThemeDef> themes = {
  'bath': ThemeDef(),
  'ocean': ThemeDef(
      pattern: 'waves', ambient: 'ocean', frame: 0xFF6FD8C4, page: 0xFFD3ECF3, grout: 0xFFB6DCE8, water: 0xFF8AD8E8, water2: 0xFF3FA3C6,
      veil: 0xE06EC4DE, bubbleFill: 0x61FFFFFF, bubbleEdge: 0xFF0D5A80, canvasInk: 0xFF08283D, canvasInkSoft: 0xFF1D4A66),
  'sunset': ThemeDef(
      pattern: 'dots', ambient: 'sunset', frame: 0xFFFF9E6B, page: 0xFFFFE9DC, grout: 0xFFFFD2BC, water: 0xFFFFD7A8, water2: 0xFFFF9CA6,
      veil: 0xE0FFC8AA, bubbleFill: 0x73FFFFFF, bubbleEdge: 0xFFB03A68, canvasInk: 0xFF4A1631, canvasInkSoft: 0xFF7A3A58, cyan: 0xFF2CA3C9),
  'candy': ThemeDef(
      pattern: 'stripes', ambient: 'candy', frame: 0xFFFF9CCB, page: 0xFFFFF0F6, grout: 0xFFFFDDEB, water: 0xFFFFE6F3, water2: 0xFFE6D8FF,
      veil: 0xE6FFE2F2, bubbleFill: 0x8CFFFFFF, bubbleEdge: 0xFFB0459A, canvasInk: 0xFF4A1A47, canvasInkSoft: 0xFF7D4A7A),
  'night': ThemeDef(
      dark: true, pattern: 'stars', ambient: 'night', frame: 0xFFB89CFF, page: 0xFF120E2E, grout: 0xFF1E1846, frameShadow: 0x99000000,
      water: 0xFF221A5C, water2: 0xFF0B0A24, veil: 0xE6100C2C, bubbleFill: 0x1AC8BEFF, bubbleEdge: 0xFFC9BBFF, canvasInk: 0xFFF1EDFF,
      canvasInkSoft: 0xFFB6AADB, halo: 0xFF100C2C, gold: 0x8CFFC928, goldEdge: 0xFFFFD659, pink: 0xFFFF86C2, cyan: 0xFF7FDCF5,
      lemon: 0xFFFFE27A, card: 0x14FFFFFF, cardStrong: 0x26FFFFFF, cardEdge: 0x29FFFFFF),
  'spooky': ThemeDef(
      dark: true, pattern: 'dots', ambient: 'bats', frame: 0xFFFF8A1F, page: 0xFF1C1426, grout: 0xFF2A1E38, frameShadow: 0x99000000,
      water: 0xFF33204A, water2: 0xFF140C1E, veil: 0xE6180E22, bubbleFill: 0x14C8FFAA, bubbleEdge: 0xFFB7F27A, canvasInk: 0xFFF4FFE8,
      canvasInkSoft: 0xFFB9C9A8, halo: 0xFF140C1E, gold: 0x8CFFC928, goldEdge: 0xFFFFD659, pink: 0xFFFF7A5C, cyan: 0xFF9BF06B,
      lemon: 0xFFFFD45C, card: 0x14FFFFFF, cardStrong: 0x26FFFFFF, cardEdge: 0x29FFFFFF),
};

// ---------------------------------------------------------------- missions
class QuestDef {
  final String id;
  final String ev; // pop · game · score · streak · power · stage · daily · chain · stars
  final String match;
  final bool isMax;
  final int lo;
  final int hi;
  final int coins;
  final int xp;
  final String needMode;
  final Tx text;
  const QuestDef(this.id, this.ev, this.lo, this.hi, this.coins, this.xp, this.text,
      {this.match = '', this.isMax = false, this.needMode = ''});
}

const List<QuestDef> questsDaily = [
  QuestDef('d_pop', 'pop', 120, 200, 50, 40, Tx('Pop {n} bubbles', 'فرقع {n} فقاعة')),
  QuestDef('d_gold', 'pop', 6, 10, 60, 45, Tx('Pop {n} gold bubbles', 'فرقع {n} فقاعات ذهبية'), match: 'gold'),
  QuestDef('d_bomb', 'pop', 3, 5, 55, 40, Tx('Pop {n} bomb bubbles', 'فرقع {n} فقاعات متفجرة'), match: 'bomb'),
  QuestDef('d_tough', 'pop', 4, 7, 55, 40, Tx('Pop {n} armored bubbles', 'فرقع {n} فقاعات مدرّعة'), match: 'tough'),
  QuestDef('d_streak', 'streak', 15, 25, 60, 45, Tx('Pop {n} in a row', 'فرقع {n} فقاعة متتالية'), isMax: true),
  QuestDef('d_power', 'power', 3, 5, 50, 40, Tx('Use {n} powers', 'استخدم {n} قدرات')),
  QuestDef('d_games', 'game', 3, 4, 45, 35, Tx('Play {n} games', 'العب {n} جولات')),
  QuestDef('d_classic', 'score', 400, 700, 70, 50, Tx('Score {n} in one Classic run', 'اجمع {n} نقطة في جولة كلاسيكية واحدة'),
      match: 'classic', isMax: true),
  QuestDef('d_time', 'score', 300, 500, 70, 50, Tx('Score {n} in Time Rush', 'اجمع {n} نقطة في سباق الوقت'),
      match: 'time', isMax: true, needMode: 'time'),
  QuestDef('d_stage', 'stage', 1, 2, 60, 50, Tx('Clear {n} challenge stage(s)', 'اجتز {n} من مراحل التحدي'), needMode: 'challenge'),
  QuestDef('d_chain', 'chain', 6, 9, 65, 50, Tx('Pop {n} with one bomb chain', 'فرقع {n} بسلسلة تفجير واحدة'), isMax: true),
  QuestDef('d_mini', 'pop', 10, 16, 50, 40, Tx('Pop {n} mini bubbles', 'فرقع {n} فقاعة صغيرة'), match: 'mini'),
];

const List<QuestDef> questsWeekly = [
  QuestDef('w_pop', 'pop', 1200, 1600, 300, 220, Tx('Pop {n} bubbles this week', 'فرقع {n} فقاعة هذا الأسبوع')),
  QuestDef('w_gold', 'pop', 50, 70, 320, 220, Tx('Pop {n} gold bubbles', 'فرقع {n} فقاعة ذهبية'), match: 'gold'),
  QuestDef('w_daily', 'daily', 3, 4, 350, 250, Tx('Beat {n} daily challenges', 'تغلّب على {n} تحديات يومية')),
  QuestDef('w_power', 'power', 20, 30, 300, 220, Tx('Use {n} powers', 'استخدم {n} قدرة')),
  QuestDef('w_games', 'game', 15, 20, 280, 200, Tx('Play {n} games', 'العب {n} جولة')),
  QuestDef('w_streak', 'streak', 40, 50, 350, 250, Tx('Pop {n} in a row', 'فرقع {n} فقاعة متتالية'), isMax: true),
  QuestDef('w_stars', 'stars', 5, 8, 330, 240, Tx('Earn {n} new challenge stars', 'اكسب {n} نجوم تحدٍّ جديدة'), needMode: 'challenge'),
  QuestDef('w_classic', 'score', 1200, 1800, 380, 260, Tx('Score {n} in one Classic run', 'اجمع {n} نقطة في جولة كلاسيكية واحدة'),
      match: 'classic', isMax: true),
];

QuestDef? questDef(String id) {
  for (final q in questsDaily) {
    if (q.id == id) return q;
  }
  for (final q in questsWeekly) {
    if (q.id == id) return q;
  }
  return null;
}

// ---------------------------------------------------------------- level curve, rewards, daily gift
int xpForLevel(int l) => (90 + 45 * math.pow(l, 1.32)).round();
int levelRewardCoins(int l) => 40 + 12 * l;

class Gift {
  final int coins;
  final int xp;
  const Gift(this.coins, [this.xp = 0]);
}

const List<Gift> loginGifts = [Gift(50), Gift(75), Gift(100, 50), Gift(125), Gift(150, 60), Gift(200), Gift(400, 150)];

const Map<String, List<int>> tierReward = {
  'easy': [40, 30],
  'medium': [120, 80],
  'hard': [300, 200],
  'rare': [400, 250],
};

// ---------------------------------------------------------------- run balance
class Bal {
  static const int feverEvery = 35;
  static const int feverMs = 7000;
  static const double feverMul = 2;
  static const int multEvery = 5;
  static const int multMax = 5;
  static const List<double> powerEvery = [17, 27];
  static const List<double> eventFirst = [28, 40];
  static const List<double> eventEvery = [32, 50];
  static const int reliefMs = 3500;
  static const double coinsPerScore = 1 / 14;
  static const double xpPerScore = 1 / 6;
  static const double xpPerPop = 0.4;
  static const int zenCapCoins = 40;
  static const int zenCapXp = 150;
  static const double hitPadTouch = 10;
  static const double hitPadMouse = 5;
  static const int escapeTime = 2;
  static const int hazardTime = 5;
}

// ---------------------------------------------------------------- changelog
class ChangeEntry {
  final String v;
  final List<String> en;
  final List<String> ar;
  const ChangeEntry(this.v, this.en, this.ar);
}

const List<ChangeEntry> changelog = [
  ChangeEntry('2.0.0', [
    '11 bubble types and 4 powers',
    '6 modes, including 24 challenge stages and a daily challenge',
    'Levels, coins, a shop, missions and achievements',
    'Seasonal events, themes, music and Arabic support',
  ], [
    '11 نوعًا من الفقاعات و4 قدرات',
    '6 أنماط لعب، منها 24 مرحلة تحدٍّ وتحدٍّ يومي',
    'مستويات وعملات ومتجر ومهام وإنجازات',
    'أحداث موسمية وثيمات وموسيقى ودعم العربية',
  ]),
  ChangeEntry('3.0.0', [
    'Rebuilt from scratch as a native Android app',
    'A taller play area that fills modern phone screens',
    'Fresh look: glossier bubbles, chunkier buttons, smoother effects',
    'Vibration on pops, bombs and lost hearts',
  ], [
    'أُعيد بناؤها من الصفر كتطبيق أندرويد أصلي',
    'ساحة لعب أطول تملأ شاشات الهواتف الحديثة',
    'مظهر جديد: فقاعات أكثر لمعانًا وأزرار أوضح ومؤثرات أنعم',
    'اهتزاز عند الفرقعة والتفجير وخسارة القلوب',
  ]),
];
