// RENDER — canvas drawing: bubbles (skins + type marks), particles,
// floating text, banners, theme ambience and power overlays.
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../core/content.dart';
import '../core/engine.dart';
import '../core/save.dart';
import '../core/util.dart';
import 'kit.dart';

/// ARGB int with its alpha multiplied by [a].
Color ca(int argb, [double a = 1]) {
  final base = (argb >> 24) & 0xFF;
  final na = clampI((base * a).round(), 0, 255);
  return Color((argb & 0x00FFFFFF) | (na << 24));
}

Color hslc(double h, double s, double l, [double a = 1]) => Color(hsla(h, s / 100, l / 100, a));

Paint _fill(Color c) => Paint()..color = c;
Paint _stroke(Color c, double w, {StrokeCap cap = StrokeCap.butt}) => Paint()
  ..color = c
  ..style = PaintingStyle.stroke
  ..strokeWidth = w
  ..strokeCap = cap
  ..strokeJoin = StrokeJoin.round;

// ---------------------------------------------------------------- text cache
class TextCache {
  final Map<String, TextPainter> _m = {};
  TextPainter get(String text, double size, int color, {int stroke = 0, double strokeW = 0, IconData? icon}) {
    final key = '$text|${(size * 4).round()}|$color|$stroke|$strokeW|${icon?.codePoint}';
    final hit = _m[key];
    if (hit != null) return hit;
    if (_m.length > 400) _m.clear();
    TextStyle style;
    if (icon != null) {
      style = TextStyle(fontFamily: icon.fontFamily, package: icon.fontPackage, fontSize: size, color: Color(color), height: 1);
    } else {
      style = ts(size, height: 1.05);
      if (strokeW > 0) {
        style = style.copyWith(
            foreground: Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = strokeW
              ..strokeJoin = StrokeJoin.round
              ..color = Color(stroke));
      } else {
        style = style.copyWith(color: Color(color));
      }
    }
    final tp = TextPainter(
      text: TextSpan(text: icon != null ? String.fromCharCode(icon.codePoint) : text, style: style),
      textDirection: gLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout();
    _m[key] = tp;
    return tp;
  }

  void clear() => _m.clear();
}

final TextCache textCache = TextCache();

void drawCentered(Canvas c, TextPainter tp, double x, double y) {
  tp.paint(c, Offset(x - tp.width / 2, y - tp.height / 2));
}

/// Text with a halo outline, centred on (x, y).
void haloText(Canvas c, String s, double x, double y, double size, int color, int halo, double haloW) {
  if (haloW > 0) drawCentered(c, textCache.get(s, size, color, stroke: halo, strokeW: haloW), x, y);
  drawCentered(c, textCache.get(s, size, color), x, y);
}

void drawIconGlyph(Canvas c, String id, double x, double y, double size, int argb) {
  if (id == 'magnet') {
    paintMagnet(c, Offset(x, y), size, Color(argb));
    return;
  }
  if (id == 'coin') {
    paintCoin(c, Offset(x, y), size);
    return;
  }
  final ic = materialIcon(id);
  if (ic == null) return;
  drawCentered(c, textCache.get('', size, argb, icon: ic), x, y);
}

// ---------------------------------------------------------------- shapes
Path starPath(double x, double y, double r, double rot) {
  final p = Path();
  for (var i = 0; i < 10; i++) {
    final a = rot + (i * math.pi) / 5 - math.pi / 2;
    final rr = i.isOdd ? r * 0.45 : r;
    final px = x + math.cos(a) * rr, py = y + math.sin(a) * rr;
    if (i == 0) {
      p.moveTo(px, py);
    } else {
      p.lineTo(px, py);
    }
  }
  return p..close();
}

Path heartPath(double x, double y, double s) {
  return Path()
    ..moveTo(x, y + s * 0.9)
    ..cubicTo(x - s * 1.6, y - s * 0.1, x - s * 0.7, y - s * 1.3, x, y - s * 0.4)
    ..cubicTo(x + s * 0.7, y - s * 1.3, x + s * 1.6, y - s * 0.1, x, y + s * 0.9)
    ..close();
}

Path sparklePath(double x, double y, double s) {
  return Path()
    ..moveTo(x, y - s)
    ..quadraticBezierTo(x, y, x + s, y)
    ..quadraticBezierTo(x, y, x, y + s)
    ..quadraticBezierTo(x, y, x - s, y)
    ..quadraticBezierTo(x, y, x, y - s)
    ..close();
}

Rect _circ(double x, double y, double r) => Rect.fromCircle(center: Offset(x, y), radius: r);

void _arc(Canvas c, double x, double y, double r, double a0, double a1, Paint p) {
  c.drawArc(_circ(x, y, r), a0, a1 - a0, false, p);
}

/// Rotated-ellipse arc (like canvas `ellipse(x, y, rx, ry, rot, a0, a1)`).
void _ellipseArc(Canvas c, double x, double y, double rx, double ry, double rot, double a0, double a1, Paint p) {
  c.save();
  c.translate(x, y);
  c.rotate(rot);
  c.drawArc(Rect.fromCenter(center: Offset.zero, width: rx * 2, height: ry * 2), a0, a1 - a0, false, p);
  c.restore();
}

void _ellipse(Canvas c, double x, double y, double rx, double ry, Paint p, [double rot = 0]) {
  if (rot == 0) {
    c.drawOval(Rect.fromCenter(center: Offset(x, y), width: rx * 2, height: ry * 2), p);
  } else {
    c.save();
    c.translate(x, y);
    c.rotate(rot);
    c.drawOval(Rect.fromCenter(center: Offset.zero, width: rx * 2, height: ry * 2), p);
    c.restore();
  }
}

// ---------------------------------------------------------------- bubble bodies (skins)
void highlight(Canvas c, double x, double y, double r, Color col) {
  _arc(c, x, y, r * 0.62, math.pi * 1.08, math.pi * 1.4, _stroke(col, math.max(2, r * 0.13), cap: StrokeCap.round));
  const ha = math.pi * 1.54;
  c.drawCircle(Offset(x + math.cos(ha) * r * 0.62, y + math.sin(ha) * r * 0.62), math.max(1.2, r * 0.07), _fill(col));
}

void soapBody(Canvas c, double x, double y, double r, Bubble b, double t, Color fill, Color edge, List<Color> sheen, Color shine) {
  c.drawCircle(
      Offset(x, y),
      r,
      Paint()
        ..shader = ui.Gradient.radial(Offset(x, y), r, [withA(shine, 0.5), fill, Color.lerp(fill, edge, 0.28)!], const [0, 0.62, 1],
            TileMode.clamp, null, Offset(x - r * 0.35, y - r * 0.4), r * 0.05));
  final lw = math.max(1.6, r * 0.11);
  final spin = t * 0.0012 + b.hue;
  for (var k = 0; k < sheen.length; k++) {
    final a = spin + k * (tau / sheen.length);
    _arc(c, x, y, math.max(0.5, r - lw * 0.9), a, a + 0.9, _stroke(withA(sheen[k], 0.8), lw, cap: StrokeCap.round));
  }
  c.drawCircle(Offset(x, y), r, _stroke(edge, 2));
  highlight(c, x, y, r, shine);
}

typedef SkinFn = void Function(Canvas c, double x, double y, double r, Bubble b, double t, bool face);

final Map<String, SkinFn> skins = {
  'soap': (c, x, y, r, b, t, face) {
    final th = Pal.th;
    soapBody(c, x, y, r, b, t, Color(th.bubbleFill), Color(th.bubbleEdge), [Color(th.pink), Color(th.cyan), Color(th.lemon)],
        Color(th.shine));
  },
  'candy': (c, x, y, r, b, t, face) {
    final h = (b.hue / tau) * 360;
    c.drawCircle(Offset(x, y), r, _fill(hslc(h, 90, 76, 0.78)));
    c.save();
    c.clipPath(Path()..addOval(_circ(x, y, math.max(1, r - 1))));
    final sp = t * 0.0006 + b.phase;
    final p = _stroke(const Color(0xBFFFFFFF), r * 0.22);
    for (var k = -1; k <= 1; k++) {
      _arc(c, x + math.cos(sp) * r * 0.2 + k * r * 0.75, y + r * 1.2, r * 1.3, math.pi * 1.2, math.pi * 1.75, p);
    }
    c.restore();
    c.drawCircle(Offset(x, y), r, _stroke(hslc(h, 60, 38), 2));
    highlight(c, x, y, r, Colors.white);
  },
  'glass': (c, x, y, r, b, t, face) {
    final h = (b.hue / tau) * 360;
    c.drawCircle(
        Offset(x, y),
        r,
        Paint()
          ..shader = ui.Gradient.radial(Offset(x, y), r, [const Color(0xE6FFFFFF), hslc(h, 70, 62, 0.6)], null, TileMode.clamp, null,
              Offset(x - r * 0.35, y - r * 0.4), r * 0.1));
    c.save();
    c.clipPath(Path()..addOval(_circ(x, y, math.max(1, r - 1))));
    final sp = t * 0.0009 + b.phase;
    c.drawPath(
        Path()
          ..moveTo(x - r, y + math.sin(sp) * r * 0.3)
          ..cubicTo(x - r * 0.3, y - r * 0.8, x + r * 0.3, y + r * 0.8, x + r, y + math.cos(sp) * r * 0.3),
        _stroke(hslc(h + 30, 85, 48, 0.85), r * 0.2));
    c.restore();
    c.drawCircle(Offset(x, y), r, _stroke(hslc(h, 50, 32), 2));
    highlight(c, x, y, r, Colors.white);
  },
  'jelly': (c, x, y, r, b, t, face) {
    final h = (b.hue / tau) * 360;
    final w = math.sin(t * 0.008 + b.phase) * 0.07;
    c.save();
    c.translate(x, y);
    c.scale(1 + w, 1 - w);
    c.drawCircle(Offset.zero, r, _fill(hslc(h, 92, 62, 0.66)));
    _ellipse(c, -r * 0.15, -r * 0.45, r * 0.5, r * 0.22, _fill(const Color(0x8CFFFFFF)), -0.3);
    c.drawCircle(Offset.zero, r, _stroke(hslc(h, 75, 35), 2.2));
    c.drawCircle(Offset(r * 0.35, r * 0.3), r * 0.08, _fill(const Color(0xCCFFFFFF)));
    c.restore();
  },
  'neon': (c, x, y, r, b, t, face) {
    final h = (b.hue / tau) * 360 + t * 0.02;
    c.drawCircle(Offset(x, y), r, _fill(const Color(0x590C0A28)));
    for (final lw in const [(9.0, 0.14), (5.0, 0.3), (2.4, 1.0)]) {
      c.drawCircle(Offset(x, y), math.max(1, r - 1), _stroke(hslc(h, 100, 62, lw.$2), lw.$1));
    }
    highlight(c, x, y, r * 0.9, hslc(h, 100, 85));
  },
  'planet': (c, x, y, r, b, t, face) {
    final h = (b.hue / tau) * 360;
    final tilt = -0.45 + math.sin(b.phase) * 0.2;
    final ring = _stroke(hslc(h + 50, 70, 72), math.max(2, r * 0.13));
    _ellipseArc(c, x, y, r * 1.45, r * 0.38, tilt, math.pi, tau, ring);
    c.drawCircle(Offset(x, y), r, _fill(hslc(h, 55, 58, 0.95)));
    c.save();
    c.clipPath(Path()..addOval(_circ(x, y, r)));
    final band = _fill(hslc(h, 55, 45, 0.6));
    c.drawRect(Rect.fromLTWH(x - r, y - r * 0.25, r * 2, r * 0.22), band);
    c.drawRect(Rect.fromLTWH(x - r, y + r * 0.25, r * 2, r * 0.14), band);
    c.restore();
    _ellipseArc(c, x, y, r * 1.45, r * 0.38, tilt, 0, math.pi, ring);
    c.drawCircle(Offset(x, y), r, _stroke(hslc(h, 50, 30), 1.5));
    highlight(c, x, y, r, const Color(0xCCFFFFFF));
  },
  'golden': (c, x, y, r, b, t, face) {
    c.drawCircle(
        Offset(x, y),
        r,
        Paint()
          ..shader = ui.Gradient.radial(Offset(x, y), r, const [Color(0xFFFFF4B8), Color(0xFFFFC928), Color(0xFFC98A00)], const [0, 0.6, 1],
              TileMode.clamp, null, Offset(x - r * 0.3, y - r * 0.35), r * 0.1));
    c.drawCircle(Offset(x, y), r, _stroke(const Color(0xFF7A4E00), 2));
    highlight(c, x, y, r, Colors.white);
  },
  'pumpkin': (c, x, y, r, b, t, face) {
    c.drawRect(Rect.fromLTWH(x - r * 0.08, y - r * 1.12, r * 0.16, r * 0.3), _fill(const Color(0xFF3E8E2E)));
    _ellipse(
        c,
        x,
        y,
        r * 1.02,
        r * 0.92,
        Paint()
          ..shader = ui.Gradient.radial(Offset(x - r * 0.3, y - r * 0.3), r * 1.4, const [Color(0xFFFFB050), Color(0xFFFF8A1F), Color(0xFFE06A0A)],
              const [0, 0.55, 1]));
    final rib = _stroke(const Color(0xFFC8590A), math.max(1.5, r * 0.08));
    for (final k in const [-0.5, 0.0, 0.5]) {
      _ellipse(c, x + k * r * 0.6, y, r * (0.45 - k.abs() * 0.2), r * 0.9, rib);
    }
    _ellipse(c, x, y, r * 1.02, r * 0.92, _stroke(const Color(0xFF7A3300), 2));
    if (face) {
      final f = _fill(const Color(0xFF3A1A00));
      c.drawPath(
          Path()
            ..moveTo(x - r * 0.45, y - r * 0.05)
            ..lineTo(x - r * 0.25, y - r * 0.35)
            ..lineTo(x - r * 0.08, y - r * 0.05)
            ..close(),
          f);
      c.drawPath(
          Path()
            ..moveTo(x + r * 0.45, y - r * 0.05)
            ..lineTo(x + r * 0.25, y - r * 0.35)
            ..lineTo(x + r * 0.08, y - r * 0.05)
            ..close(),
          f);
      c.drawPath(
          Path()
            ..moveTo(x - r * 0.5, y + r * 0.2)
            ..quadraticBezierTo(x, y + r * 0.75, x + r * 0.5, y + r * 0.2)
            ..quadraticBezierTo(x, y + r * 0.45, x - r * 0.5, y + r * 0.2)
            ..close(),
          f);
    }
    highlight(c, x, y, r, const Color(0x99FFFFFF));
  },
  'snowball': (c, x, y, r, b, t, face) {
    c.drawCircle(Offset(x, y), r, _fill(const Color(0xFFFAFDFF)));
    c.save();
    c.clipPath(Path()..addOval(_circ(x, y, r)));
    c.drawCircle(Offset(x + r * 0.35, y + r * 0.45), r * 0.95, _fill(const Color(0x7396C8EB)));
    c.restore();
    c.drawCircle(Offset(x, y), r, _stroke(const Color(0xFF7FB6D8), 2));
    for (final d in const [(-0.3, 0.2), (0.1, -0.35), (0.35, 0.1)]) {
      c.drawCircle(Offset(x + d.$1 * r, y + d.$2 * r), r * 0.06, _fill(const Color(0xFFBFE3F8)));
    }
    if (face) {
      final eye = _fill(const Color(0xFF14304D));
      c.drawCircle(Offset(x - r * 0.25, y - r * 0.1), r * 0.08, eye);
      c.drawCircle(Offset(x + r * 0.25, y - r * 0.1), r * 0.08, eye);
      c.drawPath(
          Path()
            ..moveTo(x, y + r * 0.02)
            ..lineTo(x + r * 0.35, y + r * 0.12)
            ..lineTo(x, y + r * 0.2)
            ..close(),
          _fill(const Color(0xFFFF8A1F)));
    }
    highlight(c, x, y, r, Colors.white);
  },
  'lantern': (c, x, y, r, b, t, face) {
    final glow = 0.75 + 0.25 * math.sin(t * 0.004 + b.phase);
    final wood = _fill(const Color(0xFF6B3E12));
    c.drawRect(Rect.fromLTWH(x - r * 0.45, y - r * 1.05, r * 0.9, r * 0.22), wood);
    c.drawRect(Rect.fromLTWH(x - r * 0.35, y + r * 0.85, r * 0.7, r * 0.2), wood);
    c.drawCircle(Offset(x, y - r * 1.15), r * 0.15, _stroke(const Color(0xFF6B3E12), 1.6));
    final g = (170 + 40 * glow).round();
    _ellipse(c, x, y, r * 0.8, r * 0.95, _fill(Color.fromRGBO(255, g, 70, 0.75 + 0.2 * glow)));
    final rib = _stroke(const Color(0xFF8A4F12), math.max(1.4, r * 0.07));
    for (final k in const [-0.45, 0.0, 0.45]) {
      _ellipse(c, x, y, r * 0.8 * k.abs() + 0.01, r * 0.95, rib);
    }
    _ellipse(c, x, y, r * 0.8, r * 0.95, _stroke(const Color(0xFF8A4F12), 2));
    c.drawCircle(Offset(x, y + r * 0.1), r * 0.28, _fill(Color.fromRGBO(255, 255, 220, 0.6 * glow)));
  },
  'beach': (c, x, y, r, b, t, face) {
    const cols = [Color(0xFFFF5C5C), Colors.white, Color(0xFFFFC928), Colors.white, Color(0xFF1FB0D6), Colors.white];
    final sp = t * 0.0015 + b.phase;
    for (var k = 0; k < 6; k++) {
      c.drawArc(_circ(x, y, r), sp + (k * tau) / 6, tau / 6, true, _fill(cols[k]));
    }
    c.drawCircle(Offset(x, y), r * 0.2, _fill(Colors.white));
    c.drawCircle(Offset(x, y), r, _stroke(const Color(0xFF14304D), 2));
    highlight(c, x, y, r, const Color(0xD9FFFFFF));
  },
};

const Map<String, String> seasonSkin = {'pumpkin': 'pumpkin', 'snow': 'snowball', 'lantern': 'lantern', 'beach': 'beach'};

// ---------------------------------------------------------------- type marks
void badge(Canvas c, double x, double y, double r, String icon, int col) {
  c.drawCircle(Offset(x, y), r * 0.56, _fill(const Color(0xEBFFFFFF)));
  c.drawCircle(Offset(x, y), r * 0.56, _stroke(Color(col), 1.6));
  drawIconGlyph(c, icon, x, y, r * 0.78, col);
}

const Map<String, int> powerColor = {'slow': 0xFF2E7FA8, 'blast': 0xFFE8437A, 'magnet': 0xFFB03A2E, 'shield': 0xFF1E9E62};
const Map<String, String> powerIcon = {'slow': 'slow', 'blast': 'blast', 'magnet': 'magnet', 'shield': 'shield'};

void drawBubble(Canvas c, Bubble b, double t, String skinKey, {bool danger = false, bool preview = false}) {
  final th = Pal.th;
  final age = t - b.born;
  var r = b.r * (age < 220 && !preview ? math.max(0, easeOutBack(age / 220)) : 1);
  if (t - b.hitAt < 160) r *= 1 + 0.12 * math.sin(((t - b.hitAt) / 160) * math.pi);
  if (r < 0.5) return;
  final x = b.x, y = b.y;
  if (b.deco) c.saveLayer(_circ(x, y, r * 1.6), Paint()..color = const Color(0x80000000));
  final skin = skins[skinKey] ?? skins['soap']!;

  switch (b.type) {
    case 'gold':
      soapBody(c, x, y, r, b, t, Color(th.gold), Color(th.goldEdge), [Color(th.lemon), Color(th.shine)], Color(th.shine));
      final sp = sparklePath(x, y, r * 0.42);
      c.drawPath(sp, _fill(Color(th.shine)));
      c.drawPath(sp, _stroke(Color(th.goldEdge), 1.2));
      break;
    case 'bomb':
      final pulse = 0.5 + 0.5 * math.sin(t * 0.012 + b.phase);
      c.drawPath(
          Path()
            ..moveTo(x + r * 0.35, y - r * 0.8)
            ..quadraticBezierTo(x + r * 0.7, y - r * 1.25, x + r * 0.95, y - r * 1.05),
          _stroke(const Color(0xFF5A3A1A), 2.4, cap: StrokeCap.round));
      c.drawCircle(
          Offset(x, y),
          r,
          Paint()
            ..shader = ui.Gradient.radial(Offset(x - r * 0.3, y - r * 0.35), r * 1.3, const [Color(0xFF555B80), Color(0xFF2E3350), Color(0xFF1C2036)],
                const [0, 0.55, 1]));
      c.drawCircle(Offset(x, y), r, _stroke(Color.fromRGBO(255, 92, 92, 0.5 + 0.5 * pulse), 2));
      highlight(c, x, y, r, const Color(0xD9FFFFFF));
      c.drawPath(sparklePath(x + r * 0.97, y - r * 1.07, 3.5 + pulse * 3), _fill(pulse > 0.5 ? const Color(0xFFFFD23F) : const Color(0xFFFF8A3D)));
      drawCentered(c, textCache.get('!', r * 0.8, 0xFFFF6B6B), x + 1, y + r * 0.06);
      break;
    case 'ice':
      c.drawCircle(
          Offset(x, y),
          r,
          Paint()
            ..shader = ui.Gradient.radial(Offset(x - r * 0.3, y - r * 0.35), r * 1.3, const [Color(0xF2FFFFFF), Color(0xC7CDF2FF), Color(0xD99BD8F2)],
                const [0, 0.55, 1]));
      c.drawCircle(Offset(x, y), r, _stroke(const Color(0xFF4DAFDF), 2.2));
      final line = _stroke(const Color(0xFF2A8BC2), math.max(1.5, r * 0.08), cap: StrokeCap.round);
      for (var k = 0; k < 3; k++) {
        final a = (k * math.pi) / 3 + t * 0.0004;
        final dx = math.cos(a) * r * 0.55, dy = math.sin(a) * r * 0.55;
        c.drawLine(Offset(x - dx, y - dy), Offset(x + dx, y + dy), line);
      }
      highlight(c, x, y, r, Colors.white);
      break;
    case 'tough':
      c.drawCircle(
          Offset(x, y),
          r,
          Paint()
            ..shader = ui.Gradient.radial(Offset(x - r * 0.3, y - r * 0.35), r * 1.3, const [Color(0xCCE3EAF2), Color(0xA6AAB9CD), Color(0xB3808FA6)],
                const [0, 0.6, 1]));
      final gap = math.max(2, r * 0.21);
      for (var k = 0; k < b.hp; k++) {
        c.drawCircle(Offset(x, y), math.max(1, r - k * gap), _stroke(k == 0 ? const Color(0xFF4F5F75) : const Color(0xFF6E7F96), math.max(1.5, r * 0.12)));
      }
      if (b.hp < b.maxHp) {
        final crack = Path()
          ..moveTo(x - r * 0.2, y - r * 0.6)
          ..lineTo(x, y - r * 0.2)
          ..lineTo(x - r * 0.15, y + r * 0.1)
          ..lineTo(x + r * 0.2, y + r * 0.45);
        if (b.hp < b.maxHp - 1) {
          crack
            ..moveTo(x, y - r * 0.2)
            ..lineTo(x + r * 0.4, y - r * 0.25);
        }
        c.drawPath(crack, _stroke(const Color(0xB3283246), 1.4));
      }
      drawCentered(c, textCache.get('${b.hp}', r * 0.62, 0xFF2F3B4E), x, y + 1);
      highlight(c, x, y, r, const Color(0xE6FFFFFF));
      break;
    case 'spiky':
      final rot = t * 0.0015 + b.phase;
      final spikes = Path();
      for (var k = 0; k < 24; k++) {
        final a = rot + (k * tau) / 24;
        final rr = k.isOdd ? r * 0.88 : r * 1.18;
        if (k == 0) {
          spikes.moveTo(x + math.cos(a) * rr, y + math.sin(a) * rr);
        } else {
          spikes.lineTo(x + math.cos(a) * rr, y + math.sin(a) * rr);
        }
      }
      spikes.close();
      c.drawPath(spikes, _fill(const Color(0xFF8E4FD8)));
      c.drawPath(spikes, _stroke(const Color(0xFF3E1C6E), 2));
      c.drawCircle(Offset(x, y), r * 0.78, _fill(const Color(0xFFB488F0)));
      final face = _stroke(const Color(0xFF2A0F52), math.max(1.6, r * 0.1), cap: StrokeCap.round);
      c.drawLine(Offset(x - r * 0.42, y - r * 0.28), Offset(x - r * 0.12, y - r * 0.12), face);
      c.drawLine(Offset(x + r * 0.42, y - r * 0.28), Offset(x + r * 0.12, y - r * 0.12), face);
      _arc(c, x, y + r * 0.42, r * 0.28, math.pi * 1.15, math.pi * 1.85, face);
      break;
    case 'rainbow':
      final sp = t * 0.003;
      final lw = math.max(3.0, r * 0.26);
      for (var k = 0; k < 6; k++) {
        _arc(c, x, y, math.max(1, r - lw / 2), sp + (k * tau) / 6, sp + ((k + 1) * tau) / 6 + 0.02, _stroke(hslc(k * 60 + t * 0.1, 92, 60), lw));
      }
      c.drawCircle(Offset(x, y), r * 0.66, _fill(const Color(0xD9FFFFFF)));
      final st = starPath(x, y, r * 0.45, t * 0.002);
      c.drawPath(st, _fill(const Color(0xFFFFC928)));
      c.drawPath(st, _stroke(const Color(0xFFA86F00), 1.2));
      break;
    case 'event':
      final kind = b.season != null ? (seasonSkin[b.season!.bubble] ?? 'pumpkin') : 'pumpkin';
      (skins[kind] ?? skins['soap']!)(c, x, y, r, b, t, true);
      break;
    default:
      skin(c, x, y, r, b, t, false);
      if (b.type == 'splitter') {
        for (var k = 0; k < 3; k++) {
          final a = t * 0.002 + (k * tau) / 3;
          final o = Offset(x + math.cos(a) * r * 0.38, y + math.sin(a) * r * 0.38);
          c.drawCircle(o, r * 0.18, _fill(Color(th.bubbleEdge)));
          c.drawCircle(o, r * 0.18, _stroke(Color(th.shine), 1.5));
        }
      } else if (b.type == 'heart') {
        final hp = heartPath(x, y, r * 0.42);
        c.drawPath(hp, _fill(const Color(0xFFFF5C8A)));
        c.drawPath(hp, _stroke(const Color(0xFFA81D4A), 1.5));
      } else if (b.type == 'clock') {
        badge(c, x, y, r, 'clock', 0xFF1E9E62);
      } else if (b.type == 'power' && b.power.isNotEmpty) {
        final col = powerColor[b.power] ?? 0xFF2E7FA8;
        final pulse = 1 + 0.06 * math.sin(t * 0.01);
        c.drawCircle(Offset(x, y), r * pulse, _stroke(Color(col), 2.5));
        badge(c, x, y, r * 1.08, powerIcon[b.power] ?? 'blast', col);
      }
  }

  if (b.highlight && !b.deco) {
    final p = (t * 0.004) % 1;
    c.drawCircle(
        Offset(x, y), r + 6 + p * 14, _stroke(ca(b.type == 'spiky' ? 0xFF8E4FD8 : th.canvasInk, 1 - p), 3));
  }
  if (danger && !b.deco) {
    final p = 0.5 + 0.5 * math.sin(t * 0.02);
    c.drawCircle(Offset(x, y), r + 4, _stroke(ca(0xFFFF3B5C, 0.45 + 0.45 * p), 2.5));
  }
  if (b.deco) c.restore();
}

// ---------------------------------------------------------------- ambience
class _AmbPt {
  final double x, y, s, p, h;
  _AmbPt(this.x, this.y, this.s, this.p, this.h);
}

final List<_AmbPt> _amb = List.generate(46, (_) => _AmbPt(frand(0, 1), frand(0, 1), frand(0, 1), frand(0, tau), frand(0, 360)));

void drawAmbient(Canvas c, double t, double hgt, SeasonDef? sea) {
  final th = Pal.th;
  final tt = reduceMotion ? 0.0 : t;
  const w = worldW;
  switch (th.ambient) {
    case 'bath':
      for (var k = 0; k < 3; k++) {
        final p = Path();
        for (var x = 0.0; x <= w; x += 12) {
          final y = 14 + k * 11 + math.sin(x * 0.03 + tt * 0.0015 + k) * 4;
          if (x == 0) {
            p.moveTo(x, y);
          } else {
            p.lineTo(x, y);
          }
        }
        c.drawPath(p, _stroke(ca(th.shine, 0.2 - k * 0.05), 2));
      }
      // soft light shafts
      for (var k = 0; k < 2; k++) {
        final x0 = 70 + k * 170 + math.sin(tt * 0.0003 + k) * 18;
        c.drawPath(
            Path()
              ..moveTo(x0, 0)
              ..lineTo(x0 + 36, 0)
              ..lineTo(x0 - 20, hgt)
              ..lineTo(x0 - 70, hgt)
              ..close(),
            _fill(const Color(0x0FFFFFFF)));
      }
      break;
    case 'ocean':
      for (var k = 0; k < 3; k++) {
        final x0 = 40 + k * 120 + math.sin(tt * 0.0004 + k) * 20;
        c.drawPath(
            Path()
              ..moveTo(x0, 0)
              ..lineTo(x0 + 40, 0)
              ..lineTo(x0 - 30, hgt)
              ..lineTo(x0 - 80, hgt)
              ..close(),
            _fill(const Color(0x14FFFFFF)));
      }
      final weed = _stroke(const Color(0x520E6B5C), 6, cap: StrokeCap.round);
      for (var k = 0; k < 5; k++) {
        final bx = 30 + k * 75 + (k % 2) * 12.0, hh = 50 + (k % 3) * 22.0;
        c.drawPath(
            Path()
              ..moveTo(bx, hgt + 4)
              ..quadraticBezierTo(bx + math.sin(tt * 0.0012 + k) * 16, hgt - hh * 0.5, bx + math.sin(tt * 0.0015 + k + 1) * 12, hgt - hh),
            weed);
      }
      break;
    case 'sunset':
      c.drawRect(
          Rect.fromLTWH(0, 0, w, hgt),
          Paint()
            ..shader = ui.Gradient.radial(Offset(w * 0.78, hgt * 0.16), 120, const [Color(0x8CFFF0AA), Color(0x00FFC896)]));
      for (var k = 0; k < 4; k++) {
        c.drawRect(Rect.fromLTWH(0, hgt * 0.55 + k * 26 + math.sin(tt * 0.001 + k) * 3, w, 3), _fill(const Color(0x1FFFFFFF)));
      }
      break;
    case 'candy':
      for (final p in _amb) {
        final y = ((p.y * hgt + tt * 0.012 * (0.5 + p.s)) % (hgt + 20)) - 10;
        c.save();
        c.translate(p.x * w, y);
        c.rotate(p.p + tt * 0.001);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-4, -1.5, 8, 3), const Radius.circular(1.5)), _fill(hslc(p.h, 85, 70, 0.5)));
        c.restore();
      }
      break;
    case 'night':
      for (final p in _amb) {
        final a = 0.25 + 0.6 * (0.5 + 0.5 * math.sin(tt * 0.002 * (0.5 + p.s) + p.p));
        c.drawCircle(Offset(p.x * w, p.y * hgt), 0.6 + p.s * 1.3, _fill(Color.fromRGBO(255, 255, 255, a)));
      }
      break;
    case 'bats':
      c.drawCircle(Offset(w * 0.8, hgt * 0.13), 26, _fill(const Color(0xE6FFF3C4)));
      c.drawCircle(Offset(w * 0.8 + 9, hgt * 0.13 - 5), 22, _fill(const Color(0x8C140A1E)));
      break;
  }
  if (sea != null) {
    switch (sea.ambient) {
      case 'snow':
        for (final p in _amb) {
          final y = ((p.y * hgt + tt * 0.02 * (0.4 + p.s)) % (hgt + 10)) - 5;
          c.drawCircle(Offset(p.x * w + math.sin(tt * 0.001 + p.p) * 8, y), 1 + p.s * 1.6, _fill(const Color(0x8CFFFFFF)));
        }
        break;
      case 'bats':
        final f = _fill(const Color(0x5A1E102E));
        for (var k = 0; k < 3; k++) {
          final p = _amb[k];
          final x = ((p.x * w + tt * 0.03 * (0.6 + p.s)) % (w + 60)) - 30;
          final y = 34 + p.y * 90 + math.sin(tt * 0.003 + k) * 8;
          final fl = math.sin(tt * 0.02 + k * 2) * 5;
          c.drawPath(
              Path()
                ..moveTo(x, y)
                ..quadraticBezierTo(x - 8, y - 6 - fl, x - 14, y + 1)
                ..quadraticBezierTo(x - 7, y - 1, x, y + 3)
                ..quadraticBezierTo(x + 7, y - 1, x + 14, y + 1)
                ..quadraticBezierTo(x + 8, y - 6 - fl, x, y)
                ..close(),
              f);
        }
        break;
      case 'lanterns':
        for (var k = 0; k < 4; k++) {
          final x = 45 + k * 90.0, len = 20 + (k % 2) * 16.0;
          c.drawLine(Offset(x, 0), Offset(x, len), _stroke(const Color(0x99785020), 1.2));
          final fake = Bubble(type: 'normal', baseX: x, y: len + 10, r: 8, vy: 0, wa: 0, wf: 0, phase: k.toDouble(), hue: 0, born: -9999, hp: 1);
          skins['lantern']!(c, x, len + 10, 8, fake, tt, false);
        }
        break;
      case 'sun':
        final ray = _stroke(const Color(0x2EFFD23F), 3, cap: StrokeCap.round);
        for (var k = 0; k < 8; k++) {
          final a = (k * tau) / 8 + tt * 0.0003;
          c.drawLine(Offset(w - 20 + math.cos(a) * 30, 20 + math.sin(a) * 30), Offset(w - 20 + math.cos(a) * 52, 20 + math.sin(a) * 52), ray);
        }
        break;
    }
  }
}

// ---------------------------------------------------------------- the game painter
class GamePainter extends CustomPainter {
  final Engine e;
  final SeasonDef? Function() season;
  GamePainter(this.e, this.season, Listenable repaint) : super(repaint: repaint);

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final th = Pal.th;
    final t = e.clock;
    final h = e.H;
    final rs = e.r;
    final playing = e.inRun && rs != null;
    final scale = size.width / worldW;
    canvas.save();
    canvas.scale(scale, scale);
    canvas.clipRect(Rect.fromLTWH(0, 0, worldW, h));
    drawAmbient(canvas, t, h, season());

    canvas.save();
    if (e.shake > 0) canvas.translate(frand(-e.shake, e.shake) * 0.5, frand(-e.shake, e.shake) * 0.5);
    final skin = Save.data.skin;
    final livesMode = playing && rs.maxLives > 0 && !(e.cfg?.noFail ?? true);
    final shield = playing && e.run < (rs.active['shield'] ?? 0);
    for (final b in e.bubs) {
      if (b.dead) continue;
      final def = bubbles[b.type]!;
      final danger = livesMode && !def.hazard && !def.bonus && !b.harmless && b.y < 70 && !shield;
      drawBubble(canvas, b, t, skin, danger: danger);
    }

    // flash (bomb / spiky)
    final fx = e.fx;
    final fa = t - fx.flashAt;
    if (fa < 220) {
      canvas.drawRect(
          Rect.fromLTWH(-20, -20, worldW + 40, h + 40),
          Paint()
            ..shader = ui.Gradient.radial(Offset(fx.flashX, fx.flashY), 120, [ca(fx.flashCol, 0.5 * (1 - fa / 220)), ca(fx.flashCol, 0)]));
    }
    for (final rg in fx.rings) {
      final p = rg.age / rg.life;
      canvas.drawCircle(Offset(rg.x, rg.y), rg.r + rg.grow * easeOut(p), _stroke(ca(rg.color, 1 - p), rg.w * (1 - p * 0.6)));
    }
    for (final q in fx.particles) {
      final p = q.age / q.life;
      final a = q.twinkle ? (1 - p) * (0.5 + 0.5 * math.sin(q.age * 0.05)) : 1 - p;
      final col = ca(q.color, a);
      final s = q.s * (1 - p * 0.4);
      switch (q.kind) {
        case PKind.rect:
          canvas.save();
          canvas.translate(q.x, q.y);
          canvas.rotate(q.rot);
          canvas.drawRect(Rect.fromLTWH(-s, -s * 0.5, s * 2, s), _fill(col));
          canvas.restore();
          break;
        case PKind.star:
          canvas.drawPath(starPath(q.x, q.y, s * 1.4, q.rot), _fill(col));
          break;
        case PKind.heart:
          canvas.drawPath(heartPath(q.x, q.y, s), _fill(col));
          break;
        case PKind.line:
          canvas.drawLine(Offset(q.x, q.y), Offset(q.x - q.vx * 60, q.y - q.vy * 60), _stroke(col, s, cap: StrokeCap.round));
          break;
        case PKind.shard:
          canvas.save();
          canvas.translate(q.x, q.y);
          canvas.rotate(q.rot);
          canvas.drawPath(
              Path()
                ..moveTo(0, -s)
                ..lineTo(s * 0.8, s * 0.7)
                ..lineTo(-s * 0.8, s * 0.7)
                ..close(),
              _fill(col));
          canvas.restore();
          break;
        case PKind.flake:
          final fp = _stroke(col, 1.2);
          for (var k = 0; k < 3; k++) {
            final an = q.rot + (k * math.pi) / 3;
            canvas.drawLine(Offset(q.x - math.cos(an) * s, q.y - math.sin(an) * s), Offset(q.x + math.cos(an) * s, q.y + math.sin(an) * s), fp);
          }
          break;
        case PKind.dot:
          canvas.drawCircle(Offset(q.x, q.y), s, _fill(col));
          break;
      }
    }
    canvas.restore(); // shake

    // power and status overlays
    if (playing) {
      final full = Rect.fromLTWH(0, 0, worldW, h);
      if (e.run < rs.frozenUntil) {
        final left = (rs.frozenUntil - e.run) / (bubbles['ice']!.duration);
        final a = clampD(left * 1.5, 0, 1);
        canvas.drawRect(full, _fill(Color.fromRGBO(190, 235, 255, 0.16 * a)));
        canvas.drawRect(
            full,
            Paint()
              ..shader = ui.Gradient.radial(Offset(worldW / 2, h / 2), h * 0.75,
                  [const Color(0x00DCF8FF), Color.fromRGBO(220, 248, 255, 0.85 * a)], const [0.4, 1]));
        final flake = _stroke(Color.fromRGBO(255, 255, 255, 0.5 * a), 2, cap: StrokeCap.round);
        for (final f in [(22.0, 24.0, 9.0), (worldW - 26, 30.0, 7.0), (28.0, h - 30, 8.0), (worldW - 24, h - 26, 10.0)]) {
          for (var k = 0; k < 3; k++) {
            final an = (k * math.pi) / 3;
            canvas.drawLine(Offset(f.$1 - math.cos(an) * f.$3, f.$2 - math.sin(an) * f.$3),
                Offset(f.$1 + math.cos(an) * f.$3, f.$2 + math.sin(an) * f.$3), flake);
          }
        }
      }
      if (e.run < (rs.active['slow'] ?? 0)) canvas.drawRect(full, _fill(const Color(0x14508CFF)));
      if (shield) {
        final dur = rs.activeDur['shield'] ?? 9000;
        final left = ((rs.active['shield'] ?? 0) - e.run) / dur;
        final p = 0.6 + 0.4 * math.sin(t * 0.008);
        canvas.drawRect(
            Rect.fromLTWH(0, 0, worldW, 22),
            Paint()
              ..shader = ui.Gradient.linear(Offset.zero, const Offset(0, 22), [Color.fromRGBO(95, 216, 245, 0.75 * p), const Color(0x005FD8F5)]));
        canvas.drawRect(Rect.fromLTWH(0, 0, worldW * clampD(left, 0, 1), 3), _fill(const Color(0xE6FFFFFF)));
      }
      if (e.run < (rs.active['magnet'] ?? 0) && (e.pointerActive || t < e.pointerUntil)) {
        final a = 0.35 + 0.15 * math.sin(t * 0.01);
        final dash = _stroke(Color.fromRGBO(176, 58, 46, a), 2);
        const segs = 28;
        final off = t * 0.0006;
        for (var k = 0; k < segs; k++) {
          final a0 = off + k * tau / segs;
          _arc(canvas, e.pointerX, e.pointerY, 125, a0, a0 + tau / segs * 0.55, dash);
        }
      }
      if (e.fever) {
        final p = 0.5 + 0.5 * math.sin(t * 0.01);
        canvas.drawRRect(RRect.fromRectAndRadius(full.deflate(3), const Radius.circular(14)), _stroke(hslc(t * 0.25, 95, 62, 0.8), 6 + 3 * p));
        if (!reduceMotion && frand(0, 1) < 0.3) {
          fx.add(Particle(
              x: frand(0, worldW), y: h + 2, vx: 0, vy: -frand(0.05, 0.12), s: frand(1.5, 3), color: hsla(frand(0, 360), 0.9, 0.65), life: 900,
              kind: PKind.star, vr: 0.004));
        }
      }
      final c = e.cfg;
      if (c != null && c.time > 0 && rs.timeLeft < 10000 && rs.timeLeft > 0) {
        final p = 0.5 + 0.5 * math.sin(t * 0.012);
        canvas.drawRect(
            full,
            Paint()
              ..shader = ui.Gradient.radial(
                  Offset(worldW / 2, h / 2), h * 0.8, [const Color(0x00FF3B5C), Color.fromRGBO(255, 59, 92, 0.22 * p)], const [0.45, 1]));
      }
    }
    final sa = t - fx.shockAt;
    if (sa < 500) {
      canvas.drawCircle(Offset(worldW / 2, h / 2), easeOut(sa / 500) * h * 0.85, _stroke(Color.fromRGBO(255, 255, 255, 1 - sa / 500), 10));
    }

    // floating text
    for (final tx in fx.texts) {
      final p = tx.age / tx.life;
      final grow = p < 0.12 ? 0.75 + 0.25 * (p / 0.12) : 1.0;
      final alpha = p < 0.6 ? 1.0 : 1 - (p - 0.6) / 0.4;
      final y = tx.y + tx.rise * easeOut(p);
      if (alpha < 0.99) canvas.saveLayer(Rect.fromCenter(center: Offset(tx.x, y), width: 260, height: 80), _fill(Color.fromRGBO(0, 0, 0, alpha)));
      canvas.save();
      canvas.translate(tx.x, y);
      canvas.scale(grow, grow);
      haloText(canvas, tx.text, 0, 0, tx.size, tx.color, th.halo, 4);
      if (tx.coin) {
        final tp = textCache.get(tx.text, tx.size, tx.color);
        paintCoin(canvas, Offset(-tp.width / 2 - 9, 0), 14);
      }
      canvas.restore();
      if (alpha < 0.99) canvas.restore();
    }

    // resume countdown
    if (playing && e.state == GState.playing && rs.grace > 0) {
      final n = (rs.grace / 300).ceil();
      final p = 1 - (rs.grace % 300) / 300;
      canvas.saveLayer(Rect.fromLTWH(0, 0, worldW, h), _fill(Color.fromRGBO(0, 0, 0, 1 - p * 0.6)));
      canvas.save();
      canvas.translate(worldW / 2, h / 2);
      canvas.scale(1 + p * 0.3, 1 + p * 0.3);
      haloText(canvas, '$n', 0, 0, 70, th.canvasInk, th.halo, 9);
      canvas.restore();
      canvas.restore();
    }

    // banner
    final bn = fx.cur;
    if (bn != null) {
      final p = bn.age / bn.life;
      final sIn = p < 0.15 ? easeOutBack(p / 0.15) : 1.0;
      final alpha = p > 0.8 ? 1 - (p - 0.8) / 0.2 : 1.0;
      final size = bn.kind == 'fever' ? 40.0 : (bn.kind == 'event' ? 26.0 : 28.0);
      final col = bn.kind == 'fever'
          ? hsla(((t * 0.3) / 20).floor() * 20.0, 0.9, 0.55)
          : bn.kind == 'power'
              ? th.cyan
              : bn.kind == 'event'
                  ? th.goldEdge
                  : th.pink;
      final cy = h * 0.42 - (bn.kind == 'event' ? 40 : 0);
      if (alpha < 0.99) canvas.saveLayer(Rect.fromLTWH(0, cy - 60, worldW, 120), _fill(Color.fromRGBO(0, 0, 0, alpha)));
      canvas.save();
      canvas.translate(worldW / 2, cy);
      canvas.scale(sIn, sIn);
      haloText(canvas, bn.text, 0, 0, size, col, th.halo, 7);
      canvas.restore();
      if (alpha < 0.99) canvas.restore();
    }
    canvas.restore(); // scale
  }

  @override
  bool shouldRepaint(covariant GamePainter oldDelegate) => true;
}

// ---------------------------------------------------------------- previews
/// A single bubble drawn into a small square (shop, guide, rules, toasts).
class BubblePreview extends StatelessWidget {
  final String type;
  final String? skin;
  final double size;
  final String power;
  final SeasonDef? season;
  final double? hue;
  const BubblePreview(this.type, {super.key, this.skin, this.size = 40, this.power = 'blast', this.season, this.hue});
  @override
  Widget build(BuildContext context) {
    return SizedBox(width: size, height: size, child: CustomPaint(painter: _BubblePreviewPainter(this)));
  }
}

class _BubblePreviewPainter extends CustomPainter {
  final BubblePreview w;
  _BubblePreviewPainter(this.w);
  @override
  void paint(Canvas canvas, Size size) {
    final px = size.shortestSide;
    final skinKey = w.skin ?? Save.data.skin;
    final r = px * (skinKey == 'planet' && w.type == 'normal' ? 0.27 : 0.34);
    final def = bubbles[w.type];
    final b = Bubble(
      type: w.type,
      baseX: px / 2,
      y: px / 2 + (w.type == 'bomb' ? 2 : 0) + (w.type == 'tough' ? 0 : 0),
      r: r,
      vy: 0,
      wa: 0,
      wf: 0,
      phase: 0.7,
      hue: w.hue ?? 2.2,
      born: -9999,
      hp: def?.hp ?? 1,
      power: w.power,
      season: w.season,
    );
    drawBubble(canvas, b, 1200, skinKey, preview: true);
  }

  @override
  bool shouldRepaint(covariant _BubblePreviewPainter old) => old.w.type != w.type || old.w.skin != w.skin || old.w.power != w.power;
}

/// A static burst showing a pop effect.
class FxPreview extends StatelessWidget {
  final String fx;
  final double size;
  const FxPreview(this.fx, {super.key, this.size = 60});
  @override
  Widget build(BuildContext context) => SizedBox(width: size, height: size, child: CustomPaint(painter: _FxPreviewPainter(fx)));
}

class _FxPreviewPainter extends CustomPainter {
  final String fx;
  _FxPreviewPainter(this.fx);
  @override
  void paint(Canvas c, Size size) {
    final px = size.shortestSide;
    final cx = px / 2, cy = px / 2;
    const n = 10;
    final th = Pal.th;
    c.drawCircle(Offset(cx, cy), px * 0.2, _stroke(ca(th.bubbleEdge, 0.6), 2));
    for (var k = 0; k < n; k++) {
      final a = (k / n) * tau, rr = px * (0.3 + (k % 2) * 0.08);
      final x = cx + math.cos(a) * rr, y = cy + math.sin(a) * rr;
      const col5 = [Color(0xFFFF5C8A), Color(0xFFFFC928), Color(0xFF3BD38A), Color(0xFF1FB0D6), Color(0xFF8E6CF2)];
      switch (fx) {
        case 'confetti':
          c.save();
          c.translate(x, y);
          c.rotate(a * 2);
          c.drawRect(const Rect.fromLTWH(-4, -2, 8, 4), _fill(col5[k % 5]));
          c.restore();
          break;
        case 'stars':
          c.drawPath(starPath(x, y, 5, a), _fill(k.isOdd ? const Color(0xFFFFC928) : const Color(0xFFFFE27A)));
          break;
        case 'hearts':
          c.drawPath(heartPath(x, y, 3.6), _fill(k.isOdd ? const Color(0xFFFF5C8A) : const Color(0xFFFF9CC0)));
          break;
        case 'fireworks':
          c.drawLine(Offset(cx + math.cos(a) * px * 0.14, cy + math.sin(a) * px * 0.14), Offset(x, y), _stroke(col5[k % 5], 2.2, cap: StrokeCap.round));
          break;
        case 'prism':
          c.save();
          c.translate(x, y);
          c.rotate(a);
          c.drawPath(
              Path()
                ..moveTo(0, -5)
                ..lineTo(4, 4)
                ..lineTo(-4, 4)
                ..close(),
              _fill(hslc(k * 36.0, 90, 60)));
          c.restore();
          break;
        case 'snow':
          final p = _stroke(k.isOdd ? const Color(0xFF7FB6D8) : const Color(0xFFA8D8F0), 1.4);
          for (var q = 0; q < 3; q++) {
            final aa = (q * math.pi) / 3;
            c.drawLine(Offset(x - math.cos(aa) * 4, y - math.sin(aa) * 4), Offset(x + math.cos(aa) * 4, y + math.sin(aa) * 4), p);
          }
          break;
        default:
          final cols = [th.bubbleEdge, th.pink, th.cyan, th.lemon];
          c.drawCircle(Offset(x, y), 3, _fill(Color(cols[k % 4])));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _FxPreviewPainter old) => old.fx != fx;
}

/// A tiny tub in a theme's colours.
class ThemePreview extends StatelessWidget {
  final String theme;
  final double size;
  const ThemePreview(this.theme, {super.key, this.size = 60});
  @override
  Widget build(BuildContext context) => SizedBox(width: size, height: size, child: CustomPaint(painter: _ThemePreviewPainter(theme)));
}

class _ThemePreviewPainter extends CustomPainter {
  final String theme;
  _ThemePreviewPainter(this.theme);
  @override
  void paint(Canvas c, Size size) {
    final th = themes[theme] ?? themes['bath']!;
    final px = size.shortestSide;
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, px, px), const Radius.circular(12)), _fill(Color(th.frame)));
    final inner = RRect.fromRectAndRadius(Rect.fromLTWH(7, 7, px - 14, px - 14), const Radius.circular(8));
    c.drawRRect(inner, Paint()..shader = ui.Gradient.linear(const Offset(0, 8), Offset(0, px - 8), [Color(th.water), Color(th.water2)]));
    c.drawRRect(inner, _stroke(Color(th.frameEdge), 2));
    final keep = Pal.th;
    Pal.th = th;
    for (final d in [(0.42, 0.58, 0.17, 1.0), (0.68, 0.33, 0.1, 3.0)]) {
      final b = Bubble(type: 'normal', baseX: px * d.$1, y: px * d.$2, r: px * d.$3, vy: 0, wa: 0, wf: 0, phase: 0, hue: d.$4, born: -9999, hp: 1);
      drawBubble(c, b, 1000, 'soap', preview: true);
    }
    Pal.th = keep;
  }

  @override
  bool shouldRepaint(covariant _ThemePreviewPainter old) => old.theme != theme;
}
