// APP — the controller (navigation, toasts, modals, hooks into the engine)
// and the main layout: top bar, the tall play area, score bar and powers.
import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../core/content.dart';
import '../core/engine.dart';
import '../core/progress.dart';
import '../core/save.dart';
import '../core/strings.dart';
import '../core/util.dart';
import '../services/audio.dart';
import 'kit.dart';
import 'painter.dart';
import 'screens.dart';

class FrameSignal extends ChangeNotifier {
  void tick() => notifyListeners();
}

class ToastItem {
  final int id;
  final ToastData data;
  bool out = false;
  ToastItem(this.id, this.data);
}

class _Nav {
  final String screen;
  final String mode;
  final int stage;
  _Nav(this.screen, this.mode, this.stage);
}

typedef ModalBuilder = Widget Function(BuildContext context);

late AppCtl app;

class AppCtl extends ChangeNotifier implements GameHooks {
  AppCtl() {
    engine = Engine(this);
  }

  late final Engine engine;
  final FrameSignal frame = FrameSignal();
  final ValueNotifier<int> hudTick = ValueNotifier(0);
  final ValueNotifier<int> hurtTick = ValueNotifier(0);
  final ValueNotifier<int> shakeTick = ValueNotifier(0);
  final ValueNotifier<int> toastTick = ValueNotifier(0);
  int bumpCount = 0;
  int heartGain = 0;
  final Map<String, int> powerGain = {};

  String screen = 'home';
  String pMode = 'classic';
  int pStage = 1;
  RunSummary? resR;
  RunResult? resRes;
  final List<_Nav> _stack = [];
  String shopTab = 'skin', misTab = 'daily', collTab = 'stats';
  int screenSerial = 0;

  final List<ToastItem> toasts = [];
  int _toastId = 0;
  final List<ModalBuilder> _modalQueue = [];
  ModalBuilder? modal;
  bool _modalPending = false;

  SeasonDef? seasonNow;
  String _lastDay = '';
  double _dayCheck = 0;
  double _lastHaptic = -9999;
  bool systemReduceMotion = false;
  double tubScale = 1;

  // ---------------------------------------------------------------- setup
  void boot() {
    gLang = Save.data.settings.lang;
    applyTheme();
    applyAudio();
    Prog.onToast = toast;
    Prog.onChange = notifyListeners;
    Prog.ensureQuests();
    _lastDay = dayKey();
    final act = Prog.activeSeasons();
    seasonNow = act.isNotEmpty ? act.first : null;
    for (var i = 0; i < 6; i++) {
      final b = engine.spawn(frand(0, 1) < 0.1 ? 'gold' : 'normal', deco: true, rad: frand(14, 30), vy: frand(0.028, 0.05));
      b.y = frand(30, engine.H - 10);
    }
    if (Save.notice == 'nostorage') toast(ToastData(icon: 'lock', title: t('save.noStorage'), ms: 5000));
    if (Save.notice == 'recovered') toast(ToastData(icon: 'refresh', title: t('save.recovered'), ms: 4500));
    if (Save.notice == 'reset') toast(ToastData(icon: 'lock', title: t('save.damaged'), text: t('save.damaged2'), ms: 6000));
    final seen = Save.data.contentSeen;
    if (seen.isNotEmpty && seen != contentVersion) queueModal((c) => whatsNewModal(c));
    Save.data.contentSeen = contentVersion;
    if (Prog.loginAvailable()) queueModal((c) => giftModal(c));
    Prog.checkUnlocks();
    Save.flush();
  }

  void applyTheme() {
    final th = themes[Save.data.theme] ?? themes['bath']!;
    Pal.th = th;
    engine.theme = th;
    final m = Save.data.settings.motion;
    reduceMotion = m == 'reduced' || (m == 'auto' && systemReduceMotion);
    textCache.clear();
    SystemChrome.setSystemUIOverlayStyle(th.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark);
  }

  void applyAudio() {
    final s = Save.data.settings;
    GameAudio.configure(sfx: s.sfxOn, music: s.musicOn, sfxVolume: s.sfx, musicVolume: s.music);
  }

  void setLang(String l) {
    Save.data.settings.lang = l;
    gLang = l;
    textCache.clear();
    Save.flush();
    notifyListeners();
  }

  // ---------------------------------------------------------------- frame
  void tick(double dt) {
    engine.update(dt);
    frame.tick();
    _dayCheck += dt;
    if (_dayCheck > 5000) {
      _dayCheck = 0;
      final dk = dayKey();
      if (dk != _lastDay) {
        _lastDay = dk;
        Prog.ensureQuests();
        final act = Prog.activeSeasons();
        seasonNow = act.isNotEmpty ? act.first : null;
        if (screen == 'home') notifyListeners();
      }
    }
  }

  // ---------------------------------------------------------------- navigation
  bool get runLayout => engine.state != GState.idle;

  void go(String s, {String? mode, int? stage, bool reset = false}) {
    if (reset) {
      _stack.clear();
    } else if (screen.isNotEmpty && screen != s) {
      _stack.add(_Nav(screen, pMode, pStage));
    }
    screen = s;
    if (mode != null) pMode = mode;
    if (stage != null) pStage = stage;
    screenSerial++;
    notifyListeners();
  }

  void render() => notifyListeners();

  void back() {
    if (modal != null) {
      closeModal();
      return;
    }
    if (engine.state == GState.playing) {
      pause();
      return;
    }
    if (engine.state == GState.paused && screen == 'pause') {
      resume();
      return;
    }
    if (screen == 'results') {
      go('home', reset: true);
      return;
    }
    if (_stack.isNotEmpty) {
      final p = _stack.removeLast();
      screen = p.screen;
      pMode = p.mode;
      pStage = p.stage;
      screenSerial++;
      notifyListeners();
      return;
    }
    if (engine.state == GState.paused) {
      screen = 'pause';
      notifyListeners();
      return;
    }
    if (screen != 'home') {
      go('home', reset: true);
      return;
    }
    openModal((c) => exitModal(c));
  }

  // ---------------------------------------------------------------- runs
  void startRun(String mode, {int stage = 1}) {
    if (!Prog.modeUnlocked(mode)) return;
    closeModal(silent: true);
    engine.state = GState.idle;
    engine.start(mode, stageId: stage);
    _stack.clear();
    screen = '';
    toasts.clear();
    toastTick.value++;
    bumpCount = 0;
    hudTick.value++;
    notifyListeners();
  }

  void pause() {
    if (engine.state != GState.playing) return;
    engine.pause();
    _stack.clear();
    screen = 'pause';
    screenSerial++;
    notifyListeners();
  }

  void resume() {
    if (engine.state != GState.paused) return;
    engine.resume();
    screen = '';
    notifyListeners();
  }

  void restart() {
    final m = engine.mode;
    final st = engine.stage?.id ?? 1;
    startRun(m, stage: st);
  }

  void quit() {
    engine.quit();
    screen = ''; // let the end-of-run ripple play, then results appear
    notifyListeners();
  }

  void playAgain() {
    final r = resR;
    if (r == null) return;
    startRun(r.mode, stage: r.stage > 0 ? r.stage : 1);
  }

  void usePower(String id) {
    if (engine.usePower(id)) hudTick.value++;
  }

  String timerMode() {
    final c = engine.cfg;
    if (c == null) return '';
    if (c.time > 0) return 'down';
    if (engine.mode == 'challenge' && c.goals.any((g) => g.k == 'survive')) return 'survive';
    if (engine.mode == 'survival') return 'up';
    return '';
  }

  // ---------------------------------------------------------------- GameHooks
  @override
  void sfx(String id, {int arg = 0}) => GameAudio.play(id, arg: arg);

  @override
  void haptic(int ms) {
    if (!Save.data.settings.vibrate) return;
    final now = engine.clock;
    if (ms < 30 && now - _lastHaptic < 45) return;
    _lastHaptic = now;
    if (ms <= 12) {
      HapticFeedback.selectionClick();
    } else if (ms <= 30) {
      HapticFeedback.lightImpact();
    } else if (ms <= 60) {
      HapticFeedback.mediumImpact();
    } else {
      HapticFeedback.heavyImpact();
    }
  }

  @override
  void hud({bool bump = false, bool gainHeart = false}) {
    if (bump) bumpCount++;
    if (gainHeart) heartGain++;
    hudTick.value++;
  }

  @override
  void hurt(bool shake) {
    hurtTick.value++;
    if (shake && !reduceMotion) shakeTick.value++;
  }

  @override
  void powerGained(String id) {
    powerGain[id] = (powerGain[id] ?? 0) + 1;
    hudTick.value++;
  }

  @override
  void music(String mood) => GameAudio.setMood(mood);

  @override
  void showResults(RunSummary r, RunResult res) {
    resR = r;
    resRes = res;
    engine.toIdle();
    _stack.clear();
    screen = 'results';
    screenSerial++;
    if (res.levelUps.isNotEmpty) GameAudio.play('levelUp');
    for (final lu in res.levelUps) {
      queueModal((c) => levelModal(c, lu));
    }
    notifyListeners();
  }

  @override
  void toast(ToastData d) {
    final max = runLayout ? 2 : 3;
    while (toasts.where((x) => !x.out).length >= max) {
      toasts.removeAt(0);
    }
    final item = ToastItem(++_toastId, d);
    toasts.add(item);
    if (d.sound.isNotEmpty) GameAudio.play(d.sound);
    toastTick.value++;
    Timer(Duration(milliseconds: d.ms), () {
      item.out = true;
      toastTick.value++;
      Timer(const Duration(milliseconds: 280), () {
        toasts.remove(item);
        toastTick.value++;
      });
    });
  }

  void showLevelUps() {
    final lus = List.of(Prog.levelUps);
    Prog.levelUps.clear();
    if (lus.isNotEmpty) GameAudio.play('levelUp');
    for (final lu in lus) {
      queueModal((c) => levelModal(c, lu));
    }
  }

  // ---------------------------------------------------------------- modals
  void queueModal(ModalBuilder b) {
    _modalQueue.add(b);
    if (modal == null && !_modalPending) _nextModal();
  }

  void _nextModal() {
    if (_modalQueue.isEmpty) return;
    _modalPending = true;
    Timer(const Duration(milliseconds: 350), () {
      _modalPending = false;
      if (engine.state == GState.playing || modal != null || _modalQueue.isEmpty) return;
      modal = _modalQueue.removeAt(0);
      notifyListeners();
    });
  }

  void openModal(ModalBuilder b) {
    modal = b;
    notifyListeners();
  }

  void closeModal({bool silent = false}) {
    if (modal == null) return;
    modal = null;
    if (!silent) _nextModal();
    notifyListeners();
  }
}

// ======================================================================
// SHELL
// ======================================================================
class GameShell extends StatefulWidget {
  const GameShell({super.key});
  @override
  State<GameShell> createState() => _GameShellState();
}

class _GameShellState extends State<GameShell> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final Ticker _ticker;
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _ticker = createTicker((elapsed) {
      var dt = (elapsed - _last).inMicroseconds / 1000.0;
      _last = elapsed;
      if (dt < 0) dt = 0;
      if (dt > 50) dt = 50; // after a hitch, carry on instead of jumping ahead
      try {
        app.tick(dt);
      } catch (e, st) {
        debugPrint('tick error: $e\n$st');
      }
    });
    _ticker.start();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      GameAudio.background(false);
      _last = Duration.zero;
      _ticker.stop();
      _ticker.start();
    } else {
      if (app.engine.state == GState.playing) app.pause();
      Save.flush();
      GameAudio.background(true);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sysReduce = MediaQuery.maybeDisableAnimationsOf(context) ?? false;
    if (sysReduce != app.systemReduceMotion) {
      app.systemReduceMotion = sysReduce;
      app.applyTheme();
    }
    final run = app.runLayout;
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) app.back();
      },
      child: Scaffold(
        backgroundColor: Pal.page,
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: [
            const Positioned.fill(child: PageBackdrop()),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(7, 6, 7, 9),
                child: Shaker(
                  signal: app.shakeTick,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: Pal.frameEdge, width: 3),
                      boxShadow: [BoxShadow(color: Pal.frameShadow, offset: const Offset(0, 6))],
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color.lerp(Pal.frame, Colors.white, 0.18)!, Pal.frame, Color.lerp(Pal.frame, Colors.black, 0.06)!],
                      ),
                    ),
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                    // non-const children so they rebuild with the controller
                    child: Column(
                      children: [
                        TopBar(),
                        const SizedBox(height: 8),
                        Expanded(child: Tub()),
                        if (run) ...[
                          StatsBar(),
                          if (app.engine.cfg?.powers ?? false) PowersRow(),
                        ] else
                          ProfileBar(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Patterned page behind the toy frame.
class PageBackdrop extends StatelessWidget {
  const PageBackdrop({super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _PagePainter(Pal.th));
}

class _PagePainter extends CustomPainter {
  final ThemeDef th;
  _PagePainter(this.th);
  @override
  void paint(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = Color(th.page));
    final p = Paint()..color = Color(th.grout);
    switch (th.pattern) {
      case 'tiles':
        p.strokeWidth = 2;
        for (var x = 0.0; x < s.width; x += 52) {
          c.drawLine(Offset(x, 0), Offset(x, s.height), p);
        }
        for (var y = 0.0; y < s.height; y += 52) {
          c.drawLine(Offset(0, y), Offset(s.width, y), p);
        }
        break;
      case 'dots':
        for (var y = 13.0; y < s.height; y += 26) {
          for (var x = 13.0; x < s.width; x += 26) {
            c.drawCircle(Offset(x, y), 3.5, p);
          }
        }
        break;
      case 'waves':
        p
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;
        for (var y = 12.0; y < s.height; y += 24) {
          for (var x = 0.0; x < s.width; x += 44) {
            c.drawArc(Rect.fromCircle(center: Offset(x + 22, y + 18), radius: 19), math.pi * 1.2, math.pi * 0.6, false, p);
          }
        }
        break;
      case 'stripes':
        p.strokeWidth = 11;
        for (var x = -s.height; x < s.width; x += 31) {
          c.drawLine(Offset(x, 0), Offset(x + s.height, s.height), p);
        }
        break;
      case 'stars':
        final r = math.Random(7);
        final sp = Paint()..color = const Color(0x99FFFFFF);
        for (var i = 0; i < 160; i++) {
          c.drawCircle(Offset(r.nextDouble() * s.width, r.nextDouble() * s.height), 0.6 + r.nextDouble() * 1.2, sp);
        }
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _PagePainter old) => old.th != th;
}

/// Shakes its child sideways whenever [signal] changes.
class Shaker extends StatefulWidget {
  final ValueNotifier<int> signal;
  final Widget child;
  const Shaker({super.key, required this.signal, required this.child});
  @override
  State<Shaker> createState() => _ShakerState();
}

class _ShakerState extends State<Shaker> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 320));
  @override
  void initState() {
    super.initState();
    widget.signal.addListener(_go);
  }

  void _go() => _c.forward(from: 0);

  @override
  void dispose() {
    widget.signal.removeListener(_go);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) {
        final v = _c.value;
        final dx = v == 0 || v == 1 ? 0.0 : math.sin(v * math.pi * 5) * 6 * (1 - v);
        return Transform.translate(offset: Offset(dx, 0), child: child);
      },
    );
  }
}

// ======================================================================
// TOP BAR
// ======================================================================
class TopBar extends StatelessWidget {
  const TopBar({super.key});

  String _title() {
    final e = app.engine;
    if (app.runLayout || app.screen == 'pause' || app.screen == 'results') {
      if (app.screen == 'results' && app.resR != null) {
        final r = app.resR!;
        return r.mode == 'challenge' ? t('stage.n', {'n': r.stage}) : modes[r.mode]!.name.s;
      }
      return e.mode == 'challenge' && e.stage != null ? t('stage.n', {'n': e.stage!.id}) : modes[e.mode]!.name.s;
    }
    switch (app.screen) {
      case 'modes':
        return t('modes.title');
      case 'shop':
        return t('shop.title');
      case 'missions':
        return t('missions.title');
      case 'collection':
        return t('coll.title');
      case 'settings':
        return t('set.title');
      case 'stages':
        return modes['challenge']!.name.s;
      case 'ready':
        return modes[app.pMode]!.name.s;
      case 'stage':
        return t('stage.n', {'n': app.pStage});
    }
    return 'Bubble Pop';
  }

  @override
  Widget build(BuildContext context) {
    final e = app.engine;
    final run = app.runLayout;
    final s = Save.data.settings;
    Widget nav;
    if (run && app.screen != 'settings') {
      final paused = e.state == GState.paused;
      nav = RoundIconButton(paused ? 'play' : 'pause', () => paused ? app.resume() : app.pause(),
          tooltip: paused ? t('btn.resume') : 'Pause');
    } else if (app.screen != 'home') {
      nav = RoundIconButton('back', app.back, tooltip: 'Back');
    } else {
      nav = const SizedBox(width: 40, height: 40);
    }
    final soundOn = s.sfxOn || s.musicOn;
    return SizedBox(
      height: 44,
      child: Row(
        children: [
          nav,
          const SizedBox(width: 8),
          Expanded(
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 200),
              opacity: app.screen == 'home' && !run ? 0 : 1,
              child: Text(_title(), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(22, color: Pal.ink)),
            ),
          ),
          if (run) const _Hearts(),
          if (run) const _TimerPill(),
          if (!run)
            Pill(
              icon: const Glyph('coin', size: 22),
              text: fmt(Save.data.profile.coins),
            ),
          const SizedBox(width: 8),
          RoundIconButton(soundOn ? 'volume' : 'mute', () {
            final on = !(s.sfxOn || s.musicOn);
            s.sfxOn = on;
            s.musicOn = on;
            Save.dirty();
            app.applyAudio();
            if (on) GameAudio.play('pop', arg: 2);
            app.render();
          }),
        ],
      ),
    );
  }
}

class _Hearts extends StatelessWidget {
  const _Hearts();
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: app.hudTick,
      builder: (context, _, __) {
        final r = app.engine.r;
        final c = app.engine.cfg;
        if (r == null || c == null || r.maxLives <= 0) return const SizedBox.shrink();
        final n = math.min(5, math.max(r.lives, c.lives));
        return Padding(
          padding: const EdgeInsetsDirectional.only(end: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (var i = 0; i < n; i++)
                TweenAnimationBuilder<double>(
                  key: ValueKey('h$i-${i < r.lives}-${i == r.lives - 1 ? app.heartGain : 0}'),
                  tween: Tween(begin: i < r.lives && i == r.lives - 1 && app.heartGain > 0 ? 0.4 : 1, end: 1),
                  duration: const Duration(milliseconds: 420),
                  curve: Curves.elasticOut,
                  builder: (context, v, _) => Transform.scale(
                    scale: i < r.lives ? v : 0.8,
                    child: Opacity(
                      opacity: i < r.lives ? 1 : 0.4,
                      child: CustomPaint(size: const Size(24, 22), painter: HeartIconPainter(i < r.lives)),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class HeartIconPainter extends CustomPainter {
  final bool full;
  HeartIconPainter(this.full);
  @override
  void paint(Canvas c, Size s) {
    final p = heartPath(s.width / 2, s.height * 0.5, s.width * 0.3);
    if (full) c.drawPath(p, Paint()..color = Pal.heart);
    c.drawPath(
        p,
        Paint()
          ..color = Pal.frameEdge
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..strokeJoin = StrokeJoin.round);
  }

  @override
  bool shouldRepaint(covariant HeartIconPainter old) => old.full != full;
}

class _TimerPill extends StatelessWidget {
  const _TimerPill();
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app.frame,
      builder: (context, _) {
        final tm = app.timerMode();
        final r = app.engine.r;
        final c = app.engine.cfg;
        if (tm.isEmpty || r == null || c == null) return const SizedBox.shrink();
        double ms;
        if (tm == 'down') {
          ms = r.timeLeft;
        } else if (tm == 'survive') {
          ms = c.goals.firstWhere((g) => g.k == 'survive').n * 1000 - app.engine.run;
        } else {
          ms = app.engine.run;
        }
        final low = tm != 'up' && ms < 10000;
        final txt = tm == 'up' ? fmtTime((ms / 1000).floor() * 1000) : fmtTime(ms);
        final pulse = low ? 1 + 0.06 * math.max(0, math.sin(app.engine.clock * 0.0063)) : 1.0;
        return Transform.scale(
          scale: pulse,
          child: Pill(
            icon: Glyph('clock', size: 20, color: low ? const Color(0xFFC0123F) : Pal.ink),
            text: txt,
            textColor: low ? const Color(0xFFC0123F) : Pal.ink,
          ),
        );
      },
    );
  }
}

// ======================================================================
// TUB (the play area)
// ======================================================================
class Tub extends StatelessWidget {
  const Tub({super.key});

  void _down(PointerDownEvent ev) {
    final e = app.engine;
    if (e.state != GState.playing) return;
    final sc = app.tubScale;
    e.pointerX = ev.localPosition.dx / sc;
    e.pointerY = ev.localPosition.dy / sc;
    e.pointerActive = true;
    e.tap(e.pointerX, e.pointerY);
  }

  void _move(PointerMoveEvent ev) {
    final e = app.engine;
    final sc = app.tubScale;
    e.pointerX = ev.localPosition.dx / sc;
    e.pointerY = ev.localPosition.dy / sc;
  }

  void _up(PointerEvent ev) {
    final e = app.engine;
    e.pointerActive = false;
    e.pointerUntil = e.clock + 350;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Pal.water, Pal.water2]),
      ),
      foregroundDecoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Pal.frameEdge, width: 3),
      ),
      clipBehavior: Clip.antiAlias,
      child: LayoutBuilder(builder: (context, cons) {
        app.engine.setSize(cons.maxWidth, cons.maxHeight);
        app.tubScale = cons.maxWidth / worldW;
        final challengeRun = app.runLayout && app.engine.mode == 'challenge';
        return Stack(
          fit: StackFit.expand,
          children: [
            Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: _down,
              onPointerMove: _move,
              onPointerUp: _up,
              onPointerCancel: _up,
              child: RepaintBoundary(
                child: CustomPaint(painter: GamePainter(app.engine, () => app.seasonNow, app.frame)),
              ),
            ),
            if (challengeRun) const PositionedDirectional(top: 8, start: 8, end: 8, child: GoalBar()),
            const HurtFlash(),
            OverlayLayer(),
            ToastLayer(),
            if (app.modal != null) ModalLayer(builder: app.modal!),
          ],
        );
      }),
    );
  }
}

class GoalBar extends StatelessWidget {
  const GoalBar({super.key});
  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: app.frame,
        builder: (context, _) {
          final c = app.engine.cfg;
          if (c == null) return const SizedBox.shrink();
          return Wrap(
            spacing: 5,
            runSpacing: 5,
            children: [
              for (final g in c.goals) _chip(goalShort(g), app.engine.goalValue(g) >= g.n ? Pal.good : null),
              for (final rl in c.rules) _chip(t('rule.short.$rl'), Pal.pink),
            ],
          );
        },
      ),
    );
  }

  Widget _chip(String s, Color? solid) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: solid ?? Pal.cardStrong,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: solid == null ? Pal.cardEdge : Colors.transparent, width: 2),
      ),
      child: Text(s, style: ts(13, color: solid == null ? Pal.cInk : Colors.white)),
    );
  }
}

String goalShort(Goal g) {
  final e = app.engine;
  final n = g.k == 'survive' ? fmtTime(g.n * 1000) : fmt(g.n);
  final v = e.goalValue(g);
  final cur = g.k == 'survive' ? fmtTime(math.min(e.run, g.n * 1000.0)) : fmt(math.min(v, g.n));
  final label = g.k == 'popType' ? bubbles[g.t]!.name.s : t('goal.${g.k}');
  return '$label $cur/$n';
}

String goalLong(Goal g) {
  final n = g.k == 'survive' ? fmtTime(g.n * 1000) : fmt(g.n);
  if (g.k == 'popType') return t('goal.popType.long', {'n': n, 'name': bubbles[g.t]!.name.s});
  return t('goal.${g.k}.long', {'n': n});
}

/// Pink inner glow when a heart (or time) is lost.
class HurtFlash extends StatefulWidget {
  const HurtFlash({super.key});
  @override
  State<HurtFlash> createState() => _HurtFlashState();
}

class _HurtFlashState extends State<HurtFlash> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
  @override
  void initState() {
    super.initState();
    app.hurtTick.addListener(_go);
  }

  void _go() => _c.forward(from: 0);

  @override
  void dispose() {
    app.hurtTick.removeListener(_go);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final v = _c.value;
          if (v == 0 || v == 1) return const SizedBox.shrink();
          return Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: withA(Pal.pink, 1 - v), width: 9 * (1 - v)),
            ),
          );
        },
      ),
    );
  }
}

// ======================================================================
// OVERLAY SCREENS, TOASTS, MODALS
// ======================================================================
class OverlayLayer extends StatelessWidget {
  const OverlayLayer({super.key});
  @override
  Widget build(BuildContext context) {
    final show = app.screen.isNotEmpty;
    final veil = app.screen == 'home' ? withA(Pal.veil, 0.5) : Pal.veil;
    return IgnorePointer(
      ignoring: !show,
      child: AnimatedOpacity(
        opacity: show ? 1 : 0,
        duration: const Duration(milliseconds: 220),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          color: veil,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 240),
            switchInCurve: Curves.easeOut,
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(position: Tween(begin: const Offset(0, 0.03), end: Offset.zero).animate(anim), child: child),
            ),
            child: KeyedSubtree(
              key: ValueKey('${app.screen}#${app.screenSerial}'),
              child: show ? SizedBox.expand(child: buildScreen(context)) : const SizedBox.shrink(),
            ),
          ),
        ),
      ),
    );
  }
}

class ToastLayer extends StatelessWidget {
  const ToastLayer({super.key});
  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: ValueListenableBuilder<int>(
        valueListenable: app.toastTick,
        builder: (context, _, __) {
          final run = app.runLayout;
          final list = Column(
            mainAxisSize: MainAxisSize.min,
            children: [for (final tItem in app.toasts) _ToastView(key: ValueKey(tItem.id), item: tItem, small: run)],
          );
          return Align(
            alignment: run ? Alignment.bottomCenter : Alignment.topCenter,
            child: Padding(padding: const EdgeInsets.all(8), child: list),
          );
        },
      ),
    );
  }
}

class _ToastView extends StatelessWidget {
  final ToastItem item;
  final bool small;
  const _ToastView({super.key, required this.item, required this.small});
  @override
  Widget build(BuildContext context) {
    final d = item.data;
    final body = Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: EdgeInsetsDirectional.fromSTEB(8, small ? 5 : 7, 14, small ? 5 : 7),
      decoration: BoxDecoration(
        color: d.tip ? Pal.cardStrong : Pal.frame,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Pal.frameEdge, width: 2.5),
        boxShadow: [BoxShadow(color: Pal.frameEdge, offset: const Offset(0, 3))],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(color: Colors.white.withAlpha(160), shape: BoxShape.circle),
            alignment: Alignment.center,
            child: d.bubble.isNotEmpty ? BubblePreview(d.bubble, size: 30) : Glyph(d.icon, size: 19, color: Pal.ink),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(d.title, style: ts(small ? 13 : 14.5, color: Pal.ink, height: 1.15)),
                if (d.text.isNotEmpty)
                  Text(d.text, style: ts(small ? 11.5 : 12.5, color: Pal.inkSoft, weight: FontWeight.w500, height: 1.2)),
              ],
            ),
          ),
        ],
      ),
    );
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: item.out ? 0 : 1),
      duration: Duration(milliseconds: item.out ? 250 : 320),
      curve: item.out ? Curves.easeIn : Curves.easeOutBack,
      builder: (context, v, child) => Opacity(
        opacity: v.clamp(0.0, 1.0),
        child: Transform.translate(offset: Offset(0, (1 - v) * (small ? 14 : -14)), child: child),
      ),
      child: body,
    );
  }
}

class ModalLayer extends StatelessWidget {
  final ModalBuilder builder;
  const ModalLayer({super.key, required this.builder});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => app.closeModal(),
      child: Container(
        color: const Color(0x730A1E32),
        padding: const EdgeInsets.all(16),
        alignment: Alignment.center,
        child: GestureDetector(
          onTap: () {},
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.8, end: 1),
            duration: const Duration(milliseconds: 320),
            curve: Curves.easeOutBack,
            builder: (context, v, child) => Transform.scale(scale: v, child: child),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 340),
              child: Container(
                decoration: BoxDecoration(
                  color: Pal.frame,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Pal.frameEdge, width: 3),
                  boxShadow: [BoxShadow(color: Pal.frameEdge, offset: const Offset(0, 6))],
                ),
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
                child: SingleChildScrollView(child: DefaultTextStyle(style: ts(14.5, color: Pal.ink, weight: FontWeight.w500), child: builder(context))),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ======================================================================
// BOTTOM: score bar, powers, profile
// ======================================================================
class StatsBar extends StatelessWidget {
  const StatsBar({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: app.hudTick,
      builder: (context, _, __) {
        final r = app.engine.r;
        final e = app.engine;
        final zen = e.mode == 'zen';
        final val = r == null ? 0 : (zen ? r.pops : r.score);
        final best = math.max(_runBest(), val);
        final mult = r?.mult ?? 1;
        final filled = r == null ? 0 : (mult >= Bal.multMax ? 5 : r.streak % Bal.multEvery);
        final fever = e.fever;
        Widget label(String s) => Text(s, style: ts(13, color: Pal.inkSoft, weight: FontWeight.w500));
        Widget value(String s, {Color? color}) =>
            Text(s, style: ts(27, color: color ?? Pal.ink, height: 1.0).copyWith(fontFeatures: const [FontFeature.tabularFigures()]));
        return Padding(
          padding: const EdgeInsets.fromLTRB(6, 9, 6, 0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  label(zen ? t('hud.popped') : t('hud.score')),
                  TweenAnimationBuilder<double>(
                    key: ValueKey(app.bumpCount),
                    tween: Tween(begin: reduceMotion ? 1 : 1.22, end: 1),
                    duration: const Duration(milliseconds: 200),
                    builder: (context, v, child) =>
                        Transform.scale(scale: v, alignment: AlignmentDirectional.centerStart.resolve(Directionality.of(context)), child: child),
                    child: value(fmt(val)),
                  ),
                ]),
              ),
              Column(children: [
                label(t('hud.combo')),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  value('×$mult', color: fever ? const Color(0xFFD21F5C) : null),
                  const SizedBox(width: 7),
                  for (var i = 0; i < 5; i++)
                    Container(
                      width: 9,
                      height: 9,
                      margin: const EdgeInsets.symmetric(horizontal: 1.5),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i < filled ? Pal.ink : Colors.transparent,
                        border: Border.all(color: Pal.ink, width: 2),
                      ),
                    ),
                ]),
              ]),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  label(t('hud.best')),
                  value(fmt(best)),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }

  int _runBest() {
    final s = Save.data;
    final e = app.engine;
    switch (e.mode) {
      case 'challenge':
        return s.stages[e.stage?.id ?? 0]?.best ?? 0;
      case 'daily':
        return s.daily.key == e.daily?.key ? s.daily.best : 0;
      case 'zen':
        return s.zenPops;
      default:
        return s.best[e.mode]?[e.diff] ?? 0;
    }
  }
}

class PowersRow extends StatelessWidget {
  const PowersRow({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(
        children: [
          for (final id in powers.keys) ...[
            Expanded(child: _PowerButton(id)),
            if (id != powers.keys.last) const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }
}

class _PowerButton extends StatelessWidget {
  final String id;
  const _PowerButton(this.id);
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app.frame,
      builder: (context, _) {
        final e = app.engine;
        final r = e.r;
        final n = r?.powers[id] ?? 0;
        final until = r?.active[id] ?? 0;
        final dur = r?.activeDur[id] ?? 1;
        final p = r != null && e.run < until ? ((until - e.run) / dur).clamp(0.0, 1.0) : 0.0;
        final enabled = n > 0 && e.state == GState.playing;
        final col = Color(powerColor[id] ?? 0xFF2E7FA8);
        return Semantics(
          button: true,
          label: '${powers[id]!.name.s}, ${tn('a11y.left', n)}',
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: enabled ? () => app.usePower(id) : null,
            child: TweenAnimationBuilder<double>(
              key: ValueKey('pg$id${app.powerGain[id] ?? 0}'),
              tween: Tween(begin: (app.powerGain[id] ?? 0) > 0 && !reduceMotion ? 1.18 : 1, end: 1),
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOutBack,
              builder: (context, v, child) => Transform.scale(scale: v, child: child),
              child: Opacity(
                opacity: enabled || p > 0 ? 1 : 0.4,
                child: Container(
                  height: 52,
                  decoration: BoxDecoration(
                    color: n > 0 ? Colors.white : Colors.white.withAlpha(140),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Pal.frameEdge, width: 2.5),
                    boxShadow: n > 0 ? [BoxShadow(color: Pal.frameEdge, offset: const Offset(0, 3))] : null,
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    children: [
                      if (p > 0)
                        Positioned.fill(
                          child: FractionallySizedBox(
                            alignment: AlignmentDirectional.centerStart,
                            widthFactor: p,
                            child: Container(color: withA(col, 0.28)),
                          ),
                        ),
                      Center(
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Glyph(id == 'magnet' ? 'magnet' : (powerIcon[id] ?? 'blast'), size: 26, color: col),
                          const SizedBox(width: 6),
                          Text('$n', style: ts(18, color: Pal.ink)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class ProfileBar extends StatelessWidget {
  const ProfileBar({super.key});
  @override
  Widget build(BuildContext context) {
    final p = Save.data.profile;
    final need = xpForLevel(p.level);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 10, 4, 0),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Pal.frameEdge, width: 2.5)),
            alignment: Alignment.center,
            child: Text('${p.level}', style: ts(18, color: Pal.ink)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  Text(t('level.n', {'n': p.level}), style: ts(14, color: Pal.ink)),
                  const Spacer(),
                  Text('${fmt(p.xp)} / ${fmt(need)} ${t('xp')}', style: ts(12.5, color: Pal.inkSoft, weight: FontWeight.w500)),
                ]),
                const SizedBox(height: 4),
                ProgressBar(p.xp / need, height: 12, outline: true, track: withA(Pal.frameEdge, 0.15)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
