// SCREENS — every overlay screen and modal, built from the UI kit.
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/content.dart';
import '../core/engine.dart';
import '../core/progress.dart';
import '../core/save.dart';
import '../core/strings.dart';
import '../core/util.dart';
import '../services/audio.dart';
import 'app.dart';
import 'kit.dart';
import 'painter.dart';

Widget buildScreen(BuildContext context) {
  switch (app.screen) {
    case 'home':
      return HomeScreen(); // ignore: prefer_const_constructors
    case 'modes':
      return _modes();
    case 'ready':
      return _ready();
    case 'stages':
      return _stages();
    case 'stage':
      return _stage();
    case 'shop':
      return _shop();
    case 'missions':
      return _missions();
    case 'collection':
      return _collection();
    case 'settings':
      return SettingsScreen(); // ignore: prefer_const_constructors
    case 'pause':
      return _pause();
    case 'results':
      return ResultsScreen(); // ignore: prefer_const_constructors
  }
  return HomeScreen(); // ignore: prefer_const_constructors
}

// ---------------------------------------------------------------- helpers
Widget scrollCenter(Widget child, {EdgeInsetsGeometry padding = const EdgeInsets.fromLTRB(14, 14, 14, 18)}) {
  return LayoutBuilder(
    builder: (context, cons) => SingleChildScrollView(
      padding: padding,
      child: ConstrainedBox(
        constraints: BoxConstraints(minHeight: math.max(0, cons.maxHeight - 32)),
        child: Center(child: child),
      ),
    ),
  );
}

Widget scrollList(List<Widget> children) {
  return ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 20), children: children);
}

/// Content that scrolls, with the main actions pinned at the bottom.
Widget withCta(Widget content, List<Widget> buttons) {
  return Column(
    children: [
      Expanded(child: scrollCenter(content)),
      Container(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 16),
        child: Wrap(alignment: WrapAlignment.center, spacing: 10, runSpacing: 10, children: buttons),
      ),
    ],
  );
}

Widget h2(String s) => Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(s, textAlign: TextAlign.center, style: ts(30, color: Pal.cInk, height: 1.1)),
    );

Widget sub(String s, {TextAlign align = TextAlign.center}) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(s, textAlign: align, style: ts(14.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.35)),
    );

Widget sectionH(String s, {String? extra}) => Padding(
      padding: const EdgeInsets.fromLTRB(2, 14, 2, 8),
      child: Row(children: [
        Text(s, style: ts(15.5, color: Pal.cInkSoft)),
        if (extra != null) Flexible(child: Text('  ·  $extra', style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500))),
      ]),
    );

Widget coinAmt(int n, {double size = 14, Color? color}) => Row(mainAxisSize: MainAxisSize.min, children: [
      Glyph('coin', size: size + 3),
      const SizedBox(width: 3),
      Text(fmt(n), style: ts(size, color: color ?? Pal.cInk)),
    ]);

Widget ruleRow(Widget icon, String text, {bool warn = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        SizedBox(width: 32, height: 32, child: Center(child: icon)),
        const SizedBox(width: 11),
        Expanded(
          child: Text(text,
              style: ts(15, color: warn ? Pal.pink : Pal.cInk, weight: warn ? FontWeight.w800 : FontWeight.w500, height: 1.3)),
        ),
      ]),
    );

Widget primary(String label, VoidCallback? onTap, {String? icon, bool big = false, Color? color}) => ChunkyButton(
      onTap: onTap,
      color: color,
      padding: EdgeInsets.symmetric(horizontal: big ? 36 : 24, vertical: big ? 15 : 12),
      child: BtnLabel(label, icon: icon, size: big ? 22 : 18),
    );

Widget ghost(String label, VoidCallback? onTap, {String? icon}) => ChunkyButton(
      onTap: onTap,
      color: Pal.dark ? const Color(0xFFE9E4FF) : Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
      child: BtnLabel(label, icon: icon, size: 17),
    );

Widget smallBtn(String label, VoidCallback? onTap, {String? icon, Color? color, Widget? child}) => ChunkyButton(
      onTap: onTap,
      color: color,
      lip: 3,
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
      child: child ?? BtnLabel(label, icon: icon, size: 14),
    );

void _toast(String icon, String title, [String text = '']) => app.toast(ToastData(icon: icon, title: title, text: text));

// ======================================================================
// HOME
// ======================================================================
class Logo extends StatelessWidget {
  const Logo({super.key});
  @override
  Widget build(BuildContext context) {
    const word = 'Bubble Pop';
    return LayoutBuilder(builder: (context, cons) {
      final size = math.min(58.0, cons.maxWidth / 6.2);
      return AnimatedBuilder(
        animation: app.frame,
        builder: (context, _) {
          final t = app.engine.clock;
          return Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var i = 0; i < word.length; i++)
                  Transform.translate(
                    offset: Offset(0, reduceMotion ? 0 : math.sin(t / 2600 * tau - i * 0.75) * 4),
                    child: Stack(children: [
                      Text(word[i],
                          style: TextStyle(
                            fontFamily: 'Sniglet',
                            fontSize: size,
                            fontWeight: FontWeight.w800,
                            height: 1,
                            foreground: Paint()
                              ..style = PaintingStyle.stroke
                              ..strokeWidth = 8
                              ..strokeJoin = StrokeJoin.round
                              ..color = Pal.halo,
                          )),
                      Text(word[i],
                          style: TextStyle(
                            fontFamily: 'Sniglet',
                            fontSize: size,
                            fontWeight: FontWeight.w800,
                            height: 1,
                            color: i < 6 ? Pal.cInk : Pal.pink,
                          )),
                    ]),
                  ),
              ],
            ),
          );
        },
      );
    });
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = Save.data;
    final lm = Prog.modeUnlocked(s.lastMode) ? s.lastMode : 'classic';
    final claim = Prog.claimableCount();
    final sea = app.seasonNow;
    final dsu = Prog.dailySetup();
    final dDone = s.daily.key == dsu.key && s.daily.done;

    Widget banner({required Widget lead, required String title, required String text, required VoidCallback onTap, bool strong = false}) {
      return Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Panel(
          onTap: onTap,
          color: strong ? Pal.frame : Pal.cardStrong,
          border: strong ? Pal.frameEdge : null,
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
          child: Row(children: [
            SizedBox(width: 38, height: 38, child: Center(child: lead)),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: ts(15, color: strong ? Pal.ink : Pal.cInk)),
                Text(text,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: ts(12.5, color: strong ? Pal.inkSoft : Pal.cInkSoft, weight: FontWeight.w500, height: 1.25)),
              ]),
            ),
            Glyph('back', size: 18, color: strong ? Pal.ink : Pal.cInk).flipForward(),
          ]),
        ),
      );
    }

    Widget tile(String icon, String label, VoidCallback onTap, [int badge = 0]) {
      return Stack(clipBehavior: Clip.none, children: [
        Panel(
          onTap: onTap,
          color: Pal.cardStrong,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Glyph(icon, size: 30, color: Pal.cInk),
            const SizedBox(height: 5),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, color: Pal.cInk)),
          ]),
        ),
        if (badge > 0) PositionedDirectional(top: -7, end: -4, child: CountBadge(badge)),
      ]);
    }

    final st = sea != null ? Prog.seasonState(sea) : null;
    Tier? nextTier;
    if (sea != null && st != null) {
      for (var i = 0; i < sea.tiers.length; i++) {
        if (!st.claimed.contains(i)) {
          nextTier = sea.tiers[i];
          break;
        }
      }
    }

    return scrollCenter(
      ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Logo(),
            const SizedBox(height: 8),
            Text(t('home.tagline'), textAlign: TextAlign.center, style: ts(15, color: Pal.cInkSoft, weight: FontWeight.w500)),
            const SizedBox(height: 26),
            ChunkyButton(
              onTap: () => app.go('ready', mode: lm),
              lip: 6,
              padding: const EdgeInsets.symmetric(horizontal: 52, vertical: 17),
              child: BtnLabel(t('home.play'), icon: 'play', size: 28),
            ),
            const SizedBox(height: 8),
            Text(modes[lm]!.name.s, style: ts(14, color: Pal.cInkSoft)),
            const SizedBox(height: 14),
            if (sea != null && st != null)
              banner(
                lead: BubblePreview('event', size: 38, season: sea),
                title: sea.name.s,
                text: nextTier != null ? t('event.progress', {'n': fmt(st.n), 'm': fmt(nextTier.n)}) : t('event.allDone'),
                onTap: () {
                  app.misTab = 'event';
                  app.go('missions');
                },
              ),
            banner(
              lead: Glyph('calendar', size: 28, color: Pal.ink),
              title: '${modes['daily']!.name.s}${dDone ? ' ✓' : ''}',
              text: dsu.mods.map((m) => m.name.s).join(' · '),
              onTap: () => app.go('ready', mode: 'daily'),
              strong: true,
            ),
            const SizedBox(height: 16),
            LayoutBuilder(builder: (context, cons) {
              final w = (cons.maxWidth - 20) / 3;
              return Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: [
                  SizedBox(width: w, child: tile('grid', t('home.modes'), () => app.go('modes'))),
                  SizedBox(width: w, child: tile('target', t('home.missions'), () => app.go('missions'), claim)),
                  SizedBox(width: w, child: tile('bag', t('home.shop'), () => app.go('shop'))),
                  SizedBox(width: w, child: tile('chart', t('home.stats'), () => app.go('collection'))),
                  SizedBox(width: w, child: tile('gear', t('home.settings'), () => app.go('settings'))),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }
}

extension _Flip on Widget {
  /// An arrow that points "forward" in the current reading direction.
  Widget flipForward() => Builder(
        builder: (context) => Transform.flip(flipX: true, child: this),
      );
}

// ======================================================================
// MODES / READY / STAGES
// ======================================================================
void _openMode(String m) {
  if (!Prog.modeUnlocked(m)) {
    _toast('lock', t('lock.level', {'n': modes[m]!.unlockLevel}), t('lock.levelHint'));
    return;
  }
  if (m == 'challenge') {
    app.go('stages');
  } else {
    app.go('ready', mode: m);
  }
}

Widget _modes() {
  final s = Save.data;
  return LayoutBuilder(builder: (context, cons) {
    final w = (cons.maxWidth - 28 - 10) / 2;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 20),
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [
          for (final m in modeOrder)
            SizedBox(
              width: w,
              child: Builder(builder: (context) {
                final md = modes[m]!;
                final open = Prog.modeUnlocked(m);
                String best;
                if (m == 'challenge') {
                  best = t('modes.stars', {'n': totalStars(s), 'm': stages.length * 3});
                } else if (m == 'zen') {
                  best = t('modes.bestPops', {'n': fmt(s.zenPops)});
                } else if (m == 'daily') {
                  best = s.daily.key == dayKey() ? t('modes.bestToday', {'n': fmt(s.daily.best)}) : t('modes.newToday');
                } else {
                  best = t('modes.best', {'n': fmt(bestOf(s, m))});
                }
                return Opacity(
                  opacity: open ? 1 : 0.62,
                  child: Panel(
                    onTap: () => _openMode(m),
                    color: Pal.cardStrong,
                    padding: const EdgeInsets.all(12),
                    child: SizedBox(
                      height: 150,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                                color: Pal.frame, borderRadius: BorderRadius.circular(11), border: Border.all(color: Pal.frameEdge, width: 2)),
                            alignment: Alignment.center,
                            child: Glyph(open ? md.icon : 'lock', size: 20, color: Pal.ink),
                          ),
                          const SizedBox(width: 8),
                          Expanded(child: Text(md.name.s, maxLines: 2, style: ts(16, color: Pal.cInk, height: 1.1))),
                        ]),
                        const SizedBox(height: 8),
                        Expanded(
                          child: Text(md.desc.s,
                              overflow: TextOverflow.fade, style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.3)),
                        ),
                        Text(open ? best : t('lock.level', {'n': md.unlockLevel}), style: ts(12.5, color: Pal.cInk)),
                      ]),
                    ),
                  ),
                );
              }),
            ),
        ],
      ),
    );
  });
}

List<Widget> rulesFor(String m) {
  Widget bub(String type) => BubblePreview(type, size: 32, power: 'blast');
  final out = <Widget>[];
  if (m == 'zen') {
    out
      ..add(ruleRow(bub('normal'), t('rule.tap')))
      ..add(ruleRow(Glyph('leaf', size: 26, color: Pal.cInk), t('rule.zen')))
      ..add(ruleRow(Glyph('pause', size: 26, color: Pal.cInk), t('rule.zenEnd')));
    return out;
  }
  out
    ..add(ruleRow(bub('normal'), t('rule.tap')))
    ..add(ruleRow(bub('gold'), t('rule.gold')));
  if (m == 'time') {
    out
      ..add(ruleRow(bub('clock'), t('rule.clock')))
      ..add(ruleRow(bub('spiky'), t('rule.spikyTime')))
      ..add(ruleRow(Glyph('clock', size: 26, color: Pal.cInk), t('rule.escapeTime')));
  } else {
    out
      ..add(ruleRow(CustomPaint(size: const Size(28, 26), painter: HeartIconPainter(true)), m == 'survival' ? t('rule.oneHeart') : t('rule.escape')))
      ..add(ruleRow(bub('spiky'), t('rule.spiky')));
  }
  out.add(ruleRow(bub('power'), t('rule.power')));
  if (m == 'classic' && Save.data.stats.games < 3) out.add(ruleRow(Glyph('bolt', size: 26, color: Pal.cInk), t('rule.combo')));
  return out;
}

Widget _chipStatic(String s) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: Pal.card, borderRadius: BorderRadius.circular(999), border: Border.all(color: Pal.cardEdge, width: 2)),
      child: Text(s, style: ts(13, color: Pal.cInk)),
    );

Widget _ready() {
  final s = Save.data;
  final m = app.pMode;
  final md = modes[m]!;
  final children = <Widget>[h2(md.name.s)];
  if (md.difficulty) {
    children.add(Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [
        for (final k in difficulty.keys)
          GestureDetector(
            onTap: () {
              s.settings.difficulty = k;
              Save.dirty();
              app.render();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: s.settings.difficulty == k ? Pal.frame : Pal.card,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: s.settings.difficulty == k ? Pal.frameEdge : Pal.cardEdge, width: 2),
              ),
              child: Text(difficulty[k]!.name.s + (difficulty[k]!.reward != 1 ? ' ×${difficulty[k]!.reward}' : ''),
                  style: ts(13.5, color: s.settings.difficulty == k ? Pal.ink : Pal.cInk)),
            ),
          ),
      ]),
    ));
  }
  if (m == 'daily') {
    final d = Prog.dailySetup();
    final done = s.daily.key == d.key && s.daily.done;
    children
      ..add(Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [for (final x in d.mods) _chipStatic(x.name.s)]),
      ))
      ..add(sub('${t('daily.target', {'n': d.target})}${done ? ' ✓ ${t('daily.doneToday')}' : ' · ${t('daily.reward')}'}\n'
          '${t('modes.bestToday', {'n': fmt(s.daily.key == d.key ? s.daily.best : 0)})}'));
  } else if (m == 'zen') {
    children.add(sub(t('modes.bestPops', {'n': fmt(s.zenPops)})));
  } else {
    var line = t('modes.bestDiff', {'n': fmt(s.best[m]?[s.settings.difficulty] ?? 0), 'd': difficulty[s.settings.difficulty]!.name.s});
    if (m == 'survival' && s.survivalTime > 0) line += ' · ${t('res.lasted', {'t': fmtTime(s.survivalTime)})}';
    children.add(sub(line));
  }
  children.add(ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 380),
    child: Panel(color: Pal.card, padding: const EdgeInsets.fromLTRB(12, 8, 12, 8), child: Column(children: rulesFor(m))),
  ));
  return withCta(Column(mainAxisSize: MainAxisSize.min, children: children),
      [primary(t('btn.start'), () => app.startRun(m), icon: 'play', big: true)]);
}

Widget _stages() {
  final s = Save.data;
  var nextMarked = false;
  return LayoutBuilder(builder: (context, cons) {
    final w = (cons.maxWidth - 28 - 3 * 9) / 4;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 20),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.star_rounded, color: Color(0xFFF5B800), size: 22),
          const SizedBox(width: 4),
          Text(t('modes.stars', {'n': totalStars(s), 'm': stages.length * 3}), style: ts(15, color: Pal.cInkSoft)),
        ]),
        const SizedBox(height: 12),
        Wrap(spacing: 9, runSpacing: 9, children: [
          for (final st in stages)
            Builder(builder: (context) {
              final rec = s.stages[st.id];
              final open = st.id == 1 || (s.stages[st.id - 1]?.stars ?? 0) > 0;
              final stars = rec?.stars ?? 0;
              var next = false;
              if (open && stars == 0 && !nextMarked) {
                next = true;
                nextMarked = true;
              }
              return GestureDetector(
                onTap: open ? () => app.go('stage', stage: st.id) : null,
                child: Opacity(
                  opacity: open ? 1 : 0.5,
                  child: Container(
                    width: w,
                    height: w,
                    decoration: BoxDecoration(
                      color: next ? Pal.frame : Pal.cardStrong,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: next ? Pal.frameEdge : Pal.cardEdge, width: 2.5),
                      boxShadow: next ? [BoxShadow(color: Pal.frameEdge, offset: const Offset(0, 3))] : null,
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      if (open) Text('${st.id}', style: ts(22, color: next ? Pal.ink : Pal.cInk)) else Glyph('lock', size: 22, color: Pal.cInk),
                      if (open) StarsRow(stars, size: 14),
                    ]),
                  ),
                ),
              );
            }),
        ]),
        const SizedBox(height: 14),
        Text(t('stage.more'), textAlign: TextAlign.center, style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
      ]),
    );
  });
}

Widget _stage() {
  final st = stages[clampI(app.pStage, 1, stages.length) - 1];
  final rec = Save.data.stages[st.id];
  final info = '${st.time > 0 ? t('stage.time', {'n': st.time}) : t('stage.noTimer')} · ${tn('stage.hearts', st.lives)}';
  final star2 = st.twoTimeLeft != null ? t('star.time', {'n': (st.twoTimeLeft! * 100).round()}) : t('star.score', {'n': st.twoScore ?? 0});
  return withCta(
    Column(mainAxisSize: MainAxisSize.min, children: [
      h2(t('stage.n', {'n': st.id})),
      if (rec != null) Padding(padding: const EdgeInsets.only(bottom: 6), child: StarsRow(rec.stars, size: 26)),
      sub(info),
      ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 380),
        child: Panel(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          child: Column(children: [
            for (final g in st.goals)
              ruleRow(Glyph(g.k == 'survive' ? 'clock' : (g.k == 'score' ? 'star' : 'target'), size: 26, color: Pal.cInk), goalLong(g)),
            for (final r in st.rules) ruleRow(Glyph('skull', size: 26, color: Pal.pink), t('rule.$r'), warn: true),
          ]),
        ),
      ),
      const SizedBox(height: 14),
      Text('★ ${t('star.clear')}\n★★ $star2\n★★★ ${t('star.noLoss')}',
          textAlign: TextAlign.center, style: ts(13, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.6)),
    ]),
    [primary(t('btn.start'), () => app.startRun('challenge', stage: st.id), icon: 'play', big: true)],
  );
}

// ======================================================================
// SHOP
// ======================================================================
void _buy(ItemDef it) {
  if (Prog.status(it).st == 'buy' && Save.data.profile.coins < it.price) {
    _toast('coin', t('toast.notEnough'));
    return;
  }
  if (Prog.buy(it.id)) {
    GameAudio.play('buy');
    _toast('bag', t('toast.bought'), it.name.s);
    if (it.kind == 'theme') app.applyTheme();
    app.render();
  }
}

void _equip(ItemDef it) {
  if (Prog.equip(it.id)) {
    if (it.kind == 'theme') app.applyTheme();
    GameAudio.play('ui');
    app.render();
  }
}

Widget _shop() {
  final tab = app.shopTab;
  final tabs = [('skin', t('shop.skins'), 0), ('fx', t('shop.fx'), 0), ('theme', t('shop.themes'), 0), ('upg', t('shop.upgrades'), 0)];
  final body = <Widget>[];
  if (tab == 'upg') {
    for (final u in upgrades) {
      final lv = Prog.upg(u.id), max = u.prices.length;
      final price = lv < max ? u.prices[lv] : 0;
      body.add(Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Panel(
          padding: const EdgeInsets.all(10),
          child: Row(children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: Pal.cardStrong, shape: BoxShape.circle),
              alignment: Alignment.center,
              child: Glyph(u.icon, size: 22, color: Pal.cInk),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(u.name.s, style: ts(15, color: Pal.cInk)),
                Text(u.desc.s, style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.25)),
                const SizedBox(height: 5),
                Row(children: [
                  for (var i = 0; i < max; i++)
                    Container(
                      width: 16,
                      height: 6,
                      margin: const EdgeInsetsDirectional.only(end: 4),
                      decoration: BoxDecoration(color: i < lv ? Pal.good : withA(Pal.cInk, 0.15), borderRadius: BorderRadius.circular(3)),
                    ),
                ]),
              ]),
            ),
            const SizedBox(width: 8),
            if (lv < max)
              smallBtn('', () {
                if (Save.data.profile.coins < price) {
                  _toast('coin', t('toast.notEnough'));
                  return;
                }
                if (Prog.buyUpgrade(u.id)) {
                  GameAudio.play('buy');
                  app.render();
                }
              }, child: coinAmt(price, color: Pal.ink))
            else
              Row(mainAxisSize: MainAxisSize.min, children: [
                Glyph('check', size: 18, color: Pal.good),
                Text(t('shop.max'), style: ts(13.5, color: Pal.good)),
              ]),
          ]),
        ),
      ));
    }
    body.add(Text(t('shop.upgNote'), style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)));
  } else {
    final list = items.where((i) => i.kind == tab).toList();
    body.add(LayoutBuilder(builder: (context, cons) {
      final w = (cons.maxWidth - 16) / 3;
      return Wrap(spacing: 8, runSpacing: 8, children: [
        for (final it in list)
          SizedBox(
            width: w,
            child: Builder(builder: (context) {
              final st = Prog.status(it);
              final eq = Save.data.equipped[it.kind] == it.key && st.st == 'owned';
              final Widget preview = it.kind == 'skin'
                  ? BubblePreview('normal', skin: it.key, size: 62, hue: (hashStr(it.key) % 628) / 100)
                  : it.kind == 'fx'
                      ? FxPreview(it.key, size: 62)
                      : ThemePreview(it.key, size: 62);
              Widget action;
              if (st.st == 'owned') {
                action = eq
                    ? Row(mainAxisSize: MainAxisSize.min, children: [
                        Glyph('check', size: 16, color: Pal.good),
                        Flexible(child: Text(t('shop.equipped'), maxLines: 1, style: ts(13, color: Pal.good))),
                      ])
                    : smallBtn(t('shop.use'), () => _equip(it));
              } else if (st.st == 'buy') {
                action = Opacity(opacity: st.can ? 1 : 0.6, child: smallBtn('', () => _buy(it), child: coinAmt(it.price, size: 13, color: Pal.ink)));
              } else {
                action = Text(st.why,
                    textAlign: TextAlign.center, maxLines: 2, style: ts(11, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.15));
              }
              return Panel(
                color: eq ? Pal.cardStrong : Pal.card,
                border: eq ? Pal.frameEdge : null,
                padding: const EdgeInsets.fromLTRB(6, 9, 6, 9),
                child: Column(children: [
                  preview,
                  const SizedBox(height: 4),
                  SizedBox(
                    height: 34,
                    child: Center(
                      child: Text(it.name.s,
                          textAlign: TextAlign.center, maxLines: 2, style: ts(13, color: Pal.cInk, height: 1.1)),
                    ),
                  ),
                  SizedBox(height: 34, child: Center(child: action)),
                ]),
              );
            }),
          ),
      ]);
    }));
  }
  return scrollList([
    TabsBar(
        tabs: tabs,
        current: tab,
        onPick: (k) {
          app.shopTab = k;
          app.render();
        }),
    ...body,
  ]);
}

// ======================================================================
// MISSIONS
// ======================================================================
Widget _questItem(bool daily, QuestState it, int i) {
  final d = questDef(it.id);
  if (d == null) return const SizedBox.shrink();
  final done = it.p >= it.n;
  Widget? btn;
  if (it.claimed) {
    btn = Glyph('check', size: 22, color: Pal.good);
  } else if (done) {
    btn = smallBtn(t('btn.claim'), () {
      final q = Prog.claimQuest(daily, i);
      if (q != null) {
        GameAudio.play('coin');
        _toast('coin', t('toast.claimed'), '+${q.coins} · +${q.xp} ${t('xp')}');
        app.render();
        app.showLevelUps();
      }
    });
  } else if (daily && !Save.data.qDaily.rerolled) {
    btn = Semantics(
      label: t('mis.reroll'),
      button: true,
      child: GestureDetector(
        onTap: () {
          if (Prog.rerollDaily(i)) {
            GameAudio.play('ui');
            app.render();
          }
        },
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(shape: BoxShape.circle, color: Pal.cardStrong, border: Border.all(color: Pal.cardEdge, width: 2)),
          child: Glyph('refresh', size: 20, color: Pal.cInk),
        ),
      ),
    );
  }
  return Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Opacity(
      opacity: it.claimed ? 0.6 : 1,
      child: Panel(
        border: done && !it.claimed ? Pal.good : null,
        padding: const EdgeInsets.all(11),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.text.s.replaceAll('{n}', fmt(it.n)), style: ts(14.5, color: Pal.cInk)),
              const SizedBox(height: 3),
              Row(children: [
                Text('${fmt(math.min(it.p, it.n))} / ${fmt(it.n)}', style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
                const Spacer(),
                coinAmt(d.coins, size: 12.5),
                Text('  ·  ${d.xp} ${t('xp')}', style: ts(12.5, color: Pal.cInkSoft)),
              ]),
              const SizedBox(height: 5),
              ProgressBar(it.p / it.n, color: done ? Pal.good : Pal.cyan),
            ]),
          ),
          if (btn != null) ...[const SizedBox(width: 10), btn],
        ]),
      ),
    ),
  );
}

Widget giftRow(LoginState l, bool avail) {
  return Row(children: [
    for (var i = 0; i < loginGifts.length; i++)
      Expanded(
        child: Opacity(
          opacity: i < l.day ? 0.55 : 1,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 2),
            padding: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: i == l.day && avail ? Pal.frame : Pal.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: i == l.day && avail ? Pal.frameEdge : Pal.cardEdge, width: 2),
            ),
            child: Column(children: [
              Glyph(i < l.day ? 'check' : 'gift', size: 17, color: i == l.day && avail ? Pal.ink : Pal.cInk),
              Text(t('gift.day', {'n': i + 1}), maxLines: 1, style: ts(9.5, color: i == l.day && avail ? Pal.ink : Pal.cInk)),
              Text(fmt(loginGifts[i].coins), style: ts(10.5, color: i == l.day && avail ? Pal.ink : Pal.cInk)),
            ]),
          ),
        ),
      ),
  ]);
}

void claimGift() {
  final g = Prog.claimLogin();
  if (g != null) {
    GameAudio.play('coin');
    _toast('gift', t('toast.gift'), '+${g.coins}${g.xp > 0 ? ' · +${g.xp} ${t('xp')}' : ''}');
  }
  if (app.modal != null) {
    app.closeModal();
  } else {
    app.render();
  }
  app.showLevelUps();
}

Widget _missions() {
  Prog.ensureQuests();
  final s = Save.data;
  final tab = app.misTab;
  int cnt(List<QuestState> l) => l.where((x) => !x.claimed && x.p >= x.n).length;
  final seas = Prog.activeSeasons();
  final tabs = [
    ('daily', t('mis.daily'), cnt(s.qDaily.list) + (Prog.loginAvailable() ? 1 : 0)),
    ('weekly', t('mis.weekly'), cnt(s.qWeekly.list)),
    ('ach', t('mis.trophies'), 0),
    ('event', t('mis.event'), seas.fold<int>(0, (a, x) => a + Prog.seasonClaimable(x).length)),
  ];
  final body = <Widget>[];
  if (tab == 'daily') {
    final l = s.login;
    final avail = Prog.loginAvailable();
    body.add(Panel(
      color: Pal.cardStrong,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(t('gift.title'), style: ts(16, color: Pal.cInk)),
        Text(tn('gift.streak', l.streak), style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
        const SizedBox(height: 10),
        giftRow(l, avail),
        const SizedBox(height: 12),
        if (avail)
          Center(child: primary(t('btn.claim'), claimGift, icon: 'gift'))
        else
          Text(t('gift.tomorrow', {'t': fmtDuration(msUntilMidnight())}),
              textAlign: TextAlign.center, style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
      ]),
    ));
    body.add(sectionH(t('mis.today'), extra: t('mis.resets', {'t': fmtDuration(msUntilMidnight())})));
    for (var i = 0; i < s.qDaily.list.length; i++) {
      body.add(_questItem(true, s.qDaily.list[i], i));
    }
    if (!s.qDaily.rerolled) body.add(Text(t('mis.rerollNote'), style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)));
  } else if (tab == 'weekly') {
    body.add(sectionH(t('mis.resets', {'t': fmtDuration(msUntilWeekEnd())})));
    for (var i = 0; i < s.qWeekly.list.length; i++) {
      body.add(_questItem(false, s.qWeekly.list[i], i));
    }
  } else if (tab == 'ach') {
    final got = achievements.where((a) => s.ach.containsKey(a.id)).length;
    body.add(sub(t('ach.count', {'n': got, 'm': achievements.length})));
    for (final tier in const ['easy', 'medium', 'hard', 'rare']) {
      body.add(Padding(
        padding: const EdgeInsets.fromLTRB(2, 10, 2, 8),
        child: Row(children: [
          Text(t('tier.$tier'), style: ts(15.5, color: Pal.cInkSoft)),
          const SizedBox(width: 8),
          coinAmt(tierReward[tier]![0], size: 12.5),
        ]),
      ));
      for (final a in achievements.where((x) => x.tier == tier)) {
        final done = s.ach.containsKey(a.id);
        final hide = a.secret && !done;
        final pr = Prog.achProgress(a);
        final reward = a.rewardItem.isNotEmpty ? itemById(a.rewardItem) : null;
        body.add(Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Panel(
            border: done ? Pal.good : null,
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(color: done ? const Color(0xFFFFE27A) : Pal.cardStrong, shape: BoxShape.circle),
                alignment: Alignment.center,
                child: Glyph(done ? 'trophy' : 'lock', size: 21, color: done ? const Color(0xFF8A5A00) : Pal.cInkSoft),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(hide ? '???' : a.name.s, style: ts(14.5, color: done ? Pal.cInk : Pal.cInkSoft)),
                  Text('${a.desc.s}${reward != null ? ' · ${t('ach.unlocks', {'name': reward.name.s})}' : ''}',
                      style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.25)),
                  if (pr != null && !done && !hide) ...[
                    const SizedBox(height: 5),
                    ProgressBar(pr.cur / pr.n),
                    Text('${fmt(pr.cur)} / ${fmt(pr.n)}', style: ts(11.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
                  ],
                ]),
              ),
            ]),
          ),
        ));
      }
    }
  } else if (tab == 'event') {
    if (seas.isEmpty) {
      final nx = Prog.nextSeason();
      body.add(Panel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t('event.none'), style: ts(15, color: Pal.cInk)),
          if (nx != null) Text(t('event.next', {'name': nx.sea.name.s, 'n': nx.days}), style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
        ]),
      ));
    }
    for (final sea in seas) {
      final st = Prog.seasonState(sea)!;
      body.add(Panel(
        color: Pal.cardStrong,
        child: Row(children: [
          BubblePreview('event', size: 44, season: sea),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(sea.name.s, style: ts(16, color: Pal.cInk)),
              Text('${sea.desc.s} · ${tn('event.daysLeft', Prog.seasonEnds(sea))}',
                  style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.25)),
            ]),
          ),
        ]),
      ));
      body.add(sectionH(t('event.collected', {'n': fmt(st.n)})));
      for (var i = 0; i < sea.tiers.length; i++) {
        final tr = sea.tiers[i];
        final it = tr.item.isNotEmpty ? itemById(tr.item) : null;
        final claimed = st.claimed.contains(i), ready = st.n >= tr.n;
        body.add(Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Opacity(
            opacity: claimed ? 0.6 : 1,
            child: Panel(
              border: ready && !claimed ? Pal.good : null,
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(color: Pal.cardStrong, shape: BoxShape.circle),
                  alignment: Alignment.center,
                  child: Glyph(it != null ? 'gift' : 'coin', size: 22, color: Pal.cInk),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(t('event.tier', {'n': fmt(tr.n)}), style: ts(14.5, color: Pal.cInk)),
                    if (it != null)
                      Text(it.name.s + (Prog.owns(tr.item) && !claimed ? ' (${t('event.ownedSwap')})' : ''),
                          style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500))
                    else
                      coinAmt(tr.coins, size: 12.5),
                    const SizedBox(height: 5),
                    ProgressBar(st.n / tr.n, color: ready ? Pal.good : Pal.cyan),
                  ]),
                ),
                const SizedBox(width: 8),
                if (claimed)
                  Glyph('check', size: 22, color: Pal.good)
                else if (ready)
                  smallBtn(t('btn.claim'), () {
                    if (Prog.claimTier(sea, i)) {
                      GameAudio.play('buy');
                      _toast('gift', t('toast.claimed'), sea.name.s);
                      app.render();
                    }
                  }),
              ]),
            ),
          ),
        ));
      }
    }
    body.add(Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Text(t('event.note'), style: ts(12, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.35)),
    ));
  }
  return scrollList([
    TabsBar(
        tabs: tabs,
        current: tab,
        onPick: (k) {
          app.misTab = k;
          app.render();
        }),
    ...body,
  ]);
}

// ======================================================================
// COLLECTION (stats, bubble guide, records)
// ======================================================================
Widget statRow(String k, String v) => Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(color: Pal.card, borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          Expanded(child: Text(k, style: ts(14, color: Pal.cInk, weight: FontWeight.w500))),
          Text(v, style: ts(14.5, color: Pal.cInk)),
        ]),
      ),
    );

Widget _collection() {
  final s = Save.data;
  final tab = app.collTab;
  final tabs = [('stats', t('coll.stats'), 0), ('bubbles', t('coll.bubbles'), 0), ('records', t('coll.records'), 0)];
  final body = <Widget>[];
  if (tab == 'stats') {
    final st = s.stats;
    body.addAll([
      statRow(t('st.level'), fmt(s.profile.level)),
      statRow(t('st.pops'), fmt(st.pops)),
      statRow(t('st.games'), fmt(st.games)),
      statRow(t('st.time'), fmtDuration(st.playMs)),
      statRow(t('st.streak'), fmt(st.bestStreak)),
      statRow(t('st.chain'), fmt(st.bestChain)),
      statRow(t('st.powers'), fmt(st.powersUsed)),
      statRow(t('st.fevers'), fmt(st.fevers)),
      statRow(t('st.coins'), fmt(st.coinsEarned)),
      statRow(t('st.quests'), fmt(st.questsDone)),
      statRow(t('st.ach'), '${s.ach.length} / ${achievements.length}'),
      statRow(t('st.gold'), fmt(st.popsBy['gold'] ?? 0)),
      statRow(t('st.login'), fmt(s.login.best)),
    ]);
  } else if (tab == 'bubbles') {
    final types = bubbles.keys.where((k) => !bubbles[k]!.hidden).toList();
    final found = types.where((k) => s.discovered.contains(k)).length;
    body.add(sub(t('coll.found', {'n': found, 'm': types.length})));
    for (final k in types) {
      final d = bubbles[k]!;
      final known = s.discovered.contains(k);
      body.add(Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Opacity(
          opacity: known ? 1 : 0.65,
          child: Panel(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              SizedBox(width: 44, height: 44, child: known ? BubblePreview(k, size: 44) : Center(child: Glyph('lock', size: 22, color: Pal.cInkSoft))),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(known ? d.name.s : '???', style: ts(14.5, color: Pal.cInk)),
                  Text(known ? d.desc.s : t('coll.unknown'), style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.25)),
                  if (known && d.pts > 0)
                    Text(
                        '${t('coll.pts', {'n': d.hp > 1 ? '${d.pts}×${d.hp - 1} + ${d.finalPts}' : '${d.pts}'})} · ${t('coll.popped', {'n': fmt(s.stats.popsBy[k] ?? 0)})}',
                        style: ts(12.5, color: Pal.cInk)),
                ]),
              ),
            ]),
          ),
        ),
      ));
    }
  } else {
    for (final m in const ['classic', 'time', 'survival']) {
      body.add(sectionH(modes[m]!.name.s));
      for (final d in difficulty.keys) {
        body.add(statRow(difficulty[d]!.name.s, fmt(s.best[m]?[d] ?? 0)));
      }
      if (m == 'survival') body.add(statRow(t('rec.longest'), fmtTime(s.survivalTime)));
    }
    body
      ..add(sectionH(modes['zen']!.name.s))
      ..add(statRow(t('rec.zen'), fmt(s.zenPops)))
      ..add(sectionH(modes['challenge']!.name.s))
      ..add(statRow(t('rec.stars'), '${totalStars(s)} / ${stages.length * 3}'))
      ..add(statRow(t('rec.cleared'), '${clearedStages(s)} / ${stages.length}'))
      ..add(sectionH(modes['daily']!.name.s));
    final hist = s.daily.history.reversed.take(7).toList();
    if (hist.isEmpty) body.add(sub(t('rec.noDaily'), align: TextAlign.start));
    for (final h in hist) {
      body.add(statRow(h.d, '${fmt(h.s)}${h.w ? ' ✓' : ''}'));
    }
  }
  return scrollList([
    TabsBar(
        tabs: tabs,
        current: tab,
        onPick: (k) {
          app.collTab = k;
          app.render();
        }),
    ...body,
  ]);
}

// ======================================================================
// SETTINGS
// ======================================================================
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget _row(String icon, String label, Widget ctrl) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Panel(
        padding: const EdgeInsets.fromLTRB(12, 8, 10, 8),
        child: Row(children: [
          Glyph(icon, size: 22, color: Pal.cInk),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: ts(14.5, color: Pal.cInk))),
          ctrl,
        ]),
      ),
    );
  }

  Widget _slider(double v, ValueChanged<double> onChanged) {
    return SizedBox(
      width: 108,
      child: SliderTheme(
        data: SliderThemeData(
          trackHeight: 5,
          activeTrackColor: const Color(0xFFE8A800),
          inactiveTrackColor: withA(Pal.cInk, 0.18),
          thumbColor: Pal.frame,
          overlayShape: SliderComponentShape.noOverlay,
          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9),
        ),
        child: Slider(value: v, onChanged: onChanged),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = Save.data.settings;
    void save() {
      Save.dirty();
      app.applyAudio();
      app.render();
    }

    return scrollList([
      _row('lang', t('set.lang'), Segmented(options: const [('ar', 'العربية'), ('en', 'English')], value: st.lang, onPick: app.setLang)),
      _row(
          'volume',
          t('set.sfx'),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _slider(st.sfx, (v) {
              st.sfx = v;
              save();
            }),
            ToySwitch(st.sfxOn, (v) {
              st.sfxOn = v;
              save();
              if (v) GameAudio.play('pop', arg: 3);
            }),
          ])),
      _row(
          'music',
          t('set.music'),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _slider(st.music, (v) {
              st.music = v;
              save();
            }),
            ToySwitch(st.musicOn, (v) {
              st.musicOn = v;
              save();
            }),
          ])),
      _row(
          'vibrate',
          t('set.vibrate'),
          ToySwitch(st.vibrate, (v) {
            st.vibrate = v;
            save();
            if (v) HapticFeedback.mediumImpact();
          })),
      _row(
          'speed',
          t('set.difficulty'),
          Segmented(
              options: [for (final k in difficulty.keys) (k, difficulty[k]!.name.s)],
              value: st.difficulty,
              onPick: (v) {
                st.difficulty = v;
                save();
              })),
      _row(
          'motion',
          t('set.motion'),
          Segmented(
              options: [('auto', t('set.auto')), ('reduced', t('set.less')), ('full', t('set.full'))],
              value: st.motion,
              onPick: (v) {
                st.motion = v;
                app.applyTheme();
                save();
              })),
      sectionH(t('set.progress')),
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(Save.store.ok ? t('set.saveNote') : t('set.noStorage'),
            style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.35)),
      ),
      Wrap(spacing: 8, runSpacing: 10, children: [
        smallBtn(t('set.export'), () => app.openModal((c) => exportModal(c)), icon: 'upload', color: Colors.white),
        smallBtn(t('set.import'), () => app.openModal((c) => const ImportModal()), icon: 'download', color: Colors.white),
        smallBtn(t('set.whatsNew'), () => app.openModal((c) => whatsNewModal(c)), icon: 'new', color: Colors.white),
        smallBtn(t('set.howTo'), () => app.openModal((c) => howToModal(c)), icon: 'help', color: Colors.white),
        smallBtn(t('set.reset'), () => app.openModal((c) => resetModal(c)), icon: 'delete', color: Pal.heart),
      ]),
      const SizedBox(height: 14),
      Text(t('set.about', {'v': contentVersion}), style: ts(12, color: Pal.cInkSoft, weight: FontWeight.w500)),
    ]);
  }
}

// ======================================================================
// PAUSE & RESULTS
// ======================================================================
Widget _pause() {
  final r = app.engine.r;
  final zen = app.engine.mode == 'zen';
  return scrollCenter(Column(mainAxisSize: MainAxisSize.min, children: [
    h2(t('pause.title')),
    sub(zen ? t('pause.zenPops', {'n': fmt(r?.pops ?? 0)}) : t('pause.score', {'n': fmt(r?.score ?? 0)})),
    SizedBox(
      width: 250,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        ChunkyButton(onTap: app.resume, expand: true, child: BtnLabel(t('btn.resume'), icon: 'play')),
        const SizedBox(height: 10),
        ChunkyButton(onTap: app.restart, expand: true, color: Colors.white, child: BtnLabel(t('btn.restart'), icon: 'refresh')),
        const SizedBox(height: 10),
        ChunkyButton(onTap: () => app.go('settings'), expand: true, color: Colors.white, child: BtnLabel(t('home.settings'), icon: 'gear')),
        const SizedBox(height: 10),
        ChunkyButton(onTap: app.quit, expand: true, color: Colors.white, child: BtnLabel(zen ? t('btn.finish') : t('btn.quit'), icon: 'home')),
      ]),
    ),
    if (!zen && app.engine.mode != 'challenge')
      Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Text(t('pause.quitNote'), textAlign: TextAlign.center, style: ts(12.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
      ),
  ]));
}

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final r = app.resR, res = app.resRes;
    if (r == null || res == null) return const SizedBox.shrink();
    final s = Save.data;
    String title;
    if (r.mode == 'challenge') {
      title = r.won ? t('res.clear') : t('res.failed');
    } else if (r.mode == 'zen') {
      title = t('res.zen');
    } else if (r.reason == 'time') {
      title = t('res.timeUp');
    } else {
      title = t('res.over');
    }
    final big = r.mode == 'zen' ? r.pops : r.score;
    final unit = r.mode == 'zen' ? tn('unit.bubbles', r.pops) : tn('unit.points', r.score);

    Widget mini(String label, Widget val) => Container(
          width: 98,
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 7),
          decoration: BoxDecoration(color: Pal.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pal.cardEdge, width: 2)),
          child: Column(children: [
            DefaultTextStyle(style: ts(20, color: Pal.cInk), child: val),
            const SizedBox(height: 2),
            Text(label, textAlign: TextAlign.center, maxLines: 2, style: ts(11.5, color: Pal.cInkSoft, weight: FontWeight.w500, height: 1.15)),
          ]),
        );

    final minis = <Widget>[
      if (r.mode == 'survival') mini(t('res.time') + (res.newBestTime ? ' ★' : ''), Text(fmtTime(r.timeMs))),
      if (r.mode != 'zen') mini(t('res.streak'), Text(fmt(r.bestStreak))),
      mini(t('res.pops'), Text(fmt(r.pops))),
      mini(t('res.runCoins'), Row(mainAxisSize: MainAxisSize.min, children: [const Glyph('coin', size: 18), Text('+${fmt(res.coins)}')])),
      if (r.tokens > 0) mini(t('res.tokens'), Text('+${fmt(r.tokens)}')),
    ];
    final notes = <String>[
      if (r.mode == 'daily') '${r.score >= r.target ? '✓' : '✗'} ${t('daily.target', {'n': r.target})}',
      for (final ln in res.lines)
        if (ln.key != 'res.runCoins') '${t(ln.key)} +${fmt(ln.value)}',
    ];
    final p0 = res.levelUps.isNotEmpty ? 0.0 : res.xpBefore / xpForLevel(res.levelBefore);
    final p1 = s.profile.xp / xpForLevel(s.profile.level);
    final nextStage = r.mode == 'challenge' && r.won && r.stage < stages.length;

    final content = Column(mainAxisSize: MainAxisSize.min, children: [
      h2(title),
      if (r.mode == 'challenge' && r.won)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < 3; i++)
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: Duration(milliseconds: 450 + i * 150),
                curve: Interval(i * 0.25, 1, curve: Curves.elasticOut),
                builder: (context, v, _) => Transform.scale(
                  scale: i < r.stars ? v : 1,
                  child: Icon(Icons.star_rounded, size: 46, color: i < r.stars ? const Color(0xFFF5B800) : withA(Pal.cInk, 0.2)),
                ),
              ),
          ]),
        ),
      if (r.mode == 'challenge' && !r.won) sub(t('fail.${r.reason}')),
      Text.rich(
        TextSpan(children: [
          TextSpan(text: fmt(big), style: ts(58, color: Pal.cInk, height: 1)),
          TextSpan(text: '  $unit', style: ts(19, color: Pal.cInk, weight: FontWeight.w500)),
        ]),
        textAlign: TextAlign.center,
      ),
      if (res.newBest && r.mode != 'challenge')
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.3, end: 1),
            duration: const Duration(milliseconds: 600),
            curve: Curves.elasticOut,
            builder: (context, v, child) => Transform.scale(scale: v, child: child),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(color: Pal.heart, borderRadius: BorderRadius.circular(999)),
              child: Text(t('res.newBest'), style: ts(15, color: Colors.white)),
            ),
          ),
        )
      else if (r.mode != 'challenge' && r.mode != 'zen')
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(t('res.best', {'n': fmt(res.best)}), style: ts(13.5, color: Pal.cInkSoft, weight: FontWeight.w500)),
        ),
      const SizedBox(height: 14),
      Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: minis),
      if (notes.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Text(notes.join(' · '), textAlign: TextAlign.center, style: ts(13, color: Pal.cInk)),
        ),
      const SizedBox(height: 14),
      ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 300),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Text(t('level.n', {'n': s.profile.level}), style: ts(13, color: Pal.cInk)),
            const Spacer(),
            Text('+${fmt(res.xp)} ${t('xp')}', style: ts(13, color: Pal.cInk)),
          ]),
          const SizedBox(height: 4),
          TweenAnimationBuilder<double>(
            tween: Tween(begin: p0, end: p1),
            duration: const Duration(milliseconds: 1100),
            curve: Curves.easeOutCubic,
            builder: (context, v, _) => ProgressBar(v, height: 13),
          ),
        ]),
      ),
      if (res.ach.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [
            for (final a in res.ach)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: Pal.card, borderRadius: BorderRadius.circular(999), border: Border.all(color: Pal.cardEdge, width: 2)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Glyph('trophy', size: 16, color: Color(0xFFB07A00)),
                  const SizedBox(width: 4),
                  Text(a.name.s, style: ts(12.5, color: Pal.cInk)),
                ]),
              ),
          ]),
        ),
    ]);
    return withCta(content, [
      if (nextStage) primary(t('btn.next'), () => app.startRun('challenge', stage: r.stage + 1), icon: 'play'),
      if (nextStage)
        ghost(t('btn.again'), app.playAgain, icon: 'refresh')
      else
        primary(r.mode == 'challenge' && !r.won ? t('btn.retry') : t('btn.again'), app.playAgain, icon: 'refresh'),
      ghost(t('btn.menu'), () => app.go('home', reset: true), icon: 'home'),
    ]);
  }
}

// ======================================================================
// MODALS
// ======================================================================
Widget modalTitle(String s) => Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(s, textAlign: TextAlign.center, style: ts(26, color: Pal.ink)),
    );

Widget modalText(String s) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(s, textAlign: TextAlign.center, style: ts(14.5, color: Pal.ink, weight: FontWeight.w500, height: 1.4)),
    );

Widget bullets(List<String> list) => Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final x in list)
          Padding(
            padding: const EdgeInsets.only(bottom: 5),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(padding: const EdgeInsets.only(top: 7), child: Container(width: 6, height: 6, decoration: BoxDecoration(color: Pal.ink, shape: BoxShape.circle))),
              const SizedBox(width: 8),
              Expanded(child: Text(x, style: ts(14, color: Pal.ink, weight: FontWeight.w500, height: 1.4))),
            ]),
          ),
      ]),
    );

Widget okButton(String label, VoidCallback onTap) =>
    Center(child: ChunkyButton(onTap: onTap, color: Colors.white, child: BtnLabel(label, size: 17)));

Widget levelModal(BuildContext c, LevelUp lu) {
  final list = <String>[t('lvl.coins', {'n': fmt(lu.coins)})];
  for (final m in lu.modes) {
    list.add(t('lvl.mode', {'name': modes[m]!.name.s}));
  }
  for (final it in lu.items) {
    list.add(t('lvl.item', {'name': itemById(it)?.name.s ?? it}));
  }
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('lvl.title')),
    Center(
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: const Duration(milliseconds: 700),
        curve: Curves.elasticOut,
        builder: (context, v, child) => Transform.scale(scale: v, child: child),
        child: Container(
          width: 88,
          height: 88,
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Pal.frameEdge, width: 3)),
          alignment: Alignment.center,
          child: Text('${lu.level}', style: ts(40, color: Pal.ink)),
        ),
      ),
    ),
    modalText(t('lvl.reached', {'n': lu.level})),
    bullets(list),
    okButton(t('btn.great'), () => app.closeModal()),
  ]);
}

Widget giftModal(BuildContext c) {
  final l = Save.data.login;
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('gift.title')),
    modalText(t(l.total > 0 ? 'gift.body' : 'gift.first')),
    giftRow(l, true),
    const SizedBox(height: 14),
    Center(child: ChunkyButton(onTap: claimGift, color: Colors.white, child: BtnLabel(t('btn.claim'), icon: 'gift'))),
    const SizedBox(height: 10),
    Text(t('gift.note'), textAlign: TextAlign.center, style: ts(12, color: Pal.inkSoft, weight: FontWeight.w500)),
  ]);
}

Widget whatsNewModal(BuildContext c) {
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('new.title')),
    for (final ch in changelog.reversed) ...[
      Text(t('new.version', {'v': ch.v}), style: ts(15, color: Pal.ink)),
      const SizedBox(height: 6),
      bullets(gLang == 'ar' ? ch.ar : ch.en),
    ],
    okButton(t('btn.great'), () => app.closeModal()),
  ]);
}

Widget howToModal(BuildContext c) {
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('set.howTo')),
    bullets([for (final k in const ['how.1', 'how.2', 'how.3', 'how.4', 'how.5']) t(k)]),
    Text(t('how.powerList'), style: ts(15, color: Pal.ink)),
    const SizedBox(height: 6),
    bullets([for (final p in powers.values) '${p.name.s} — ${p.desc.s}']),
    okButton(t('btn.ok'), () => app.closeModal()),
  ]);
}

Widget exportModal(BuildContext c) {
  Save.flush();
  final code = Save.exportCode();
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('set.export')),
    modalText(t('exp.body')),
    Container(
      height: 110,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(color: Colors.white.withAlpha(200), borderRadius: BorderRadius.circular(12), border: Border.all(color: Pal.cardEdge, width: 2)),
      child: SingleChildScrollView(
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: SelectableText(code, style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFF14304D))),
        ),
      ),
    ),
    const SizedBox(height: 12),
    Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: [
      smallBtn(t('exp.copy'), () {
        Clipboard.setData(ClipboardData(text: code));
        _toast('check', t('exp.copied'));
      }, icon: 'copy', color: Colors.white),
      smallBtn(t('btn.close'), () => app.closeModal(), color: Colors.white),
    ]),
  ]);
}

class ImportModal extends StatefulWidget {
  const ImportModal({super.key});
  @override
  State<ImportModal> createState() => _ImportModalState();
}

class _ImportModalState extends State<ImportModal> {
  final TextEditingController _c = TextEditingController();
  String _msg = '';

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    try {
      final d = await Clipboard.getData('text/plain');
      if (d?.text != null) setState(() => _c.text = d!.text!.trim());
    } catch (_) {}
  }

  void _go() {
    final data = Save.importCode(_c.text);
    if (data == null) {
      setState(() => _msg = t('imp.bad'));
      return;
    }
    Save.data = data;
    Save.flush();
    gLang = data.settings.lang;
    app.applyTheme();
    app.applyAudio();
    app.closeModal(silent: true);
    app.go('home', reset: true);
    _toast('check', t('imp.ok'));
  }

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      modalTitle(t('set.import')),
      modalText(t('imp.body')),
      Directionality(
        textDirection: TextDirection.ltr,
        child: TextField(
          controller: _c,
          minLines: 3,
          maxLines: 5,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFF14304D)),
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white.withAlpha(220),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            isDense: true,
          ),
        ),
      ),
      if (_msg.isNotEmpty)
        Padding(padding: const EdgeInsets.only(top: 8), child: Text(_msg, textAlign: TextAlign.center, style: ts(13, color: const Color(0xFFC0123F)))),
      const SizedBox(height: 12),
      Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: [
        smallBtn(t('imp.paste'), _paste, icon: 'paste', color: Colors.white),
        smallBtn(t('imp.go'), _go, icon: 'download'),
        smallBtn(t('btn.cancel'), () => app.closeModal(), color: Colors.white),
      ]),
    ]);
  }
}

Widget resetModal(BuildContext c) {
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('reset.title')),
    modalText(t('reset.body')),
    Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: [
      smallBtn(t('reset.yes'), () {
        Save.reset();
        gLang = Save.data.settings.lang;
        app.applyTheme();
        app.applyAudio();
        app.closeModal(silent: true);
        app.go('home', reset: true);
        _toast('refresh', t('reset.done'));
      }, icon: 'delete', color: Pal.heart),
      smallBtn(t('btn.cancel'), () => app.closeModal(), color: Colors.white),
    ]),
  ]);
}

Widget exitModal(BuildContext c) {
  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    modalTitle(t('exit.title')),
    const SizedBox(height: 4),
    Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: [
      smallBtn(t('exit.yes'), () {
        Save.flush();
        SystemNavigator.pop();
      }, icon: 'close', color: Pal.heart),
      smallBtn(t('btn.cancel'), () => app.closeModal(), color: Colors.white),
    ]),
  ]);
}
