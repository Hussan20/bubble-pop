// UI KIT — palette, type, icons and the chunky toy-like building blocks.
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/content.dart';
import '../core/strings.dart';
import '../services/audio.dart';

/// Current theme palette as Flutter colors.
class Pal {
  static ThemeDef th = themes['bath']!;
  static Color get frame => Color(th.frame);
  static Color get frameEdge => Color(th.frameEdge);
  static Color get frameShadow => Color(th.frameShadow);
  static Color get ink => Color(th.ink);
  static Color get inkSoft => Color(th.inkSoft);
  static Color get heart => Color(th.heart);
  static Color get page => Color(th.page);
  static Color get grout => Color(th.grout);
  static Color get water => Color(th.water);
  static Color get water2 => Color(th.water2);
  static Color get veil => Color(th.veil);
  static Color get card => Color(th.card);
  static Color get cardStrong => Color(th.cardStrong);
  static Color get cardEdge => Color(th.cardEdge);
  static Color get pink => Color(th.pink);
  static Color get cyan => Color(th.cyan);
  static Color get good => Color(th.good);
  static Color get goldEdge => Color(th.goldEdge);
  static Color get cInk => Color(th.canvasInk);
  static Color get cInkSoft => Color(th.canvasInkSoft);
  static Color get halo => Color(th.halo);
  static bool get dark => th.dark;
}

Color withA(Color c, double a) => c.withAlpha((a.clamp(0.0, 1.0) * 255).round());

/// Text style in the game's rounded fonts (Sniglet for Latin, Baloo for Arabic).
TextStyle ts(double size, {Color? color, FontWeight weight = FontWeight.w800, double? height, List<Shadow>? shadows}) {
  final ar = gLang == 'ar';
  return TextStyle(
    fontFamily: ar ? 'Baloo' : 'Sniglet',
    fontFamilyFallback: ar ? const ['Sniglet'] : const ['Baloo'],
    fontSize: size,
    fontWeight: weight,
    fontVariations: [FontVariation('wght', weight == FontWeight.w800 ? 800 : (weight == FontWeight.w700 ? 700 : 500))],
    color: color,
    height: height,
    shadows: shadows,
  );
}

// ---------------------------------------------------------------- icons
IconData? materialIcon(String id) {
  switch (id) {
    case 'play':
      return Icons.play_arrow_rounded;
    case 'pause':
      return Icons.pause_rounded;
    case 'back':
      return Icons.arrow_back_rounded;
    case 'clock':
      return Icons.schedule_rounded;
    case 'star':
      return Icons.star_rounded;
    case 'heart':
      return Icons.favorite_rounded;
    case 'gear':
      return Icons.settings_rounded;
    case 'bag':
      return Icons.shopping_bag_rounded;
    case 'target':
      return Icons.track_changes_rounded;
    case 'chart':
      return Icons.bar_chart_rounded;
    case 'grid':
      return Icons.grid_view_rounded;
    case 'lock':
      return Icons.lock_rounded;
    case 'check':
      return Icons.check_rounded;
    case 'gift':
      return Icons.card_giftcard_rounded;
    case 'refresh':
      return Icons.refresh_rounded;
    case 'home':
      return Icons.home_rounded;
    case 'trophy':
      return Icons.emoji_events_rounded;
    case 'slow':
      return Icons.hourglass_bottom_rounded;
    case 'blast':
      return Icons.flare_rounded;
    case 'shield':
      return Icons.shield_rounded;
    case 'calendar':
      return Icons.calendar_month_rounded;
    case 'bolt':
      return Icons.bolt_rounded;
    case 'leaf':
      return Icons.eco_rounded;
    case 'skull':
      return Icons.local_fire_department_rounded;
    case 'flag':
      return Icons.flag_rounded;
    case 'sparkle':
      return Icons.auto_awesome_rounded;
    case 'volume':
      return Icons.volume_up_rounded;
    case 'mute':
      return Icons.volume_off_rounded;
    case 'music':
      return Icons.music_note_rounded;
    case 'vibrate':
      return Icons.vibration_rounded;
    case 'lang':
      return Icons.translate_rounded;
    case 'copy':
      return Icons.content_copy_rounded;
    case 'paste':
      return Icons.content_paste_rounded;
    case 'close':
      return Icons.close_rounded;
    case 'help':
      return Icons.help_outline_rounded;
    case 'new':
      return Icons.new_releases_rounded;
    case 'delete':
      return Icons.delete_forever_rounded;
    case 'upload':
      return Icons.upload_rounded;
    case 'download':
      return Icons.download_rounded;
    case 'speed':
      return Icons.speed_rounded;
    case 'motion':
      return Icons.animation_rounded;
    case 'swap':
      return Icons.swap_horiz_rounded;
    case 'palette':
      return Icons.palette_rounded;
    case 'bubbles':
      return Icons.bubble_chart_rounded;
    case 'party':
      return Icons.celebration_rounded;
    case 'ice':
      return Icons.ac_unit_rounded;
    case 'split':
      return Icons.call_split_rounded;
    case 'timer':
      return Icons.timer_rounded;
  }
  return null;
}

/// Draws a horseshoe magnet into [c] centred at [ctr] with size [s].
void paintMagnet(Canvas c, Offset ctr, double s, Color color) {
  final w = s * 0.62, top = ctr.dy - s * 0.36, bottom = ctr.dy + s * 0.34, arm = s * 0.2;
  final path = Path()
    ..moveTo(ctr.dx - w / 2, top)
    ..lineTo(ctr.dx - w / 2, bottom - w / 2)
    ..arcToPoint(Offset(ctr.dx + w / 2, bottom - w / 2), radius: Radius.circular(w / 2), clockwise: false)
    ..lineTo(ctr.dx + w / 2, top);
  final p = Paint()
    ..color = color
    ..style = PaintingStyle.stroke
    ..strokeWidth = arm
    ..strokeCap = StrokeCap.butt;
  c.drawPath(path, p);
  final tip = Paint()..color = const Color(0xFFFFFFFF).withAlpha(230);
  c.drawRect(Rect.fromLTWH(ctr.dx - w / 2 - arm / 2, top - 1, arm, s * 0.17), tip);
  c.drawRect(Rect.fromLTWH(ctr.dx + w / 2 - arm / 2, top - 1, arm, s * 0.17), tip);
}

/// Gold coin with rim and shine.
void paintCoin(Canvas c, Offset ctr, double s) {
  final r = s * 0.42;
  c.drawCircle(ctr, r, Paint()..color = const Color(0xFFFFC928));
  c.drawCircle(
      ctr,
      r,
      Paint()
        ..color = const Color(0xFFA86F00)
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * 0.085);
  c.drawCircle(
      ctr,
      r * 0.6,
      Paint()
        ..color = const Color(0xFFA86F00)
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * 0.065);
  c.drawArc(
      Rect.fromCircle(center: ctr, radius: r * 0.6),
      math.pi * 1.1,
      math.pi * 0.42,
      false,
      Paint()
        ..color = const Color(0xFFFFFFFF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * 0.07
        ..strokeCap = StrokeCap.round);
}

class _GlyphPainter extends CustomPainter {
  final String id;
  final Color color;
  _GlyphPainter(this.id, this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final ctr = size.center(Offset.zero);
    if (id == 'magnet') {
      paintMagnet(canvas, ctr, size.shortestSide, color);
    } else {
      paintCoin(canvas, ctr, size.shortestSide);
    }
  }

  @override
  bool shouldRepaint(covariant _GlyphPainter old) => old.id != id || old.color != color;
}

/// Any game icon: Material glyphs plus a painted magnet and coin.
class Glyph extends StatelessWidget {
  final String id;
  final double size;
  final Color? color;
  const Glyph(this.id, {super.key, this.size = 22, this.color});
  @override
  Widget build(BuildContext context) {
    final col = color ?? DefaultTextStyle.of(context).style.color ?? Pal.ink;
    if (id == 'magnet' || id == 'coin') {
      return SizedBox(width: size, height: size, child: CustomPaint(painter: _GlyphPainter(id, col)));
    }
    return Icon(materialIcon(id) ?? Icons.circle, size: size, color: col);
  }
}

// ---------------------------------------------------------------- building blocks
/// A chunky button with a solid "lip" that presses down.
class ChunkyButton extends StatefulWidget {
  final VoidCallback? onTap;
  final Widget child;
  final Color? color;
  final Color? textColor;
  final double radius;
  final EdgeInsetsGeometry padding;
  final double lip;
  final bool expand;
  const ChunkyButton({
    super.key,
    required this.onTap,
    required this.child,
    this.color,
    this.textColor,
    this.radius = 999,
    this.padding = const EdgeInsets.symmetric(horizontal: 26, vertical: 13),
    this.lip = 5,
    this.expand = false,
  });

  @override
  State<ChunkyButton> createState() => _ChunkyButtonState();
}

class _ChunkyButtonState extends State<ChunkyButton> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    final base = widget.color ?? Pal.frame;
    final lip = _down ? 1.0 : widget.lip;
    final body = AnimatedContainer(
      duration: const Duration(milliseconds: 70),
      margin: EdgeInsets.only(top: widget.lip - lip, bottom: lip),
      padding: widget.padding,
      decoration: BoxDecoration(
        color: base,
        borderRadius: BorderRadius.circular(widget.radius),
        border: Border.all(color: Pal.frameEdge, width: 2.6),
        boxShadow: [BoxShadow(color: Pal.frameEdge, offset: Offset(0, lip), blurRadius: 0)],
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color.lerp(base, Colors.white, 0.22)!, base],
        ),
      ),
      child: DefaultTextStyle.merge(
        style: TextStyle(color: widget.textColor ?? Pal.ink),
        child: IconTheme.merge(
          data: IconThemeData(color: widget.textColor ?? Pal.ink),
          // a Flexible child only when our width is bounded (e.g. not inside a Row)
          child: LayoutBuilder(builder: (context, cons) {
            final bounded = cons.hasBoundedWidth;
            return Row(
              mainAxisSize: widget.expand && bounded ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [if (bounded) Flexible(child: widget.child) else widget.child],
            );
          }),
        ),
      ),
    );
    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: enabled ? (_) => setState(() => _down = true) : null,
        onTapCancel: enabled ? () => setState(() => _down = false) : null,
        onTapUp: enabled ? (_) => setState(() => _down = false) : null,
        onTap: enabled
            ? () {
                GameAudio.play('ui');
                widget.onTap!();
              }
            : null,
        child: body,
      ),
    );
  }
}

/// Icon + label laid out for buttons.
class BtnLabel extends StatelessWidget {
  final String? icon;
  final String text;
  final double size;
  const BtnLabel(this.text, {super.key, this.icon, this.size = 18});
  @override
  Widget build(BuildContext context) {
    final col = DefaultTextStyle.of(context).style.color ?? Pal.ink;
    return LayoutBuilder(builder: (context, cons) {
      final label = Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(size, color: col));
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Glyph(icon!, size: size + 4, color: col), SizedBox(width: size * 0.4)],
          if (cons.hasBoundedWidth) Flexible(child: label) else label,
        ],
      );
    });
  }
}

/// Round icon button used in the top bar.
class RoundIconButton extends StatelessWidget {
  final String icon;
  final VoidCallback onTap;
  final double size;
  final String? tooltip;
  const RoundIconButton(this.icon, this.onTap, {super.key, this.size = 40, this.tooltip});
  @override
  Widget build(BuildContext context) {
    final b = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withAlpha(120),
          border: Border.all(color: Pal.frameEdge, width: 2.5),
        ),
        alignment: Alignment.center,
        child: Glyph(icon, size: size * 0.55, color: Pal.ink),
      ),
    );
    return tooltip == null ? b : Semantics(label: tooltip, button: true, child: b);
  }
}

/// Translucent rounded panel used for cards and list rows.
class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final Color? border;
  final double radius;
  final VoidCallback? onTap;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(12), this.color, this.border, this.radius = 18, this.onTap});
  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? Pal.card,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: border ?? Pal.cardEdge, width: 2.2),
      ),
      child: child,
    );
    if (onTap == null) return box;
    return GestureDetector(behavior: HitTestBehavior.opaque, onTap: onTap, child: box);
  }
}

class ProgressBar extends StatelessWidget {
  final double value;
  final double height;
  final Color? color;
  final Color? track;
  final bool outline;
  const ProgressBar(this.value, {super.key, this.height = 9, this.color, this.track, this.outline = false});
  @override
  Widget build(BuildContext context) {
    final v = value.isNaN ? 0.0 : value.clamp(0.0, 1.0);
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: track ?? withA(Pal.cInk, 0.12),
        borderRadius: BorderRadius.circular(height),
        border: outline ? Border.all(color: Pal.frameEdge, width: 2) : null,
      ),
      clipBehavior: Clip.antiAlias,
      child: Align(
        alignment: AlignmentDirectional.centerStart,
        child: FractionallySizedBox(
          widthFactor: v,
          heightFactor: 1,
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(height),
              gradient: LinearGradient(colors: [color ?? Pal.cyan, Color.lerp(color ?? Pal.cyan, const Color(0xFF3BD38A), 0.6)!]),
            ),
          ),
        ),
      ),
    );
  }
}

class StarsRow extends StatelessWidget {
  final int n;
  final double size;
  const StarsRow(this.n, {super.key, this.size = 14});
  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: tn('a11y.stars', n),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 0; i < 3; i++)
            Icon(Icons.star_rounded, size: size, color: i < n ? const Color(0xFFF5B800) : withA(Pal.cInk, 0.2)),
        ],
      ),
    );
  }
}

class CountBadge extends StatelessWidget {
  final int n;
  const CountBadge(this.n, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 21),
      height: 21,
      padding: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(color: Pal.heart, borderRadius: BorderRadius.circular(11), border: Border.all(color: Pal.frameEdge, width: 2)),
      alignment: Alignment.center,
      child: Text('$n', style: ts(11.5, color: Colors.white, height: 1.1)),
    );
  }
}

/// Segmented tabs (shop, missions, stats).
class TabsBar extends StatelessWidget {
  final List<(String, String, int)> tabs; // key, label, badge
  final String current;
  final ValueChanged<String> onPick;
  const TabsBar({super.key, required this.tabs, required this.current, required this.onPick});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(color: Pal.card, borderRadius: BorderRadius.circular(999), border: Border.all(color: Pal.cardEdge, width: 2)),
      child: Row(
        children: [
          for (final tb in tabs)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onPick(tb.$1),
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
                      decoration: BoxDecoration(
                        color: tb.$1 == current ? Pal.frame : Colors.transparent,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: tb.$1 == current ? Pal.frameEdge : Colors.transparent, width: 2),
                      ),
                      alignment: Alignment.center,
                      child: Text(tb.$2,
                          maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, color: tb.$1 == current ? Pal.ink : Pal.cInk)),
                    ),
                    if (tb.$3 > 0) PositionedDirectional(top: -8, end: -2, child: CountBadge(tb.$3)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// A pill with an icon and a number (coins, timer).
class Pill extends StatelessWidget {
  final Widget icon;
  final String text;
  final Color? textColor;
  const Pill({super.key, required this.icon, required this.text, this.textColor});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      padding: const EdgeInsetsDirectional.only(start: 6, end: 12),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(128),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Pal.frameEdge, width: 2.5),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        icon,
        const SizedBox(width: 5),
        Text(text, style: ts(16.5, color: textColor ?? Pal.ink).copyWith(fontFeatures: const [FontFeature.tabularFigures()])),
      ]),
    );
  }
}

/// On/off switch in the game's style.
class ToySwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;
  const ToySwitch(this.value, this.onChanged, {super.key});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onChanged(!value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: 52,
        height: 31,
        padding: const EdgeInsets.all(2.5),
        decoration: BoxDecoration(
          color: value ? const Color(0xFF3BD38A) : withA(Pal.cInk, 0.2),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Pal.frameEdge, width: 2.5),
        ),
        child: AnimatedAlign(
          duration: const Duration(milliseconds: 150),
          alignment: value ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: Container(
            width: 21,
            height: 21,
            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Pal.frameEdge, width: 2)),
          ),
        ),
      ),
    );
  }
}

/// Segmented choice (difficulty, language…).
class Segmented extends StatelessWidget {
  final List<(String, String)> options;
  final String value;
  final ValueChanged<String> onPick;
  const Segmented({super.key, required this.options, required this.value, required this.onPick});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(999), border: Border.all(color: Pal.cardEdge, width: 2)),
      clipBehavior: Clip.antiAlias,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final o in options)
            GestureDetector(
              onTap: () => onPick(o.$1),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                color: o.$1 == value ? Pal.frame : Colors.transparent,
                child: Text(o.$2, style: ts(13, color: o.$1 == value ? Pal.ink : Pal.cInk)),
              ),
            ),
        ],
      ),
    );
  }
}
