// Persistent key-value storage backed by SharedPreferences.
import 'package:shared_preferences/shared_preferences.dart';

import '../core/save.dart';

class PrefsStore implements KeyValueStore {
  final SharedPreferences? _prefs;
  PrefsStore(this._prefs);

  static Future<PrefsStore> open() async {
    try {
      return PrefsStore(await SharedPreferences.getInstance());
    } catch (_) {
      return PrefsStore(null);
    }
  }

  @override
  bool get ok => _prefs != null;

  @override
  String? read(String key) {
    try {
      return _prefs?.getString(key);
    } catch (_) {
      return null;
    }
  }

  @override
  bool write(String key, String value) {
    final p = _prefs;
    if (p == null) return false;
    try {
      p.setString(key, value);
      return true;
    } catch (_) {
      return false;
    }
  }
}
