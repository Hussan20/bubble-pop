// AUDIO — pre-rendered sound effects (low-latency pool) and looping music.
import 'dart:async';

import 'package:audioplayers/audioplayers.dart';

class GameAudio {
  static const List<String> sfxNames = [
    'pop0', 'pop1', 'pop2', 'pop3', 'pop4', 'pop5', 'pop6', 'pop7', 'pop8', 'pop9', 'pop10', 'pop11', 'pop12', 'pop13', 'pop14', //
    'hit', 'gold', 'coin', 'bomb', 'ice', 'split', 'spiky', 'heal', 'clock', 'rainbow', 'powerGet', 'power_slow', 'power_blast',
    'power_magnet', 'power_shield', 'block', 'combo2', 'combo3', 'combo4', 'combo5', 'fever', 'miss', 'lose', 'over', 'win',
    'levelUp', 'ach', 'event', 'ui', 'buy',
  ];

  static final Map<String, AudioPlayer> _players = {};
  static AudioPlayer? _music;
  static String _mood = 'menu';
  static String _playing = '';
  static bool sfxOn = true;
  static bool musicOn = true;
  static double sfxVol = 0.8;
  static double musicVol = 0.45;
  static bool _ready = false;
  static bool _background = false;

  static void _safe(Future<void> f) {
    unawaited(f.catchError((Object e) {}));
  }

  static Future<void> init() async {
    try {
      await AudioPlayer.global.setAudioContext(AudioContext(
        android: const AudioContextAndroid(
          audioFocus: AndroidAudioFocus.none,
          usageType: AndroidUsageType.game,
          contentType: AndroidContentType.sonification,
        ),
      ));
    } catch (_) {}
    try {
      final m = AudioPlayer();
      await m.setReleaseMode(ReleaseMode.loop);
      _music = m;
    } catch (_) {}
    _ready = true;
    _applyMusic();
    // load the effects in the background so the first screen is never held up
    for (final n in sfxNames) {
      try {
        final p = AudioPlayer();
        await p.setPlayerMode(PlayerMode.lowLatency);
        await p.setReleaseMode(ReleaseMode.stop);
        await p.setSource(AssetSource('sfx/$n.wav'));
        _players[n] = p;
      } catch (_) {}
    }
  }

  static void configure({required bool sfx, required bool music, required double sfxVolume, required double musicVolume}) {
    sfxOn = sfx;
    musicOn = music;
    sfxVol = sfxVolume;
    musicVol = musicVolume;
    _applyMusic();
  }

  static void play(String id, {int arg = 0}) {
    if (!sfxOn || _background || sfxVol <= 0) return;
    var name = id;
    if (id == 'pop') name = 'pop${arg.clamp(0, 14)}';
    if (id == 'combo') name = 'combo${arg.clamp(2, 5)}';
    final p = _players[name];
    if (p == null) return;
    _safe(p.stop().then((_) => p.play(AssetSource('sfx/$name.wav'), volume: sfxVol)));
  }

  static void setMood(String mood) {
    if (mood == _mood) return;
    _mood = mood;
    _applyMusic();
  }

  static void _applyMusic() {
    final m = _music;
    if (!_ready || m == null) return;
    final want = musicOn && !_background && musicVol > 0;
    if (!want) {
      if (_playing.isNotEmpty) {
        _playing = '';
        _safe(m.stop());
      }
      return;
    }
    final vol = musicVol * 0.55;
    if (_playing != _mood) {
      _playing = _mood;
      _safe(m.stop().then((_) => m.play(AssetSource('music/$_mood.ogg'), volume: vol)));
    } else {
      _safe(m.setVolume(vol));
    }
  }

  static void background(bool bg) {
    if (_background == bg) return;
    _background = bg;
    if (bg) {
      final m = _music;
      if (m != null && _playing.isNotEmpty) {
        _playing = '';
        _safe(m.stop());
      }
    } else {
      _applyMusic();
    }
  }
}
