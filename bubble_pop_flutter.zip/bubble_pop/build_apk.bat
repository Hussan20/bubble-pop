@echo off
rem Builds the release APK. Needs Flutter (https://docs.flutter.dev/get-started/install).
cd /d "%~dp0"

if not exist android (
  call flutter create --platforms=android --org com.bubblepop --project-name bubble_pop .
  if errorlevel 1 goto :fail
)
call flutter pub get
if errorlevel 1 goto :fail
call dart run tool/setup_android.dart
if errorlevel 1 goto :fail
call flutter build apk --release
if errorlevel 1 goto :fail

echo.
echo Done! APK: build\app\outputs\flutter-apk\app-release.apk
pause
exit /b 0

:fail
echo.
echo Build failed - see the messages above.
pause
exit /b 1
